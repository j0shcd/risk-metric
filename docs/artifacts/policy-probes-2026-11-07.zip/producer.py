from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
import json,hashlib,time
import pandas as pd,numpy as np
from research.market_dataset import canonical_bytes,load_snapshot
from research.market_information import baseline_candidates
from research.indicator_outer_replay import candidate_from_csv
from research.policy_probes import run_probes
from research.scorecard_artifacts import verify_packet,publish,write_packet
P=Path('output/indicator-outer-replay-2026-11-07-frozen');T=Path('output/policy-probes-2026-11-07-frozen')
def task(args):
 name,prices,scores=args;start=time.monotonic();result=run_probes(prices,scores);return name,result,time.monotonic()-start
if __name__=='__main__':
 verify_packet(P);s=load_snapshot(P/'source.csv');declaration=json.loads((P/'replay_registration.json').read_text())
 candidates=[candidate_from_csv((P/d['csv']).read_bytes(),d,s) for d in declaration['candidates']]
 candidates += [c for c in baseline_candidates(s) if c['direction']=='higher_risk']
 prices=pd.Series([r['price'] for r in s['daily']],index=pd.to_datetime([r['date'] for r in s['daily']]))
 targets=[]
 for c in candidates:
  scores=pd.Series([r['value'] for r in c['values']],index=pd.to_datetime([r['date'] for r in c['values']]))
  scores=scores.loc['2021-01-31':] # 24prior months, decisions Jan2023 onwards, same resetstate.
  targets.append((c['name'],prices,scores))
 registration={'protocol':'supporting-policy-campaign-v1','candidate_names':[x[0] for x in targets],'input_receipt_sha256':hashlib.sha256((P/'receipt.json').read_bytes()).hexdigest(),'input_source_sha256':s['source_sha256'],'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'policy_code_sha256':hashlib.sha256(Path('research/policy_probes.py').read_bytes()).hexdigest(),'first_decision':'2023-01-31','first_execution':'2023-02-01','warmup_start':'2021-01-31','final_mark':s['daily'][-1]['date'],'cost_bps_per_leg':[0,25,50],'freeze':'allthreefinalists and allfive declaredhigher-risk fixedreferences, no sign/threshold/cost/window selection','limitations':['Previously exposed historical pseudoOOS, unknown input availability, not economic validation or significance','Comparators have equal startingcapital1/no furthercontributions; exposurematch ex-post descriptive','Two separatepolicies; no selection or totalwinner']}
 T.mkdir(exist_ok=False);publish(T/'registration.json',canonical_bytes(registration));print(json.dumps(registration),flush=True)
 results={}
 with ProcessPoolExecutor(max_workers=2) as pool:
  for name,result,seconds in pool.map(task,targets):
   assert result['first_execution']=='2023-02-01';results[name]=result;print(name,round(seconds,3),flush=True)
 write_packet(T,{'results.json':canonical_bytes(results),'producer.py':Path(__file__).read_bytes()},bound_existing=('registration.json',))
 print('COMPLETE',flush=True)
