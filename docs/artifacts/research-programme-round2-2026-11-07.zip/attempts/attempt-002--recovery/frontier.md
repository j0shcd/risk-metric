# Benchmark frontier comparison

Completed measurement; no automatic promotion. Positive loss delta favors candidate; coverage/width are separate tradeoffs.

| Role | Months | Target | Reference | Replica | Scored / failed / unavailable | CRPS delta | Brier delta | 50% coverage delta / width delta | 80% coverage delta / width delta |
|---|---:|---|---|---:|---|---:|---:|---|---|
| development | 12 | terminal_log_return | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.039523 | -0.016536 | -0.020833 / -0.013926 | -0.020833 / 0.069577 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | -0.016141 | -0.008819 | 0.020833 / 0.002906 | 0.000000 / 0.002935 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | -0.015148 | -0.002939 | 0.062500 / 0.014008 | 0.000000 / -0.015472 |
| development | 24 | terminal_log_return | direct_cdf:dca_risk | None | 24 / 0 / 0 | -0.082929 | 0.000000 | 0.000000 / -0.124854 | 0.000000 / -0.136659 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | 0.002869 | 0.009552 | -0.166667 / 0.004050 | 0.000000 / 0.000300 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | 0.022208 | -0.010399 | -0.041667 / 0.029788 | -0.041667 / -0.025743 |
| development | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.062962 | -0.012381 | -0.041667 / -0.009265 | -0.020833 / 0.092324 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | -0.008633 | -0.009197 | 0.000000 / -0.015682 | 0.000000 / 0.004423 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | -0.014430 | -0.018889 | 0.000000 / 0.001573 | 0.000000 / 0.004821 |
| development | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.080432 | 0.000000 | 0.000000 / -0.181338 | 0.000000 / -0.187285 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.005107 | 0.003547 | -0.125000 / 0.005960 | 0.000000 / -0.018371 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | 0.032866 | -0.015174 | -0.125000 / -0.045123 | -0.041667 / -0.025743 |
| development | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.044052 | 0.020337 | 0.000000 / 0.013355 | -0.020833 / 0.051990 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | -0.001663 | 0.041625 | 0.000000 / -0.007476 | -0.020833 / -0.001504 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | -0.017554 | -0.020626 | 0.041667 / 0.049885 | 0.020833 / 0.015722 |
| development | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | -0.066892 | 0.000000 | 0.000000 / -0.060379 | 0.000000 / -0.028905 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | 0.001893 | 0.005003 | -0.083333 / 0.000876 | 0.000000 / 0.000300 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | 0.015313 | -0.009047 | 0.083333 / 0.087357 | 0.000000 / 0.000000 |
| development | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | 0.022017 | -0.019430 | -0.020833 / -0.067297 | -0.020833 / -0.024431 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | -0.010875 | -0.015203 | -0.020833 / -0.044351 | 0.000000 / 0.003274 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | -0.012374 | 0.006853 | 0.041667 / -0.018424 | -0.041667 / -0.068074 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.034711 | 0.000000 | 0.041667 / -0.072178 | 0.000000 / -0.077195 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.001651 | 0.001888 | -0.083333 / -0.010435 | 0.000000 / 0.000300 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | 0.008972 | 0.002503 | 0.000000 / 0.045865 | 0.000000 / 0.000000 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.081867 | -0.012381 | -0.041667 / -0.007626 | -0.041667 / 0.068720 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | -0.007142 | -0.006773 | -0.020833 / -0.025216 | 0.000000 / 0.001281 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | -0.017092 | -0.022331 | 0.000000 / 0.007518 | 0.020833 / 0.010351 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.087037 | 0.000000 | 0.000000 / -0.260561 | 0.000000 / -0.173328 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.000987 | 0.005903 | -0.125000 / 0.001623 | 0.000000 / -0.003249 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | 0.038191 | -0.023420 | -0.208333 / -0.118745 | -0.083333 / -0.062817 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | 0.013990 | -0.003503 | -0.020833 / 0.143640 | 0.000000 / 0.139667 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | -0.020224 | -0.020634 | 0.041667 / 0.041880 | 0.020833 / 0.013419 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | -0.024455 | -0.022990 | 0.125000 / 0.030016 | 0.020833 / 0.027185 |
| development | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.062877 | 0.000000 | 0.000000 / -0.065488 | 0.000000 / -0.028905 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.000327 | 0.003524 | -0.041667 / 0.011354 | 0.000000 / 0.000300 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | 0.016065 | -0.009047 | 0.083333 / 0.082361 | 0.000000 / -0.004997 |
| development | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | 0.013990 | -0.003503 | -0.020833 / 0.143640 | 0.000000 / 0.139667 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | -0.020224 | -0.020634 | 0.041667 / 0.041880 | 0.020833 / 0.013419 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | -0.024455 | -0.022990 | 0.125000 / 0.030016 | 0.020833 / 0.027185 |
| development | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.062877 | 0.000000 | 0.000000 / -0.065488 | 0.000000 / -0.028905 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.000327 | 0.003524 | -0.041667 / 0.011354 | 0.000000 / 0.000300 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | 0.016065 | -0.009047 | 0.083333 / 0.082361 | 0.000000 / -0.004997 |
| development | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.031294 | -0.022352 | 0.000000 / 0.100491 | -0.020833 / -0.007112 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | -0.007046 | -0.022556 | 0.000000 / 0.007515 | 0.000000 / -0.008804 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | -0.010178 | -0.018330 | 0.020833 / -0.002096 | 0.000000 / -0.017674 |
| development | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | -0.047479 | 0.000000 | -0.125000 / -0.206823 | 0.000000 / -0.154187 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | -0.011618 | -0.007118 | -0.083333 / -0.047255 | 0.000000 / 0.000230 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | 0.029254 | -0.029931 | 0.000000 / -0.069513 | -0.041667 / -0.069245 |
| development | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | 0.009075 | -0.017284 | -0.041667 / -0.168571 | -0.041667 / -0.011040 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | -0.008746 | -0.005118 | -0.020833 / -0.040848 | 0.000000 / 0.003860 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | -0.014954 | -0.016915 | 0.000000 / -0.014708 | -0.020833 / 0.015081 |
| development | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | -0.033384 | 0.000000 | 0.041667 / -0.068368 | 0.000000 / -0.025133 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | 0.002028 | 0.005903 | -0.041667 / 0.008570 | 0.000000 / 0.000300 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | -0.007061 | -0.012193 | 0.000000 / -0.035872 | 0.000000 / 0.000000 |
| development | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.081124 | -0.014465 | -0.020833 / 0.055515 | -0.041667 / -0.025918 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.001858 | 0.009034 | 0.000000 / -0.004160 | -0.020833 / -0.006090 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.004984 | 0.023077 | 0.000000 / -0.006877 | -0.062500 / -0.031276 |
| development | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | -0.012529 | 0.000000 | -0.083333 / -0.096239 | 0.000000 / -0.098547 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | -0.002242 | -0.001476 | -0.083333 / -0.006245 | 0.000000 / 0.000230 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | 0.025779 | 0.022587 | -0.041667 / -0.023737 | -0.041667 / -0.051718 |
| development | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.080593 | 0.002934 | -0.062500 / -0.024069 | -0.083333 / -0.019098 |
| development | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | -0.014895 | 0.016408 | 0.020833 / -0.005480 | -0.020833 / -0.025756 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | -0.019017 | -0.007530 | 0.104167 / 0.060928 | 0.020833 / -0.004926 |
| development | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | -0.104798 | 0.000000 | -0.083333 / -0.412088 | 0.000000 / -0.199704 |
| development | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | 0.039745 | 0.032309 | -0.166667 / -0.041656 | -0.083333 / -0.004407 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | 0.052498 | -0.014635 | 0.041667 / -0.001481 | -0.041667 / -0.026988 |
| development | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | 0.055679 | 0.007084 | 0.000000 / 0.125785 | 0.000000 / 0.055282 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | -0.022288 | -0.019956 | 0.020833 / 0.026712 | 0.020833 / 0.011931 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | -0.028075 | -0.031118 | 0.145833 / 0.018650 | 0.000000 / 0.003074 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | -0.049150 | 0.000000 | -0.041667 / -0.165999 | 0.000000 / -0.086444 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | 0.001702 | 0.003524 | -0.125000 / -0.000883 | 0.000000 / 0.000230 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | 0.016556 | 0.010538 | 0.041667 / 0.034229 | 0.000000 / -0.004997 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | -0.029925 | 0.000619 | 0.020833 / -0.154636 | 0.000000 / 0.053071 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | -0.003436 | -0.004874 | 0.000000 / -0.074065 | 0.000000 / -0.004204 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | 0.003606 | -0.005303 | 0.020833 / 0.035025 | 0.000000 / 0.000692 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | 0.014976 | 0.000000 | -0.125000 / -0.063802 | 0.000000 / 0.015951 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | -0.006770 | -0.007118 | 0.000000 / -0.056289 | 0.000000 / 0.000300 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | 0.008028 | 0.001207 | 0.041667 / 0.020926 | 0.000000 / -0.017411 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | context | None | 48 / 0 / 0 | 0.013990 | -0.003503 | -0.020833 / 0.143640 | 0.000000 / 0.139667 |
| development | 12 | entry_adverse_log_loss | context | None | 48 / 0 / 0 | -0.020224 | -0.020634 | 0.041667 / 0.041880 | 0.020833 / 0.013419 |
| development | 12 | peak_drawdown_log_loss | context | None | 48 / 0 / 0 | -0.024455 | -0.022990 | 0.125000 / 0.030016 | 0.020833 / 0.027185 |
| development | 24 | terminal_log_return | context | None | 24 / 0 / 0 | -0.062877 | 0.000000 | 0.000000 / -0.065488 | 0.000000 / -0.028905 |
| development | 24 | entry_adverse_log_loss | context | None | 24 / 0 / 0 | -0.000327 | 0.003524 | -0.041667 / 0.011354 | 0.000000 / 0.000300 |
| development | 24 | peak_drawdown_log_loss | context | None | 24 / 0 / 0 | 0.016065 | -0.009047 | 0.083333 / 0.082361 | 0.000000 / -0.004997 |
| development | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | unconditional | None | 48 / 0 / 0 | 0.017701 | 0.055460 | 0.000000 / 0.200095 | 0.000000 / 0.227943 |
| development | 12 | entry_adverse_log_loss | unconditional | None | 48 / 0 / 0 | -0.011554 | 0.001027 | 0.041667 / 0.079861 | 0.041667 / 0.047257 |
| development | 12 | peak_drawdown_log_loss | unconditional | None | 48 / 0 / 0 | -0.005954 | 0.000094 | 0.041667 / 0.110179 | 0.020833 / -0.016192 |
| development | 24 | terminal_log_return | unconditional | None | 24 / 0 / 0 | -0.185604 | 0.002658 | 0.250000 / 0.137660 | 0.041667 / 0.074944 |
| development | 24 | entry_adverse_log_loss | unconditional | None | 24 / 0 / 0 | 0.010688 | 0.030371 | -0.166667 / 0.124547 | 0.166667 / 0.141989 |
| development | 24 | peak_drawdown_log_loss | unconditional | None | 24 / 0 / 0 | 0.019504 | -0.072737 | 0.041667 / 0.241890 | 0.000000 / 0.046569 |
| development | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 0 | 48 / 0 / 0 | -0.185863 | -0.003592 | 0.062500 / -0.114439 | 0.083333 / -0.237355 |
| development | 12 | entry_adverse_log_loss | generative | 0 | 48 / 0 / 0 | -0.067261 | -0.068063 | -0.166667 / -0.072619 | 0.000000 / -0.038670 |
| development | 12 | peak_drawdown_log_loss | generative | 0 | 48 / 0 / 0 | 0.040006 | 0.264931 | -0.104167 / 0.090297 | -0.145833 / 0.109694 |
| development | 24 | terminal_log_return | generative | 0 | 24 / 0 / 0 | 0.188512 | 0.094137 | -0.250000 / 0.096236 | -0.375000 / 0.266853 |
| development | 24 | entry_adverse_log_loss | generative | 0 | 24 / 0 / 0 | -0.084143 | -0.021168 | 0.041667 / 0.227061 | 0.250000 / 0.446723 |
| development | 24 | peak_drawdown_log_loss | generative | 0 | 24 / 0 / 0 | -0.006055 | 0.227496 | 0.000000 / -0.003733 | -0.041667 / 0.058807 |
| development | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 1 | 48 / 0 / 0 | -0.187561 | -0.004019 | 0.041667 / -0.119757 | 0.104167 / -0.240659 |
| development | 12 | entry_adverse_log_loss | generative | 1 | 48 / 0 / 0 | -0.067512 | -0.068762 | -0.166667 / -0.073396 | 0.000000 / -0.041741 |
| development | 12 | peak_drawdown_log_loss | generative | 1 | 48 / 0 / 0 | 0.039505 | 0.264672 | -0.104167 / 0.090386 | -0.166667 / 0.108310 |
| development | 24 | terminal_log_return | generative | 1 | 24 / 0 / 0 | 0.189950 | 0.095399 | -0.208333 / 0.097919 | -0.375000 / 0.255307 |
| development | 24 | entry_adverse_log_loss | generative | 1 | 24 / 0 / 0 | -0.083848 | -0.020528 | 0.000000 / 0.227564 | 0.250000 / 0.448147 |
| development | 24 | peak_drawdown_log_loss | generative | 1 | 24 / 0 / 0 | -0.005113 | 0.227094 | -0.041667 / -0.001858 | -0.041667 / 0.057637 |
| development | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |

MC guard (numerical only, not significance):
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [-0.18586346511040075, -0.18756059241746992], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [-0.0035924544397563742, -0.004018607648276648], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.06726094374262635, -0.06751167627941164], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.06806305920618964, -0.06876187920707826], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [0.04000633416351592, 0.03950478486665768], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.2649313957735378, 0.26467150269824935], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [0.18851220071530128, 0.18995011014073626], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.09413701770599477, 0.09539876736477615], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.08414341752036925, -0.08384766025504549], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.021167829707400665, -0.020527796375593394], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [-0.0060546447648343925, -0.005113399300752265], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.22749557970977632, 0.22709398661296398], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}

Fixed-direction ordering, separate from forecast quality:
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': -0.28082555850090773, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': -0.16453062420624306, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.17132734273787883, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': 0.12579587111711366, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': -0.15759467320863904, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.6092660465915449, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': -0.36669561441597914, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': -0.306288738550756, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.6655135748747236, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
