"""Reproduce registered frozen transforms from immutable owned BTC bytes.

Copies are reviewed source/configuration; this is not a Python sandbox. No path,
macro payload, outcome, incumbent score or scorer is supplied to a transform.
"""
import argparse, hashlib, importlib.util, json, platform, shutil, sys
from pathlib import Path
import numpy as np
import pandas as pd
from research.owned_indicator_input import derive

SPECS = {
 'persistence': ('/Users/josh/.codex/worktrees/research-round2-persistence/risk-metric','research/candidates/persistence_20261107/generator.py','sign_persistence','output/round2-persistence-frozen/candidate.csv','7ca3609'),
 'recovery': ('/Users/josh/.codex/worktrees/research-simple-ensemble/risk-metric','research/candidates/recovery_20261107/generate.py','excursion_recovery_risk','output/recovery_20261107/frozen.csv','1606873'),
 'regime': ('/Users/josh/.codex/worktrees/research-round2-regime/risk-metric','research/candidates/regime_20261107/producer.py','regime_state','/private/tmp/regime-20261107-frozen-1b62110/candidate.csv','1b62110'),
}
INPUT_SHA='d6e0e23e4d84e32690cea42cc0bf69f44ddfe9d954939b54ba499635431ed04c'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def canonical(obj):return (json.dumps(obj,indent=2,sort_keys=True,allow_nan=False)+'\n').encode()

def main():
 p=argparse.ArgumentParser();p.add_argument('--capture',action='store_true');p.add_argument('--packet',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args()
 a.output_dir.mkdir(parents=True,exist_ok=False)
 if a.capture:
  raw=Path('/private/tmp/research-round2-admitted-inputs-20261107/btc_daily.csv').read_bytes()
  if sha(raw)!=INPUT_SHA:raise ValueError('unregistered input')
  (a.packet/'btc_daily.csv').write_bytes(raw)
 else:raw=(a.packet/'btc_daily.csv').read_bytes()
 receipt={'input_sha256':sha(raw),'helper_sha256':sha(Path(sys.modules[derive.__module__].__file__).read_bytes()),'controller_sha256':sha(Path(__file__).read_bytes()),'runtime':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__},'candidates':{}}
 queries=pd.date_range('2014-12-31','2022-12-31',freq='ME')
 for name,(root,relative,column,expected,commit) in SPECS.items():
  source_dir=a.packet/'generators'/name
  if a.capture:
   source_dir.mkdir(parents=True,exist_ok=False)
   src=Path(root)/relative
   (source_dir/'producer.py').write_bytes(src.read_bytes())
   (source_dir/'config.json').write_bytes(src.with_name('config.json').read_bytes())
   (source_dir/'worker.csv').write_bytes((Path(root)/expected).read_bytes())
  spec=importlib.util.spec_from_file_location('owned_'+name,source_dir/'producer.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
  result,evidence=derive(raw,INPUT_SHA,lambda frame:mod.generate(frame,queries))
  if isinstance(result,tuple): result=result[0]
  if len(result)!=97 or list(result.Date)!=list(queries.strftime('%Y-%m-%d')) or not np.isfinite(result[column]).all():raise ValueError('query/finite mismatch')
  generated=result.to_csv(index=False,float_format='%.17g').encode()
  if generated!=(source_dir/'worker.csv').read_bytes():raise ValueError('worker output not reproduced byte for byte: '+name)
  target=a.output_dir/name;target.mkdir();(target/'candidate.csv').write_bytes(generated)
  receipt['candidates'][name]={**evidence,'column':column,'source_commit':commit,'producer_sha256':sha((source_dir/'producer.py').read_bytes()),'config_sha256':sha((source_dir/'config.json').read_bytes()),'output_sha256':sha(generated),'rows':len(result),'worker_csv_exact':True}
 (a.output_dir/'reproduction.json').write_bytes(canonical(receipt));print(json.dumps(receipt,sort_keys=True))
if __name__=='__main__': main()
