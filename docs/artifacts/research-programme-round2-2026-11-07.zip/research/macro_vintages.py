"""Offline FRED output_type=1 interval snapshots from owned bytes.

parse_pages(raw_pages, manifest) returns a mapping series_id -> SeriesPages.
Manifest entries bind series_id, sha256 and request parameters; explicit empty
blocks use status='no_archived_vintages' without a payload. Never accepts a path.
select_snapshot(series_pages, query) uses archive day=query00UTC minus2calendar
days and the containing request block. Its calendar history retains missingness.
Clipped interval starts are NOT original release dates. Date-level archival
reconstruction is not exact ingestion/PIT evidence; no current-cache fallback.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date,timedelta
import hashlib
import json
import math
import re

SERIES=frozenset(('DTWEXBGS','DFII10','WALCL','RRPONTSYD'))
MAX_PAGES=128
MAX_BYTES=128*1024*1024
MAX_ROWS=1_000_000


def day(value):
    if not isinstance(value,str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}',value):raise ValueError('ISO day required')
    return date.fromisoformat(value)  # stdlib handles9999-12-31 without overflow.


def integer(value):
    if type(value) is not int or value<0:raise ValueError('nonnegative integer required')
    return value


def _object(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate JSON key')
        result[key]=value
    return result


@dataclass(frozen=True)
class Block:
    start: date
    end: date
    observation_start: date
    observation_end: date
    status: str
    records: tuple
    hashes: tuple
    duplicate_count: int


@dataclass(frozen=True)
class SeriesPages:
    series_id: str
    blocks: tuple[Block,...]


def parse_pages(raw_pages,manifest):
    """Validate response echoes, complete pagination and conflict-free intervals.

    raw_pages follows captured manifest entries; empty-block markers consume no
    bytes. Captured bytes are hashed and parsed directly, never reopened.
    All pages in a block must use one fixed request limit and observation span.
    """
    if not isinstance(raw_pages,(list,tuple)) or not isinstance(manifest,(list,tuple)) or len(manifest)>MAX_PAGES or len(raw_pages)>MAX_PAGES:
        raise ValueError('bounded page/manifest sequences required')
    if any(type(raw) is not bytes for raw in raw_pages) or sum(map(len,raw_pages))>MAX_BYTES:raise ValueError('owned byte limit/type')
    groups={};position=total_rows=0
    for entry in manifest:
        series=entry['series_id']
        if series not in SERIES:raise ValueError('unregistered series')
        request=entry['request']
        if 'api_key' in request or ('series_id' in request and request['series_id']!=series):raise ValueError('credential or series request mismatch')
        start,end=day(request['realtime_start']),day(request['realtime_end'])
        obs_start,obs_end=day(request['observation_start']),day(request['observation_end'])
        if start>end or obs_start>obs_end or (obs_end-obs_start).days>36600 or type(request['output_type']) is not int or request['output_type']!=1:raise ValueError('request bounds/output type')
        key=(series,start,end);group=groups.setdefault(key,{'span':(obs_start,obs_end),'pages':[],'empty':False})
        if group['span']!=(obs_start,obs_end):raise ValueError('observation span changed within block')
        if entry.get('status','captured')=='no_archived_vintages':
            if group['pages'] or group['empty']:raise ValueError('duplicate/contradictory empty block')
            group['empty']=True;continue
        if entry.get('status','captured')!='captured' or group['empty']:raise ValueError('unsupported/contradictory block status')
        if position>=len(raw_pages):raise ValueError('missing owned page')
        raw=raw_pages[position];position+=1
        digest=hashlib.sha256(raw).hexdigest()
        if digest!=entry['sha256']:raise ValueError('owned page hash mismatch')
        body=json.loads(raw,object_pairs_hook=_object,parse_constant=lambda v:(_ for _ in ()).throw(ValueError('nonfinite JSON constant')))
        for field in ('realtime_start','realtime_end','observation_start','observation_end'):
            if body[field]!=request[field]:raise ValueError('response date echo mismatch')
        if type(body['output_type']) is not int:raise ValueError('integer output_type required')
        expected={'units':'lin','output_type':1,'file_type':'json','order_by':'observation_date','sort_order':'asc'}
        for field,value in expected.items():
            if body[field]!=value or (field in request and request[field]!=value):raise ValueError('response/request transform echo mismatch')
        if 'series_id' in body and body['series_id']!=series:raise ValueError('response series mismatch')
        count,offset,limit=(integer(body[k]) for k in ('count','offset','limit'))
        if limit<1 or offset!=integer(request['offset']) or limit!=integer(request['limit']):raise ValueError('pagination echo mismatch')
        rows=body['observations']
        if not isinstance(rows,list) or offset>count or len(rows)!=min(limit,count-offset):raise ValueError('response count/row mismatch')
        total_rows+=len(rows)
        if total_rows>MAX_ROWS:raise ValueError('row budget exceeded')
        parsed=[]
        for row in rows:
            if set(row)!={'date','realtime_start','realtime_end','value'}:raise ValueError('row schema mismatch')
            observation,left,right=day(row['date']),day(row['realtime_start']),day(row['realtime_end'])
            if not obs_start<=observation<=obs_end or left>right or left<start or right>end:raise ValueError('row outside requested/clipped interval')
            text=row['value']
            if not isinstance(text,str):raise ValueError('original value token required')
            if text=='.':value=None
            else:
                if not re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?',text):raise ValueError('invalid numeric token')
                value=float(text)
                if not math.isfinite(value):raise ValueError('nonfinite value')
                if series in ('DTWEXBGS','WALCL') and value<=0 or series=='RRPONTSYD' and value<0:raise ValueError('invalid series physical value')
            parsed.append((observation,left,right,value,text))
        group['pages'].append((offset,count,limit,tuple(parsed),digest))
    if position!=len(raw_pages):raise ValueError('unmanifested owned bytes')
    result={}
    for (series,start,end),group in groups.items():
        pages=sorted(group['pages'],key=lambda p:p[0]);records=[];duplicates=0;hashes=[]
        if pages:
            expected_offset=0;count=pages[0][1];limit=pages[0][2];seen_offsets=set()
            for offset,total,page_limit,rows,digest in pages:
                if offset in seen_offsets or offset!=expected_offset or total!=count or page_limit!=limit:raise ValueError('incomplete/overlapping pagination')
                seen_offsets.add(offset);expected_offset+=len(rows);records.extend(rows);hashes.append(digest)
            if expected_offset!=count:raise ValueError('incomplete pagination')
        elif not group['empty']:raise ValueError('uncovered block')
        unique={}
        for row in records:
            key=row[:3]
            if key in unique:
                if unique[key][3:]!=row[3:]:raise ValueError('conflicting duplicate interval')
                duplicates+=1
            else:unique[key]=row
        records=sorted(unique.values(),key=lambda r:r[:3]);previous=None
        for row in records:
            if previous is not None and row[0]==previous[0] and row[1]<=previous[2]:raise ValueError('overlapping observation intervals')
            previous=row
        block=Block(start,end,*group['span'],'no_archived_vintages' if group['empty'] else 'captured',tuple(records),tuple(hashes),duplicates)
        result.setdefault(series,[]).append(block)
    for series,blocks in result.items():
        blocks.sort(key=lambda b:b.start)
        for previous,current in zip(blocks,blocks[1:]):
            if current.start<=previous.end:raise ValueError('overlapping request blocks')
            if (current.observation_start,current.observation_end)!=(previous.observation_start,previous.observation_end):raise ValueError('observation domain changed across blocks')
        result[series]=SeriesPages(series,tuple(blocks))
    return result


def select_snapshot(series_pages,query):
    """Return calendar history, explicit missing states and separate row evidence.

    history is invariant to future revisions/closure of an old open interval.
    evidence hashes/end bounds may legitimately change as captures change.
    Calendar gaps are unavailable, never an invented economic zero or ffill.
    """
    q=day(query);cutoff=q-timedelta(days=2)
    blocks=[b for b in series_pages.blocks if b.start<=cutoff<=b.end]
    base={'series_id':series_pages.series_id,'query':query,'archive_asof_day':cutoff.isoformat(),
          'history':[],'evidence':[],'finite_n':0,'explicit_missing_n':0,'gap_n':0}
    if not blocks:return {**base,'coverage_status':'uncovered_archive_day','duplicate_count':0}
    block=blocks[0]
    if block.status=='no_archived_vintages':return {**base,'coverage_status':'no_archived_vintages','duplicate_count':0}
    selected={}
    for observation,start,end,value,token in block.records:
        if observation<=q and start<=cutoff<=end:selected[observation]=(start,end,value,token)
    history=[];evidence=[];current=block.observation_start;last=min(q,block.observation_end)
    for n in range(max(0,(last-current).days+1)):
        at=current+timedelta(days=n)
        item=selected.get(at)
        value=None if item is None else item[2]
        status='no_interval' if item is None else ('explicit_missing' if value is None else 'finite')
        history.append({'observation_date':at.isoformat(),'value':value,'status':status})
        if item is not None:evidence.append({'observation_date':at.isoformat(),'interval_start_bound':item[0].isoformat(),
            'interval_end_bound':item[1].isoformat(),'original_value_token':item[3]})
    finite=sum(r['status']=='finite' for r in history);missing=sum(r['status']=='explicit_missing' for r in history)
    latest=max(selected,default=None)
    return {**base,'coverage_status':'captured','history':history,'evidence':evidence,'finite_n':finite,
            'explicit_missing_n':missing,'gap_n':len(history)-finite-missing,'duplicate_count':block.duplicate_count,
            'request_realtime_start':block.start.isoformat(),'request_realtime_end':block.end.isoformat(),
            'source_sha256':list(block.hashes),'latest_observation_date':None if latest is None else latest.isoformat(),
            'latest_observation_age_days':None if latest is None else (q-latest).days}
