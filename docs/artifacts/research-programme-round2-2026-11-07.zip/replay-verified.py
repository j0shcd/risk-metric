"""Replay a trusted round2 evidence packet; no scoring or data acquisition.

Authenticate the enclosing ZIP SHA externally before use. Receipt+payload hashes
provide internal continuity, not authentication against jointly rewritten files.
Verified Python is trusted reviewed code, not sandboxed. Supply the frozen helper
via --helper, or package it as owned_indicator_input.py at the packet root.
"""
import argparse
import hashlib
import importlib.util
import json
import platform
import tempfile
from pathlib import Path
import numpy as np
import pandas as pd

NAMES=('persistence','recovery','regime')
INPUT_SHA='d6e0e23e4d84e32690cea42cc0bf69f44ddfe9d954939b54ba499635431ed04c'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def checked(path, expected):
    raw=path.read_bytes()
    if digest(raw)!=expected:
        raise ValueError('identity mismatch: '+str(path))
    return raw


def capture(packet, helper):
    # All checks finish before loading any captured Python, including helper.
    receipt_raw=(packet/'reproduced/reproduction.json').read_bytes()
    receipt=json.loads(receipt_raw)
    runtime={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__}
    if receipt['runtime']!=runtime:
        raise ValueError('runtime mismatch')
    if set(receipt['candidates'])!=set(NAMES) or receipt['input_sha256']!=INPUT_SHA:
        raise ValueError('unexpected candidate or input inventory')
    owned={'receipt':receipt,'receipt_raw':receipt_raw,
           'controller':checked(packet/'replay-generators.py',receipt['controller_sha256']),
           'input':checked(packet/'btc_daily.csv',INPUT_SHA),
           'helper':checked(helper,receipt['helper_sha256']),'candidates':{}}
    for name in NAMES:
        item=receipt['candidates'][name];root=packet/'generators'/name
        if item['input_sha256']!=INPUT_SHA or item['rows']!=97 or item['worker_csv_exact'] is not True:
            raise ValueError('candidate declaration mismatch')
        if item['input_bytes']!=len(owned['input']):
            raise ValueError('input byte count mismatch')
        owned['candidates'][name]={file:checked(root/file,item[key]) for file,key in (
            ('producer.py','producer_sha256'),('config.json','config_sha256'),('worker.csv','output_sha256'))}
    return owned


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def execute(owned, output):
    receipt=owned['receipt'];queries=pd.date_range('2014-12-31','2022-12-31',freq='ME')
    generated={}
    with tempfile.TemporaryDirectory(prefix='round2-verified-',dir=Path(tempfile.gettempdir()).resolve()) as temp:
        private=Path(temp);helper=private/'owned_indicator_input.py';helper.write_bytes(owned['helper'])
        derive=load('verified_owned_indicator_input',helper).derive
        for name in NAMES:
            root=private/name;root.mkdir()
            for file,raw in owned['candidates'][name].items():(root/file).write_bytes(raw)
            producer=load('verified_round2_'+name,root/'producer.py')
            result,evidence=derive(owned['input'],INPUT_SHA,lambda frame:producer.generate(frame,queries))
            if isinstance(result,tuple):result=result[0]
            item=receipt['candidates'][name];column=item['column']
            if len(result)!=97 or list(result.Date)!=list(queries.strftime('%Y-%m-%d')) or not np.isfinite(result[column]).all():
                raise ValueError('support mismatch: '+name)
            if evidence['input_rows']!=item['input_rows']:
                raise ValueError('input row count mismatch')
            raw=result.to_csv(index=False,float_format='%.17g').encode()
            if raw!=owned['candidates'][name]['worker.csv']:
                raise ValueError('output mismatch: '+name)
            generated[name]=raw
    output.mkdir(parents=True,exist_ok=False)
    for name,raw in generated.items():
        target=output/name;target.mkdir();(target/'candidate.csv').write_bytes(raw)
    (output/'verification.json').write_text(json.dumps({'original_receipt_sha256':digest(owned['receipt_raw']),
        'input_sha256':INPUT_SHA,'rows_each':97,'outputs':{n:digest(b) for n,b in generated.items()},
        'scope':'transform replay only; no scoring; external ZIP authenticity required'},indent=2)+'\n')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--packet',type=Path,required=True)
    p.add_argument('--helper',type=Path)
    p.add_argument('--output-dir',type=Path,required=True)
    a=p.parse_args()
    owned=capture(a.packet,a.helper or a.packet/'owned_indicator_input.py')
    execute(owned,a.output_dir)
    print('verified all three 97-row outputs; no scoring')


if __name__=='__main__':main()
