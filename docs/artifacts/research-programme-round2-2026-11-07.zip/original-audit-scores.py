"""Read-only primitive arithmetic audit; no research modules or model/scorer calls."""
import hashlib, io, json, math
from pathlib import Path
import numpy as np
import pandas as pd
P=Path('/Users/josh/Documents/03_Projects/risk-metric/output/research-programme-round2-2026-11-07')
def load(p): return json.loads(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(x): return hashlib.sha256((json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()
errors={}; counts={}; warnings=[]
def close(kind,a,b):
 if a is None or b is None: assert a is b,(kind,a,b);return
 e=float(np.max(np.abs(np.asarray(a,dtype=float)-np.asarray(b,dtype=float))))
 errors[kind]=max(errors.get(kind,0),e)
 assert e<1e-10,(kind,e,a,b)
def key(r):return (r['date'],r['horizon'],r['target'])
def cellkey(r):return (r['role'],r['horizon'],r['target'])
def receipt(path):
 for f,h in load(path/'receipt.json')['files'].items():assert sha(path/f)==h,(path,f)
receipt(P)
manifest=load(P/'manifest.json');atlas=load(P/'benchmark_atlas.json');reproduction=load(P/'reproduced/reproduction.json')
assert sha(P/'benchmark_atlas.json')==manifest['benchmark_atlas_sha256']
assert sha(P/'references.json')==manifest['references_id']
assert atlas['atlas_id']==manifest['benchmark_atlas_id']
assert len(atlas['models'])==17 and len(set((m['name'],m['replica']) for m in atlas['models']))==17
assert sorted([list((m['name'],m['replica'])) for m in atlas['models']],key=str)==sorted(atlas['reference_inventory'],key=str)
for file,h in manifest['code_hashes'].items():assert sha(P.parents[1]/'research'/file)==h,file
raw=(P/'btc_daily.csv').read_bytes();assert hashlib.sha256(raw).hexdigest()=='d6e0e23e4d84e32690cea42cc0bf69f44ddfe9d954939b54ba499635431ed04c'
prices=pd.read_csv(io.BytesIO(raw),parse_dates=['Date']).set_index('Date').Price
logs=np.log(prices);support=manifest['support'];assert len(support)==97
TARGETS=['terminal_log_return','entry_adverse_log_loss','peak_drawdown_log_loss']
contexts={}
for d in support:
 q=pd.Timestamp(d);ctx=[logs[q]-logs[q-pd.DateOffset(years=1)],np.std(np.diff(logs.loc[q-pd.Timedelta(days=90):q]),ddof=1)]
 contexts[d]=ctx
labels={}
for d in support:
 for h in (12,24,48):
  entry=pd.Timestamp(d)+pd.Timedelta(days=1);end=entry+pd.DateOffset(months=h);avail=end+pd.Timedelta(days=1)
  if end<=logs.index[-1]:
   path=logs.loc[entry:end].to_numpy();v=[path[-1]-path[0],path[0]-min(path),max(np.maximum.accumulate(path)-path)]
   for t,y in zip(TARGETS,v):labels[(d,h,t)]=(float(y),avail.strftime('%Y-%m-%d'))
def loss(x,w,y):return float(sum(w*abs(x-y))-.5*sum(w[i]*w[j]*abs(x[i]-x[j]) for i in range(len(x)) for j in range(len(x))))
def metrics(r):
 x=np.asarray(r['atoms']);w=np.asarray(r['candidate_weights']);y=r['outcome']
 if y is None:return {}
 mask=x<0 if r['target']==TARGETS[0] else x>math.log(2)
 event=y<0 if r['target']==TARGETS[0] else y>math.log(2)
 prob=float(sum(w[mask]));out={'crps':loss(x,w,y),'brier':(prob-event)**2}
 order=np.argsort(x);xx=x[order];ww=w[order];cs=np.cumsum(ww)
 for level,tail in [(50,.25),(80,.1)]:
  lo=xx[min(np.searchsorted(cs,tail),len(x)-1)];hi=xx[min(np.searchsorted(cs,1-tail),len(x)-1)]
  out['coverage_'+str(level)]=float(lo<=y<=hi);out['width_'+str(level)]=float(hi-lo)
 return out
primary={};totalpred=totalscored=totalcells=totalguards=0
for attempt in sorted((P/'attempts').iterdir()):
 if not attempt.is_dir():continue
 receipt(attempt);name=attempt.name.split('--')[1];rep=reproduction['candidates'][name]
 trial=load(attempt/'trial.json');result=trial['result'];front=load(attempt/'frontier.json');req=load(attempt/'request.json')
 assert load(attempt/'outcome.json')['status']=='completed'
 for f,field in [('producer.bin','producer_sha256'),('config.bin','config_sha256'),('candidate.csv','output_sha256')]:assert sha(attempt/f)==rep[field]
 assert (attempt/'producer.bin').read_bytes()==(P/'generators'/name/'producer.py').read_bytes()
 assert (attempt/'config.bin').read_bytes()==(P/'generators'/name/'config.json').read_bytes()
 assert (attempt/'candidate.csv').read_bytes()==(P/'generators'/name/'worker.csv').read_bytes()==(P/'reproduced'/name/'candidate.csv').read_bytes()
 assert trial['candidate_csv_sha256']==rep['output_sha256']
 for k,v in atlas['identity'].items():assert result[k]==v,k
 csv=pd.read_csv(attempt/'candidate.csv');vals=dict(zip(csv.Date,csv[rep['column']]))
 assert list(csv.Date)==support
 for row in trial['candidate']['values']:close('csv_values',vals[row['date']],row['value'])
 # Independently calculate all97 candidate scalars from admitted prices, without producer execution.
 if name=='regime':
  rr=np.r_[np.nan,np.diff(logs.to_numpy())];pp=.5;states=[]
  for i,r in enumerate(rr):
   prev=rr[max(0,i-365):i]
   if len(prev)<365 or not np.isfinite(prev).all() or np.mean(prev**2)<=1e-12:pp=.5
   else:
    var=np.mean(prev**2);prior=.99*pp+.01*(1-pp)
    ll=np.log([1-prior,prior])-np.log([.5,2.])-.5*r*r/var/np.square([.5,2.])
    pp=float(np.exp(ll[1]-np.logaddexp(ll[0],ll[1])))
   states.append(100*pp)
 for d in support:
  q=pd.Timestamp(d)
  if name=='persistence':
   cut=q-pd.Timedelta(days=2);v=prices.loc[cut-pd.Timedelta(days=365):cut].to_numpy();s=np.sign(np.diff(v));a=s[:-1];b=s[1:];n=len(a)
   expected=(1+(n*sum(a*b)-sum(a)*sum(b))/np.sqrt((n*sum(a*a)-sum(a)**2)*(n*sum(b*b)-sum(b)**2)))/2
  elif name=='recovery':
   path=logs.loc[:q-pd.Timedelta(days=1)].to_numpy();peak=path[0];worst=0
   for v in path:
    if v>=peak:peak=v;worst=0
    dd=peak-v;worst=max(worst,dd)
   expected=100*(1-dd/max(math.log(2),worst))
  else:expected=states[logs.index.get_loc(q-pd.Timedelta(days=1))]
  close('candidate_'+name,expected,vals[d])
 predictions={key(r):r for r in result['predictions']};base={key(r):r for r in atlas['models'][0]['records']}
 assert predictions.keys()==base.keys()
 computed={}
 for k,r in predictions.items():
  totalpred+=1;assert len(r['atoms'])==24
  h=r['horizon'];d=r['date'];target=r['target']
  eligible=[s for s in support if s<d and (s,h,target) in labels and labels[s,h,target][1]<d][-24:]
  assert eligible==r['train_dates']
  close('atoms',[labels[s,h,target][0] for s in eligible],r['atoms'])
  f=np.array([contexts[s]+[vals[s]] for s in eligible]);query=np.array(contexts[d]+[vals[d]]);cuts=np.median(f,axis=0)
  close('thresholds',cuts,r['thresholds']);m=np.all((f[:,:2]>cuts[:2])==(query[:2]>cuts[:2]),axis=1);c=m&((f[:,2]>cuts[2])==(query[2]>cuts[2]));u=np.ones(24)/24
  wr=.5*u+.5*m/sum(m) if m.any() else u;wc=.5*u+.5*c/sum(c) if c.any() else wr
  close('reference_weights',wr,r['reference_weights']);close('candidate_weights',wc,r['candidate_weights'])
  assert r['candidate_cell_n']==sum(c) and r['context_cell_n']==sum(m)
  assert r['candidate_fallback']==(not c.any()) and r['context_fallback']==(not m.any())
  for field in ('role','outcome','entry','end','label_available'):assert r[field]==base[k][field]
  if r['status']=='scored':
   totalscored+=1;close('outcome',r['outcome'],labels[k][0]);x=np.array(r['atoms']);y=r['outcome']
   for field,w in [('candidate_crps',wc),('reference_crps',wr),('unconditional_crps',u)]:close('crps',loss(x,w,y),r[field])
  computed[k]=metrics(r)
 for model in atlas['models']:
  refs={key(r):r for r in model['records']}
  for cell in [c for c in front['cells'] if c['reference']==model['name'] and c['replica']==model['replica']]:
   totalcells+=1;group=[k for k,r in base.items() if cellkey(r)==cellkey(cell)]
   scored=[k for k in group if predictions[k]['status']=='scored' and refs[k]['status']=='scored'];failed=[k for k in group if refs[k]['status']=='numerical_failure']
   assert cell['requested_n']==len(group) and cell['scored_n']==len(scored) and cell['failure_n']==len(failed)
   assert cell['unavailable_n']==len(group)-len(scored)-len(failed)
   assert cell['scored_origins_id']==digest(sorted(k[0] for k in scored))
   assert cell['extra_reference_origins_excluded_n']==sum(cellkey(r)==cellkey(cell) and k not in base for k,r in refs.items())
   complete=len(scored)==sum(predictions[k]['status']=='scored' for k in group) and not failed
   for metric in ('crps','brier','coverage_50','coverage_80','width_50','width_80'):
    cm=float(np.mean([computed[k][metric] for k in scored])) if complete and scored else None
    rm=float(np.mean([refs[k][metric] for k in scored])) if complete and scored else None
    delta=float(np.mean([refs[k][metric]-computed[k][metric] for k in scored])) if complete and scored else None
    close('cell_candidate_'+metric,cm,cell['candidate'][metric]);close('cell_reference_'+metric,rm,cell['reference_means'][metric]);close('cell_delta_'+metric,delta,cell['reference_minus_candidate'][metric])
 for guard in front['mc_guards']:
  totalguards+=1;cs=[next(c for c in front['cells'] if c['reference']=='generative' and c['replica']==i and cellkey(c)==cellkey(guard)) for i in (0,1)]
  gains=[c['reference_minus_candidate'][guard['metric']] for c in cs];assert gains==guard['replica_gains']
  passed=all(g is not None and g>0 for g in gains) and abs(gains[0]-gains[1])<.2*min(gains)
  assert passed==guard['numerically_stable_gain']
 for cell in result['cells']:
  rows=[r for r in predictions.values() if cellkey(r)==cellkey(cell) and r['status']=='scored']
  assert len(rows)==cell['scored_n']
  if rows:close('trial_cell_crps',np.mean([computed[key(r)]['crps'] for r in rows]),cell['candidate_mean_crps'])
 primary[name]=next(c['candidate_mean_crps'] for c in result['cells'] if cellkey(c)==('development',24,TARGETS[0]))
 best=min(c['reference_means']['crps'] for c in front['cells'] if cellkey(c)==('development',24,TARGETS[0]) and c['reference_means']['crps'] is not None)
 close('primary_best_reference',best,0.33107363984732724)
 assert primary[name]>best
 assert not any(r['status']=='scored' and r['horizon']==48 for r in predictions.values())
 if name in ('persistence','regime') and result['direction']=='higher_risk':warnings.append(name+': API higher_risk metadata is arbitrary ordering convention; registered mechanism is undirected. Does not affect distribution losses.')
 assert len(front['cells'])==765 and len(front['mc_guards'])==90
counts={'attempts':3,'predictions':totalpred,'scored_predictions':totalscored,'frontier_cells':totalcells,'mc_guards':totalguards,'candidate_scalar_values':291,'reference_models':17}
report={'status':'PASS_arithmetic_with_direction_metadata_caveat','counts':counts,'max_absolute_errors':errors,'primary24m_crps':primary,'warnings':warnings,'limitations':['No scorer, generator or model modules imported/executed. No new trials or macro payloads read.','Generative reference fair losses trusted from immutable previously audited atlas; samples not regenerated.','Candidate source/config/worker/root reproduction byte identity verified; scalars independently reconstructed from admitted prices.','Historical timing and source-vintage limitations remain; not performance qualification.'],'campaign_manifest_sha256':sha(P/'manifest.json'),'atlas_sha256':sha(P/'benchmark_atlas.json'),'script_sha256':sha(Path(__file__))}
Path('/private/tmp/round2-independent-score-audit-b.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2))
