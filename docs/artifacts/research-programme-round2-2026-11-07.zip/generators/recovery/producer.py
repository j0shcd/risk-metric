"""Frozen price-only excursion recovery hypothesis; no estimated parameters.

Higher risk means less remaining recovery opportunity, a hypothesis not evidence.
Owned daily prices are current-vintage historical data, not certified PIT prices.
Prior programme outer history is exposed; this is not a fresh holdout.
Run: python -m research.candidates.recovery_20261107.generate --input CSV --output CSV
"""
import argparse
import hashlib
import io
import json
from pathlib import Path

import numpy as np
import pandas as pd

INPUT_SHA256 = 'd6e0e23e4d84e32690cea42cc0bf69f44ddfe9d954939b54ba499635431ed04c'
COLUMN = 'excursion_recovery_risk'


def generate(prices, queries):
    """Date/Price frame -> finite query scores, with strict one-calendar-day lag.

    State starts at first owned close and resets only when that peak is recovered.
    Missing/invalid earlier closes invalidate subsequent state; no interpolation.
    Future rows are excluded before inspecting prices, so poison cannot leak back.
    """
    dates = pd.to_datetime(prices['Date'], errors='raise')
    if dates.dt.tz is not None or not (dates == dates.dt.normalize()).all():
        raise ValueError('dates must be naive UTC calendar midnights')
    rows = []
    for query in pd.to_datetime(queries):
        if query.tz is not None or query != query.normalize():
            raise ValueError('query must be UTC calendar midnight')
        cutoff = query - pd.Timedelta(days=1)
        frame = prices.loc[dates <= cutoff].copy()
        frame['Date'] = dates.loc[dates <= cutoff]
        frame = frame.sort_values('Date')
        flag = 'available'
        score = 50.0
        dd = worst = 0.0
        if len(frame) < 731:
            flag = 'insufficient_history'
        elif frame['Date'].duplicated().any():
            flag = 'duplicate_date'
        elif frame['Date'].iloc[-1] != cutoff:
            flag = 'stale'
        elif not frame['Date'].diff().iloc[1:].eq(pd.Timedelta(days=1)).all():
            flag = 'calendar_gap'
        else:
            values = pd.to_numeric(frame['Price'], errors='coerce').to_numpy(float)
            if not np.isfinite(values).all() or (values <= 0).any():
                flag = 'invalid_price'
            else:
                logs = np.log(values)  # avoid price-ratio overflow
                peak = logs[0]
                for value in logs:
                    if value >= peak:
                        peak, worst = value, 0.0
                    dd = max(0.0, peak - value)
                    worst = max(worst, dd)
                score = 100.0 * (1.0 - dd / max(np.log(2.0), worst))
        rows.append({'Date': query.strftime('%Y-%m-%d'), COLUMN: float(score),
                     'coverage': flag, 'observations': len(frame),
                     'current_log_drawdown': float(dd), 'excursion_worst_log_drawdown': float(worst)})
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    payload = Path(args.input).read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    if digest != INPUT_SHA256:
        raise ValueError('input is not the admitted owned price payload')
    prices = pd.read_csv(io.BytesIO(payload))
    queries = pd.date_range('2014-12-31', '2022-12-31', freq='ME')
    result = generate(prices, queries)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x') as stream:
        result.to_csv(stream, index=False, float_format='%.17g')
    diagnostic = {'input_sha256': digest, 'producer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  'output_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
                  'rows': len(result), 'coverage': result.coverage.value_counts().to_dict(),
                  'benchmark_executed': False}
    with output.with_suffix('.json').open('x') as stream:
        json.dump(diagnostic, stream, indent=2, sort_keys=True)
    print(json.dumps(diagnostic, sort_keys=True))


if __name__ == '__main__':
    main()
