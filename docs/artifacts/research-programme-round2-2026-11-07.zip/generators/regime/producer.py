"""Online relative-volatility state filter, fixed before any fitness feedback."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import platform
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
CONFIG=json.loads((HERE/'config.json').read_bytes())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()


def filter_returns(returns):
    """Predict then update; RMS reference excludes the return being evaluated."""
    values=np.asarray(returns,dtype=float)
    if values.ndim!=1:
        raise ValueError('one-dimensional daily returns required')
    base=pd.Series(values).pow(2).rolling(CONFIG['reference_days'],min_periods=CONFIG['reference_days']).mean().shift(1).to_numpy()
    result=[];probability=.5
    for i,value in enumerate(values):
        variance=base[i]
        available=bool(np.isfinite(value) and np.isfinite(variance) and variance>CONFIG['minimum_reference_variance'])
        if not available:
            probability=.5
        else:
            prior=CONFIG['stay_probability']*probability+(1-CONFIG['stay_probability'])*(1-probability)
            # Work in log space: no products of tiny normal densities.
            scales=np.asarray(CONFIG['relative_scales'])
            log_likelihood=-np.log(scales)-.5*(value/np.sqrt(variance)/scales)**2
            joint=np.log([1-prior,prior])+log_likelihood
            probability=float(np.exp(joint[1]-np.logaddexp(joint[0],joint[1])))
        result.append({'high_state_probability':probability,'available':available,
                       'reference_variance':float(variance) if np.isfinite(variance) else None,
                       'reason':'available' if available else 'missing_return_or_reference_warmup_or_zero_variance'})
    return result


def daily(frame):
    dates=pd.DatetimeIndex(pd.to_datetime(frame['Date'],errors='raise'))
    if dates.hasnans or dates.tz is not None or dates.has_duplicates or not dates.equals(dates.normalize()):
        raise ValueError('unique daily calendar dates required')
    if len(dates)>20000 or (len(dates) and (dates.max()-dates.min()).days>=20000):
        raise ValueError('bounded daily history required')
    values=pd.to_numeric(frame['Price'],errors='coerce').to_numpy(float)
    booleans=frame['Price'].map(lambda x:isinstance(x,(bool,np.bool_))).to_numpy(dtype=bool)
    valid=np.isfinite(values)&(values>0)&~booleans
    price=pd.Series(np.where(valid,values,np.nan),index=dates).sort_index()
    if price.empty:
        return pd.DatetimeIndex([]),[]
    price=price.reindex(pd.date_range(price.index.min(),price.index.max(),freq='D'))
    returns=np.log(price).diff().to_numpy()
    return price.index,filter_returns(returns)


def generate(frame,queries):
    queries=pd.DatetimeIndex(pd.to_datetime(queries))
    if queries.hasnans or queries.tz is not None or queries.has_duplicates or not queries.is_monotonic_increasing or not queries.equals(queries.normalize()):
        raise ValueError('ordered unique daily query dates required')
    dates,states=daily(frame);rows=[];diagnostics=[]
    for query in queries:
        cutoff=query-pd.Timedelta(days=CONFIG['price_lag_days'])
        position=dates.get_indexer([cutoff])[0]
        if position<0:
            state={'high_state_probability':.5,'available':False,'reference_variance':None,'reason':'cutoff_close_absent'}
        else:
            state=states[position]
        rows.append({'Date':query.date().isoformat(),'regime_state':100*state['high_state_probability']})
        diagnostics.append({'Date':query.date().isoformat(),'price_cutoff':cutoff.date().isoformat(),**state})
    return pd.DataFrame(rows,columns=['Date','regime_state']),diagnostics


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args();raw=args.input.read_bytes()
    if sha(raw)!=CONFIG['input_sha256']:
        raise ValueError('only admitted frozen BTC bytes accepted')
    frame=pd.read_csv(io.BytesIO(raw),usecols=['Date','Price'])
    if pd.to_datetime(frame.Date).max()>pd.Timestamp(CONFIG['cutoff']):
        raise ValueError('post-development input forbidden')
    scores,diag=generate(frame,pd.date_range(CONFIG['first_query'],CONFIG['cutoff'],freq='ME'))
    assert len(scores)==97 and np.isfinite(scores.regime_state).all()
    csv=scores.to_csv(index=False,float_format='%.17g').encode();diagnostics=canonical(diag)
    receipt={'schema':'fixed-price-state-generation-v1','config':CONFIG,'input_sha256':sha(raw),
             'producer_sha256':sha(Path(__file__).read_bytes()),'config_sha256':sha((HERE/'config.json').read_bytes()),
             'csv_sha256':sha(csv),'diagnostics_sha256':sha(diagnostics),'rows':len(scores),'available_n':sum(d['available'] for d in diag),
             'fitness_evaluated':False,'runtime':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__}}
    args.output_dir.mkdir(parents=True,exist_ok=False)
    (args.output_dir/'candidate.csv').write_bytes(csv);(args.output_dir/'diagnostics.json').write_bytes(diagnostics)
    (args.output_dir/'receipt.json').write_bytes(canonical(receipt))
    print(json.dumps({k:receipt[k] for k in ('csv_sha256','producer_sha256','config_sha256','rows','available_n','fitness_evaluated')},sort_keys=True))


if __name__=='__main__':
    main()
