"""Frozen price-only persistence hypothesis, no fitted labels or thresholds.

Sign order may distinguish persistent from alternating price paths despite equal
return inventory. Centering adjacent signs removes their separate marginal means.
High values mean persistent signs, not risk or opportunity. A failure on the fixed
24-month return benchmark falsifies usefulness of this scalar/readout combination;
it does not establish that every path-order model fails. Existing exposed BTC
history and overlapping targets prevent a fresh-holdout interpretation.

Daily Price observations retain the inherited unverified close/revision provenance.
Use only dates <=query minus two calendar days. Missing/invalid closes break pairs;
no interpolation, return across gaps, zero imputation, global scaling or tuning.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path

import numpy as np
import pandas as pd

CONFIG = json.loads(Path(__file__).with_name('config.json').read_text())


def state(prices, query):
    query = pd.Timestamp(query)
    cutoff = query - pd.Timedelta(days=CONFIG['close_lag_calendar_days'])
    calendar = pd.date_range(cutoff - pd.Timedelta(days=CONFIG['window_returns']), cutoff)
    values = pd.to_numeric(prices.loc[prices.index <= cutoff].reindex(calendar), errors='coerce').to_numpy(float)
    good = np.isfinite(values) & (values > 0)
    signs = np.full(len(values) - 1, np.nan)
    valid_returns = good[1:] & good[:-1]
    # Comparison avoids overflow, log cancellation and changes of measurement units.
    signs[valid_returns] = np.sign(values[1:][valid_returns] - values[:-1][valid_returns])
    paired = np.isfinite(signs[:-1]) & np.isfinite(signs[1:])
    x, y = signs[:-1][paired], signs[1:][paired]
    result = {'Date': query.date().isoformat(), 'sign_persistence': CONFIG['neutral'],
              'available': False, 'status': 'insufficient_pairs', 'valid_pairs': len(x),
              'cutoff': cutoff.date().isoformat(), 'positive_signs': int(np.sum(signs > 0)),
              'negative_signs': int(np.sum(signs < 0)), 'zero_signs': int(np.sum(signs == 0))}
    if len(x) < CONFIG['minimum_valid_adjacent_pairs']:
        return result
    x = x - x.mean()
    y = y - y.mean()
    denominator = float(np.sqrt(np.dot(x, x) * np.dot(y, y)))
    if denominator == 0:
        result['status'] = 'constant_sign_marginal'
        return result
    correlation = float(np.dot(x, y) / denominator)
    result.update(sign_persistence=float((np.clip(correlation, -1, 1) + 1) / 2),
                  available=True, status='available')
    return result


def generate(frame, queries):
    dates = pd.to_datetime(frame['Date'], errors='raise')
    if dates.dt.tz is not None or not dates.eq(dates.dt.normalize()).all() or dates.duplicated().any() or not dates.is_monotonic_increasing:
        raise ValueError('dates must be unique ordered naive midnight calendar dates')
    prices = pd.Series(frame['Price'].to_numpy(), index=pd.DatetimeIndex(dates))
    return pd.DataFrame([state(prices, query) for query in queries])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    if hashlib.sha256(raw).hexdigest() != CONFIG['input_sha256']:
        raise ValueError('unregistered input bytes')
    queries = pd.date_range(CONFIG['query_start'], CONFIG['query_end'], freq='ME')
    result = generate(pd.read_csv(io.BytesIO(raw)), queries)
    assert len(result) == 97 and np.isfinite(result.sign_persistence).all()
    args.output_dir.mkdir(parents=True, exist_ok=False)
    result.to_csv(args.output_dir / 'candidate.csv', index=False, float_format='%.17g')
    diagnostics = {'config': CONFIG, 'input_sha256': hashlib.sha256(raw).hexdigest(),
                   'generator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                   'config_sha256': hashlib.sha256(Path(__file__).with_name('config.json').read_bytes()).hexdigest(),
                   'csv_sha256': hashlib.sha256((args.output_dir / 'candidate.csv').read_bytes()).hexdigest(),
                   'availability_counts': result.status.value_counts().to_dict()}
    (args.output_dir / 'diagnostics.json').write_text(json.dumps(diagnostics, indent=2) + '\n')


if __name__ == '__main__':
    main()
