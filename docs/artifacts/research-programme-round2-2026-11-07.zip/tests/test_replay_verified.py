import importlib.util,json,shutil,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
PACKET=ROOT
spec=importlib.util.spec_from_file_location('replay',ROOT/'replay-verified.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class ReplayTests(unittest.TestCase):
 def fixture(self,root):
  for name in ['replay-generators.py','btc_daily.csv']:shutil.copyfile(PACKET/name,root/name)
  shutil.copytree(PACKET/'generators',root/'generators');(root/'reproduced').mkdir();shutil.copyfile(PACKET/'reproduced/reproduction.json',root/'reproduced/reproduction.json');shutil.copyfile(ROOT/'owned_indicator_input.py',root/'owned_indicator_input.py')
 def test_identity_matrix_before_any_producer(self):
  for target in ['generators/persistence/producer.py','generators/recovery/config.json','owned_indicator_input.py','replay-generators.py','btc_daily.csv','generators/regime/worker.csv','runtime']:
   with self.subTest(target=target),tempfile.TemporaryDirectory() as td:
    root=Path(td);self.fixture(root)
    if target=='runtime':
     p=root/'reproduced/reproduction.json';r=json.loads(p.read_text());r['runtime']['python']='0.0';p.write_text(json.dumps(r))
    else:
     p=root/target;p.write_bytes(p.read_bytes()+b'\n') # producer remains behaviorally identical
    with patch.object(m,'load',side_effect=AssertionError('Python executed before verification')) as loader:
     with self.assertRaises(ValueError):m.execute(m.capture(root,root/'owned_indicator_input.py'),root/'result')
     loader.assert_not_called()
 def test_captured_bytes_survive_original_path_replacement(self):
  with tempfile.TemporaryDirectory() as td:
   root=Path(td);self.fixture(root);owned=m.capture(root,root/'owned_indicator_input.py')
   (root/'generators/persistence/producer.py').write_text("raise RuntimeError('reopened source')")
   (root/'generators/persistence/config.json').write_text('{}');(root/'btc_daily.csv').write_text('bad')
   m.execute(owned,root/'result')
   for name in m.NAMES:self.assertEqual((root/'result'/name/'candidate.csv').read_bytes(),owned['candidates'][name]['worker.csv'])
if __name__=='__main__':unittest.main()
