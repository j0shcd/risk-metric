import hashlib,json,unittest
from datetime import date,timedelta
from research import macro_vintages as m


def row(obs,start,end,value):return {'date':obs,'realtime_start':start,'realtime_end':end,'value':value}

def pages(rows,series='DFII10',start='2014-01-01',end='9999-12-31',limit=100,obs_start='2014-01-01',obs_end='2022-12-31'):
    raw=[];manifest=[]
    for offset in range(0,max(1,len(rows)),limit):
        request={'realtime_start':start,'realtime_end':end,'observation_start':obs_start,'observation_end':obs_end,'output_type':1,'offset':offset,'limit':limit}
        body={**request,'units':'lin','file_type':'json','order_by':'observation_date','sort_order':'asc','count':len(rows),'observations':rows[offset:offset+limit]}
        payload=json.dumps(body).encode();raw.append(payload);manifest.append({'series_id':series,'request':request,'sha256':hashlib.sha256(payload).hexdigest()})
    return raw,manifest

def parsed(rows,**kwargs):
    raw,manifest=pages(rows,**kwargs);return m.parse_pages(raw,manifest)[kwargs.get('series','DFII10')]

def values(snapshot):return {r['observation_date']:r['value'] for r in snapshot['history'] if r['status']!='no_interval'}

FIXTURE=[row('2014-10-01','2014-11-01','2014-11-30','90'),row('2014-10-01','2014-12-05','9999-12-31','91'),
 row('2014-11-01','2014-11-15','2014-12-29','100'),row('2014-11-01','2014-12-30','9999-12-31','110'),
 row('2014-12-01','2014-12-31','2015-01-14','200'),row('2014-12-01','2015-01-15','2015-01-19','.'),
 row('2014-12-01','2015-01-20','9999-12-31','205')]

class VintageTests(unittest.TestCase):
    def test_independent_inclusive_interval_oracle(self):
        series=parsed(FIXTURE,limit=2)
        for query in ['2014-12-03','2014-12-31','2015-01-01','2015-01-02','2015-01-16','2015-01-17','2015-01-21','2015-01-22']:
            q=date.fromisoformat(query);asof=q-timedelta(days=2)
            expected={r['date']:None if r['value']=='.' else float(r['value']) for r in FIXTURE
                      if date.fromisoformat(r['date'])<=q and date.fromisoformat(r['realtime_start'])<=asof<=date.fromisoformat(r['realtime_end'])}
            actual=m.select_snapshot(series,query)
            self.assertEqual(values(actual),expected)
            self.assertEqual(actual['finite_n'],sum(v is not None for v in expected.values()))
        self.assertIsNone(values(m.select_snapshot(series,'2015-01-17'))['2014-12-01'])
        self.assertNotIn('2014-10-01',values(m.select_snapshot(series,'2014-12-03')))

    def test_future_revision_and_old_end_update_invariance(self):
        original=[row('2014-11-01','2014-12-01','9999-12-31','10')]
        revised=[row('2014-11-01','2014-12-01','2015-01-31','10'),row('2014-11-01','2015-02-01','9999-12-31','999'),row('2014-10-01','2015-02-01','9999-12-31','888')]
        a,b=parsed(original),parsed(revised)
        for query in ('2014-12-03','2014-12-31','2015-01-22','2015-02-02'):
            self.assertEqual(m.select_snapshot(a,query)['history'],m.select_snapshot(b,query)['history'])
        self.assertEqual(values(m.select_snapshot(b,'2015-02-03'))['2014-11-01'],999.)

    def test_clipped_blocks_and_empty_coverage(self):
        raw1,meta1=pages([row('2014-01-01','2014-01-01','2014-12-31','1')],end='2014-12-31')
        raw2,meta2=pages([row('2014-01-01','2015-01-01','2015-12-31','2')],start='2015-01-01',end='2015-12-31')
        series=m.parse_pages(raw1+raw2,meta1+meta2)['DFII10']
        self.assertEqual(values(m.select_snapshot(series,'2015-01-02'))['2014-01-01'],1.)
        self.assertEqual(values(m.select_snapshot(series,'2015-01-03'))['2014-01-01'],2.)
        self.assertEqual(m.select_snapshot(series,'2016-01-03')['coverage_status'],'uncovered_archive_day')
        empty={'series_id':'DFII10','status':'no_archived_vintages','request':{**meta1[0]['request']}}
        series=m.parse_pages([], [empty])['DFII10']
        self.assertEqual(m.select_snapshot(series,'2014-12-31')['coverage_status'],'no_archived_vintages')
        with self.assertRaises(ValueError):m.parse_pages(raw1,[empty,*meta1])

    def test_missing_gap_future_observation_and_endpoint_age(self):
        series=parsed([row('2014-01-01','2014-12-29','9999-12-31','3'),row('2015-01-01','2014-12-29','9999-12-31','4')])
        snap=m.select_snapshot(series,'2014-12-31')
        self.assertEqual(values(snap),{'2014-01-01':3.});self.assertEqual(snap['latest_observation_age_days'],364)
        self.assertEqual(snap['history'][-1]['status'],'no_interval')
        self.assertEqual(snap['gap_n'],364)

    def test_exact_duplicates_and_conflicts_across_pages(self):
        r=FIXTURE[0]
        series=parsed([r,r],limit=1);self.assertEqual(series.blocks[0].duplicate_count,1)
        self.assertEqual(values(m.select_snapshot(series,'2014-11-03')),{'2014-10-01':90.})
        for bad in [{**r,'value':'99'}, {**r,'realtime_start':'2014-11-02'}, {**r,'realtime_end':'2014-11-29'}]:
            for rows in ([r,bad],[bad,r]):
                with self.assertRaises(ValueError):parsed(rows,limit=1)

    def test_schema_hash_date_domain_pagination(self):
        r=row('2014-11-01','2014-12-01','9999-12-31','-2.5')
        self.assertEqual(values(m.select_snapshot(parsed([r]),'2014-12-03'))['2014-11-01'],-2.5)
        for field,value in [('date','2014-02-30'),('realtime_start','2013-01-01'),('value','NaN'),('value','inf'),('value',True),('value','')]:
            with self.assertRaises(ValueError):parsed([{**r,field:value}])
        for series in ('DTWEXBGS','WALCL','RRPONTSYD'):
            with self.assertRaises(ValueError):parsed([r],series=series)
        raw,meta=pages([r]);meta[0]['sha256']='0'*64
        with self.assertRaises(ValueError):m.parse_pages(raw,meta)
        raw,meta=pages(FIXTURE,limit=2)
        with self.assertRaises(ValueError):m.parse_pages(raw[:-1],meta[:-1])
        with self.assertRaises(ValueError):m.parse_pages(raw+raw[:1],meta+meta[:1])
        for field,value in [('offset',3),('count',999),('realtime_start','2013-01-01'),('units','pch'),('series_id','WALCL')]:
            one,manifest=pages([r]);body=json.loads(one[0]);body[field]=value;one[0]=json.dumps(body).encode();manifest[0]['sha256']=hashlib.sha256(one[0]).hexdigest()
            with self.assertRaises(ValueError):m.parse_pages(one,manifest)

    def test_owned_bytes_and_no_file_reopen(self):
        from pathlib import Path
        from unittest.mock import patch
        raw,meta=pages(FIXTURE)
        with patch.object(Path,'read_bytes',side_effect=AssertionError('must not reopen')):
            selected=m.select_snapshot(m.parse_pages(raw,meta)['DFII10'],'2015-01-22')
        self.assertEqual(values(selected)['2014-12-01'],205.)
        self.assertEqual(selected['source_sha256'],[hashlib.sha256(raw[0]).hexdigest()])

    def test_full_history_calendar_and_query_inventory(self):
        start=date(2009,12,31);end=date(2014,12,31)
        rows=[row((start+timedelta(days=i)).isoformat(),(start+timedelta(days=i)).isoformat(),'9999-12-31','1') for i in range((end-start).days+1)]
        snap=m.select_snapshot(parsed(rows,start='2009-12-31',obs_start='2009-12-31'),'2014-12-31')
        self.assertEqual(len(snap['history']),1827);self.assertEqual(snap['finite_n'],1825);self.assertEqual(snap['gap_n'],2)
        import calendar
        empty=m.parse_pages([], [{'series_id':'DFII10','status':'no_archived_vintages','request':{'realtime_start':'2007-01-01','realtime_end':'2022-12-31','observation_start':'2007-01-01','observation_end':'2022-12-31','output_type':1}}])['DFII10']
        queries=[f'{year}-{month:02}-{calendar.monthrange(year,month)[1]}' for year in range(2012,2023) for month in range(1,13)]
        self.assertEqual(len([m.select_snapshot(empty,q) for q in queries]),132)
        self.assertEqual(len([q for q in queries if q>='2014-12-31']),97)

if __name__=='__main__':unittest.main()
