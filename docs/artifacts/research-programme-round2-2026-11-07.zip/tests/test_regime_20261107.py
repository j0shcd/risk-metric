import importlib.util
from pathlib import Path
import unittest
import numpy as np
import pandas as pd

PATH=Path(__file__).resolve().parents[1]/'research/candidates/regime_20261107/producer.py'
spec=importlib.util.spec_from_file_location('regime_candidate',PATH);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)


def prices():
    dates=pd.date_range('2011-01-01','2022-12-31');t=np.arange(len(dates))
    returns=.01*np.sin(t/2.3)*(1+.8*np.sin(t/131))
    return pd.DataFrame({'Date':dates,'Price':np.exp(5+np.cumsum(returns))})


class RegimeTests(unittest.TestCase):
    def test_prefix_and_future_shock_warmup_boundaries(self):
        frame=prices();days=[frame.Date.iloc[n] for n in (364,365,366,367,800,1900,3500)]
        full,diags=p.generate(frame,days)
        for i,day in enumerate(days):
            prefix=frame.loc[frame.Date<=day]
            got,d=p.generate(prefix,days[:i+1]);pd.testing.assert_frame_equal(got,full.iloc[:i+1].reset_index(drop=True));self.assertEqual(d,diags[:i+1])
            shock=frame.copy();shock.loc[shock.Date>=day,'Price']=1e100
            changed,cd=p.generate(shock,days[:i+1]);pd.testing.assert_frame_equal(changed,got);self.assertEqual(cd,d)

    def test_independent_bayes_recurrence(self):
        values=.01*np.sin(np.arange(470)/2.7);actual=p.filter_returns(values);prob=.5
        for i,r in enumerate(values):
            if i<365:
                self.assertEqual(actual[i]['high_state_probability'],.5);self.assertFalse(actual[i]['available']);continue
            variance=np.mean(values[i-365:i]**2);prior=.99*prob+.01*(1-prob)
            low=np.exp(-.5*r*r/(variance*.25))/.5
            high=np.exp(-.5*r*r/(variance*4))/2
            prob=prior*high/(prior*high+(1-prior)*low)
            self.assertAlmostEqual(actual[i]['high_state_probability'],prob,places=13)

    def test_synthetic_sustained_high_then_low_state(self):
        values=np.tile([.01,-.01],300).tolist()+np.tile([.003,-.003],20).tolist()+np.tile([.04,-.04],10).tolist()+np.tile([.003,-.003],20).tolist()
        result=p.filter_returns(values)
        self.assertLess(result[639]['high_state_probability'],.2)
        self.assertGreater(result[659]['high_state_probability'],.9)
        self.assertLess(result[-1]['high_state_probability'],.1)
        # Sign symmetry is deliberate: this is state information, not direction.
        flipped=p.filter_returns(-np.array(values));self.assertEqual(result,flipped)

    def test_current_shock_not_used_to_estimate_reference(self):
        values=np.tile([.01,-.01],250).astype(float);values[-1]=1.
        result=p.filter_returns(values)
        self.assertAlmostEqual(result[-1]['reference_variance'],.0001,places=15)
        self.assertGreater(result[-1]['high_state_probability'],.999)

    def test_missing_domain_reset_and_recovery(self):
        values=np.tile([.01,-.01],500).astype(float);values[500]=np.nan
        result=p.filter_returns(values)
        for i in (500,501,865):self.assertEqual(result[i]['high_state_probability'],.5);self.assertFalse(result[i]['available'])
        self.assertTrue(result[866]['available'])
        for value in (0.,-1.,np.inf,np.nan,True):
            frame=prices().astype({'Price':'object'});day=pd.Timestamp('2017-08-31');frame.loc[frame.Date==day-pd.Timedelta(days=1),'Price']=value
            score,d=p.generate(frame,[day]);self.assertEqual(score.regime_state.iloc[0],50.);self.assertFalse(d[0]['available'])
        frame=prices();frame=pd.concat([frame,frame.iloc[:1]])
        with self.assertRaises(ValueError):p.generate(frame,['2017-08-31'])

    def test_complete_support_empty_constant_and_label_exclusion(self):
        queries=pd.date_range('2014-12-31','2022-12-31',freq='ME');frame=prices()
        a,diag=p.generate(frame,queries);self.assertEqual(len(a),97);self.assertTrue(np.isfinite(a.regime_state).all())
        frame['future_return24m']=np.arange(len(frame))*1e30;frame['label_available']='2099-12-31'
        b,bd=p.generate(frame,queries);pd.testing.assert_frame_equal(a,b);self.assertEqual(diag,bd)
        for f in (frame.iloc[:0],frame.assign(Price=1.)):
            scores,d=p.generate(f,queries);self.assertTrue((scores.regime_state==50).all());self.assertTrue(all(not x['available'] for x in d))

if __name__=='__main__':unittest.main()
