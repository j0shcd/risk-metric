import unittest
import numpy as np
import pandas as pd
from research.candidates.recovery_20261107.generate import generate, COLUMN


class RecoveryTests(unittest.TestCase):
    def frame(self, suffix):
        values = [100.] * 731 + list(suffix)
        return pd.DataFrame({'Date': pd.date_range('2012-01-01', periods=len(values)), 'Price': values})

    def score(self, frame):
        q = frame.Date.iloc[-1] + pd.Timedelta(days=1)
        return generate(frame, [q]).iloc[0]

    def test_independent_simple_law_and_reset(self):
        # 100 -> 25 loses log4; 25 -> 50 recovers half that log loss.
        self.assertAlmostEqual(self.score(self.frame([25, 50]))[COLUMN], 50)
        self.assertEqual(self.score(self.frame([25]))[COLUMN], 0)
        self.assertEqual(self.score(self.frame([25, 100]))[COLUMN], 100)
        self.assertAlmostEqual(self.score(self.frame([25, 100, 50]))[COLUMN], 0)
        self.assertAlmostEqual(self.score(self.frame([100 / np.sqrt(2)]))[COLUMN], 50)

    def test_path_dependence_distinguishes_equal_current_drawdown(self):
        self.assertAlmostEqual(self.score(self.frame([50]))[COLUMN], 0)
        self.assertAlmostEqual(self.score(self.frame([25, 50]))[COLUMN], 50)

    def test_future_append_shock_and_query_day_exclusion(self):
        frame = self.frame([25, 50])
        q = frame.Date.iloc[-1] + pd.Timedelta(days=1)
        expected = generate(frame, [q])
        future = pd.DataFrame({'Date': pd.date_range(q, periods=3), 'Price': [1e300, np.nan, -1]})
        pd.testing.assert_frame_equal(expected, generate(pd.concat([frame, future], ignore_index=True), [q]))

    def test_scale_and_order_invariance(self):
        frame = self.frame([25, 50])
        expected = self.score(frame)[COLUMN]
        frame.Price *= 1e200
        self.assertAlmostEqual(self.score(frame)[COLUMN], expected, places=10)
        q = frame.Date.iloc[-1] + pd.Timedelta(days=1)
        self.assertAlmostEqual(generate(frame.iloc[::-1], [q]).iloc[0][COLUMN], expected, places=10)

    def test_neutral_domains(self):
        for change, flag in [(lambda x: x.iloc[1:], 'insufficient_history'),
                             (lambda x: x.drop(index=3), 'calendar_gap'),
                             (lambda x: x.assign(Price=-1), 'invalid_price')]:
            frame = self.frame([50]) if flag == 'insufficient_history' else self.frame([50, 60])
            if flag == 'insufficient_history': frame = frame.iloc[:731]
            row = self.score(change(frame))
            self.assertEqual(row.coverage, flag)
            self.assertEqual(row[COLUMN], 50)
        frame = self.frame([50])
        q = frame.Date.iloc[-1] + pd.Timedelta(days=2)
        self.assertEqual(generate(frame, [q]).iloc[0].coverage, 'stale')

    def test_common_calendar_coverage(self):
        frame = pd.DataFrame({'Date': pd.date_range('2012-01-01', '2022-12-31'), 'Price': 1.})
        out = generate(frame, pd.date_range('2014-12-31', '2022-12-31', freq='ME'))
        self.assertEqual(len(out), 97)
        self.assertTrue(out.coverage.eq('available').all())
        self.assertTrue(out[COLUMN].eq(100).all())


if __name__ == '__main__': unittest.main()
