import unittest
import hashlib
import json
import tempfile
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from research.candidates.persistence_20261107 import generator as g


def frame(signs):
    # Integer additive increments keep intended signs exact.
    return pd.DataFrame({'Date': pd.date_range('2019-01-01', periods=len(signs)+1),
                         'Price': 1000.0 + np.r_[0, np.cumsum(signs)]})


class PersistenceTests(unittest.TestCase):
    def test_order_mechanism_and_independent_transition_counts(self):
        alternating = np.tile([1, -1], 182)
        runs = np.r_[np.ones(182), -np.ones(182)]
        q = pd.Timestamp('2020-01-02')
        a, b = [g.generate(frame(s), [q]).iloc[0] for s in (alternating, runs)]
        self.assertTrue(a.available and b.available)
        self.assertLess(a.sign_persistence, .01)
        self.assertGreater(b.sign_persistence, .99)
        rng = np.random.default_rng(1907)
        signs = rng.choice([-1, 0, 1], 364)
        # Independent 3x3 contingency table, raw moment Pearson formula.
        counts = {(i,j): sum(x==i and y==j for x,y in zip(signs[:-1], signs[1:]))
                  for i in (-1,0,1) for j in (-1,0,1)}
        n=sum(counts.values());sx=sum(i*c for (i,j),c in counts.items());sy=sum(j*c for (i,j),c in counts.items())
        xy=sum(i*j*c for (i,j),c in counts.items());xx=sum(i*i*c for (i,j),c in counts.items());yy=sum(j*j*c for (i,j),c in counts.items())
        expected=(1+(n*xy-sx*sy)/np.sqrt((n*xx-sx*sx)*(n*yy-sy*sy)))/2
        self.assertAlmostEqual(g.generate(frame(signs),[q]).iloc[0].sign_persistence, expected, places=14)

    def test_prefix_append_future_poison_and_exact_lag(self):
        rng=np.random.default_rng(5);data=frame(rng.choice([-1,1],900))
        q=pd.Timestamp('2020-06-30');cut=q-pd.Timedelta(days=2)
        expected=g.generate(data,[q])
        pd.testing.assert_frame_equal(expected,g.generate(data[data.Date<=cut],[q]))
        poisoned=data.copy();poisoned.loc[poisoned.Date>cut,'Price']=np.nan
        pd.testing.assert_frame_equal(expected,g.generate(poisoned,[q]))
        # A suffix of persistent positive signs would change a whole-history fit.
        appended=pd.concat([data,pd.DataFrame({'Date':pd.date_range(data.Date.iloc[-1]+pd.Timedelta(days=1),periods=700),'Price':np.arange(2000,2700)})],ignore_index=True)
        pd.testing.assert_frame_equal(expected,g.generate(appended,[q]))
        shocked=data.copy();shocked.loc[shocked.Date>cut,'Price']=1e200
        pd.testing.assert_frame_equal(expected,g.generate(shocked,[q]))

    def test_domain_missing_and_units(self):
        data=frame(np.tile([1,-1],182));q=pd.Timestamp('2020-01-02')
        expected=g.generate(data,[q]);scaled=data.copy();scaled.Price*=1024
        pd.testing.assert_frame_equal(expected,g.generate(scaled,[q]))
        for prices in (np.ones(len(data)),np.arange(1,len(data)+1)):
            bad=data.copy();bad.Price=prices;r=g.generate(bad,[q]).iloc[0]
            self.assertFalse(r.available);self.assertEqual(r.sign_persistence,.5)
        bad=data.copy();bad.loc[100:200,'Price']=0
        self.assertFalse(g.generate(bad,[q]).iloc[0].available)
        self.assertFalse(g.generate(data.iloc[:200],[q]).iloc[0].available)
        with self.assertRaises(ValueError):g.generate(pd.concat([data,data.iloc[-1:]]),[q])

    def test_cli_uses_only_hashed_owned_bytes(self):
        data=frame(np.tile([1,-1],1500))
        raw=data.to_csv(index=False).encode()
        digest=hashlib.sha256(raw).hexdigest()
        with tempfile.TemporaryDirectory() as temp:
            source=Path(temp)/'prices.csv';source.write_bytes(raw)
            output=Path(temp)/'output'
            original_read=pd.read_csv
            def replaced_path_read(arg,*args,**kwargs):
                source.write_text('Date,Price\n2019-01-01,1\n')
                return original_read(arg,*args,**kwargs)
            with patch.dict(g.CONFIG,{'input_sha256':digest}), patch('sys.argv',['generator','--input',str(source),'--output-dir',str(output)]), patch.object(g.pd,'read_csv',side_effect=replaced_path_read):
                g.main()
            expected=g.generate(data,pd.date_range('2014-12-31','2022-12-31',freq='ME')).to_csv(index=False,float_format='%.17g').encode()
            self.assertEqual((output/'candidate.csv').read_bytes(),expected)
            self.assertEqual(json.loads((output/'diagnostics.json').read_text())['input_sha256'],digest)

    def test_declared_monthly_support(self):
        data=frame(np.tile([1,-1],1500));qs=pd.date_range('2014-12-31','2022-12-31',freq='ME')
        out=g.generate(data,qs)
        self.assertEqual(len(out),97);self.assertTrue(np.isfinite(out.sign_persistence).all())
        self.assertTrue(out.sign_persistence.between(0,1).all())
