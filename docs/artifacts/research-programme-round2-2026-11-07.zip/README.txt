Round two: three failed price-only hypotheses, fixed benchmark, 2026-11-07.
Authenticate this ZIP against its SHA256 in the canonical research record before executing Python.
No code here is a Python sandbox; only run reviewed, authenticated source.

Registered runtime: Python 3.12.16, NumPy 2.4.6, pandas 2.3.3.
From the unpacked directory, with that runtime:
  python replay-verified.py --packet . --output-dir NEW_DIRECTORY
  python audit-scores.py --packet . --source-root benchmark-code --output NEW_REPORT.json
  python -m unittest discover -s tests

The first command authenticates all recorded generator/input/helper/runtime identities
before executing any captured producer, then reproduces all three CSVs exactly.
The second independently reconstructs scalar values, outcome/readout arithmetic and
recorded comparisons. It does not train, call scorers or run new model trials.
Generative samples are not regenerated; the pre-existing audited atlas is retained.
The original capture controller and original audit script are preserved as historical
evidence. Use the verified/portable entrypoints above, not the historical scripts'
original absolute paths. Tests use synthetic data and actual captured price identities.

No newly retrieved FRED numerical payload or detailed numerical audit report is here.
Public macro audit is metadata/counts/hashes only; raw evidence remains quarantined.
Generic macro interval adapter is archived synthetic-only code, not an admitted feed.
The legacy raw macro bundle is deliberately omitted; manifest retains its receipt ID.
This packet replays candidate generation and recorded-score arithmetic, not a full
rebuild of the old reference atlas from all original inputs. Trial ledger is OPEN
with all three slots exhausted, no finalists and no later-period release.
All market history was previously exposed; no fresh-holdout/performance claim.
Undirected persistence/regime retain arbitrary higher_risk trial metadata; their
ordering diagnostics do not establish favorable risk ordering. No model promoted.
