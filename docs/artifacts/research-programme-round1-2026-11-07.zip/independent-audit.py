import hashlib,json,platform,subprocess
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path('/Users/josh/Documents/03_Projects/risk-metric');P=ROOT/'output/research-programme-round1-2026-11-07'
sha=lambda b:hashlib.sha256(b).hexdigest()
canon=lambda x:(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
digest=lambda x:sha(canon(x))
maxerr={'atoms':0.,'weights':0.,'loss':0.,'summary':0.,'frontier':0.};counts={'receipt_files':0,'candidate_predictions':0,'scored_candidate_predictions':0,'direct_reference_records':0,'trial_cells':0,'frontier_cells':0}
def check(a,b,category):
 if a is None or b is None:assert a is None and b is None;return
 delta=float(np.max(np.abs(np.asarray(a,dtype=float)-np.asarray(b,dtype=float))))
 maxerr[category]=max(maxerr[category],delta);assert delta<2e-11,(category,delta,a,b)
for receipt in P.rglob('receipt.json'):
 for name,h in json.loads(receipt.read_bytes())['files'].items():
  assert Path(name).name==name and sha((receipt.parent/name).read_bytes())==h
  counts['receipt_files']+=1
manifest=json.loads((P/'manifest.json').read_bytes());repro=json.loads((P/'generators/reproduction.json').read_bytes());atlas=json.loads((P/'benchmark_atlas.json').read_bytes())
assert len(atlas['models'])==17 and sha((P/'benchmark_atlas.json').read_bytes())==manifest['benchmark_atlas_sha256']=='22b67b6dc9ea4aaa661ff220a6dff372b7d2ef54de64044f6d6ab961e07834db'
assert atlas['atlas_id']==digest({k:v for k,v in atlas.items() if k!='atlas_id'})==manifest['benchmark_atlas_id']
assert manifest['runtime']=={'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__}
for name,h in manifest['code_hashes'].items():assert sha((ROOT/'research'/name).read_bytes())==h
bundle=json.loads((P/'bundle/manifest.json').read_bytes());assert bundle['cutoff']=='2022-12-31'
for name,info in bundle['sources'].items():assert sha((P/'bundle'/name).read_bytes())==info['development_sha256']
assert sha((P/'bundle/receipt.json').read_bytes())==manifest['bundle_receipt_sha256']
source=pd.read_csv(P/'bundle/development_scores.csv',index_col=0,parse_dates=True);price=source.btc_price;log=np.log(price)
assert price.index[-1]==pd.Timestamp('2022-12-31');dates=pd.date_range('2014-12-31','2022-12-31',freq='ME');date_strings=dates.strftime('%Y-%m-%d').tolist();assert manifest['support']==date_strings
context=np.array([[log[q]-log[q-pd.DateOffset(years=1)],np.diff(log.loc[q-pd.Timedelta(days=90):q]).std(ddof=1)] for q in dates]);bydate={d:i for i,d in enumerate(date_strings)}
TARGETS=['terminal_log_return','entry_adverse_log_loss','peak_drawdown_log_loss'];metrics=['crps','brier','coverage_50','coverage_80','width_50','width_80'];outcomes={}
for i,q in enumerate(dates):
 for h in (12,24,48):
  entry=q+pd.Timedelta(days=1);end=entry+pd.DateOffset(months=h);available=end+pd.Timedelta(days=1);values=None
  if end<=price.index[-1]:
   path=log.loc[entry:end].to_numpy();assert len(path)==(end-entry).days+1
   values=[path[-1]-path[0],path[0]-min(path),max(np.maximum.accumulate(path)-path)]
  outcomes[i,h]={'entry':entry.date().isoformat(),'end':end.date().isoformat(),'label_available':available.date().isoformat(),'values':values,'role':'development' if available<=price.index[-1] else 'pending'}
def pool(i,h):return [j for j in range(i) if outcomes[j,h]['values'] is not None and outcomes[j,h]['label_available']<date_strings[i]][-24:]
def weights(values,i,train):
 x=np.column_stack([context[train],np.asarray(values)[train]]);q=np.r_[context[i],values[i]];cuts=np.median(x,axis=0)
 contextmask=np.all((x[:,:2]>cuts[:2])==(q[:2]>cuts[:2]),axis=1)
 mask=contextmask&((x[:,2]>cuts[2])==(q[2]>cuts[2]));uniform=np.full(24,1/24)
 base=.5*uniform+.5*contextmask/sum(contextmask) if any(contextmask) else uniform
 candidate=.5*uniform+.5*mask/sum(mask) if any(mask) else base
 return candidate,base,cuts,int(sum(mask)),int(sum(contextmask))
def scores(atoms,w,y,target):
 a=np.array(atoms);w=np.array(w);assert np.isfinite(a).all() and min(w)>=0 and np.isclose(sum(w),1)
 ordered=np.argsort(a);x=a[ordered];cdf=np.cumsum(w[ordered]);event=(a<0) if target==TARGETS[0] else (a>np.log(2));prob=float(w@event)
 out={'event_probability':prob}
 for level,tail in [(50,.25),(80,.1)]:
  lo=x[min(np.searchsorted(cdf,tail),len(x)-1)];hi=x[min(np.searchsorted(cdf,1-tail),len(x)-1)]
  out['width_'+str(level)]=float(hi-lo);out['coverage_'+str(level)]=None if y is None else bool(lo<=y<=hi)
 if y is None:out.update(crps=None,brier=None)
 else:
  actual=bool(y<0 if target==TARGETS[0] else y>np.log(2));out['brier']=(prob-actual)**2
  out['crps']=float(w@abs(a-y)-.5*np.sum(np.outer(w,w)*abs(a[:,None]-a[None,:])))
 return out
refs=json.loads((P/'references.json').read_bytes());assert len(refs)==13 and digest(refs)==manifest['references_id']
refvalues={r['name']:np.array([v['value'] for v in r['values']]) for r in refs}
# Reconstruct all15 issued-CDF reference distributions from raw prices and fixed values.
atlas_maps={}
for model in atlas['models']:
 key=(model['name'],model['replica']);mapped={(r['date'],r['horizon'],r['target']):r for r in model['records']};assert len(mapped)==len(model['records']);atlas_maps[key]=mapped
 if model['kind']=='issued_cdf':
  for k,r in mapped.items():
   i=bydate[k[0]];h=k[1];t=TARGETS.index(k[2]);train=pool(i,h);assert len(train)==24
   atoms=np.array([outcomes[j,h]['values'][t] for j in train]);target=outcomes[i,h];y=target['values'][t] if target['role']=='development' else None
   assert r['role']==target['role'] and all(r[x]==target[x] for x in ('entry','end','label_available'));check(y,r['outcome'],'atoms')
   name=model['name'];v=refvalues[name.split(':',1)[1]] if name.startswith('direct_cdf:') else next(iter(refvalues.values()))
   candidate,base,*_=weights(v,i,train);w=np.full(24,1/24) if name=='unconditional' else base if name=='context' else candidate
   assert r['atoms_identity']['sha256']==sha(atoms.astype('<f8').tobytes());assert r['weights_identity']['sha256']==sha(np.array(w,dtype='<f8').tobytes())
   computed=scores(atoms,w,y,k[2])
   if y is not None:
    for metric in metrics:check(computed[metric],r[metric],'loss')
   else:
    check(computed['event_probability'],r['event_probability'],'loss')
    for level in ('50','80'):check(computed['width_'+level],r['intervals'][level][1]-r['intervals'][level][0],'loss')
   counts['direct_reference_records']+=1
 else:
  assert model['replica'] in (0,1)
  for r in mapped.values():
   assert r['sample_n']==8192 and r['score_interpretation']=='iid_predictive_law_draws'
   if r['status']=='scored':
    p=r['event_probability'];check(p*(1-p)/8191,r['brier_mc_correction'],'loss')
    check(r['empirical_crps']-r['crps_mc_correction'],r['crps'],'loss');check(r['empirical_brier']-r['brier_mc_correction'],r['brier'],'loss')
summary={};attempts=sorted((P/'attempts').iterdir());assert len(attempts)==manifest['global_budget']==3
for attempt in attempts:
 arm=attempt.name.split('--')[1];identity=repro[arm];directory=P/'generators'/arm
 outcome=json.loads((attempt/'outcome.json').read_bytes());request=json.loads((attempt/'request.json').read_bytes())
 assert outcome['status']=='completed' and request['worker']==arm and manifest['worker_budgets'][arm]==1
 for key,path in [('candidate',attempt/'candidate.csv'),('producer',attempt/'producer.bin'),('config',attempt/'config.bin')]:assert sha(path.read_bytes())==identity[key+'_sha256']
 assert (directory/'candidate.csv').read_bytes()==(attempt/'candidate.csv').read_bytes()
 assert (directory/identity['source_file']).read_bytes()==(attempt/'producer.bin').read_bytes();assert (directory/'config.json').read_bytes()==(attempt/'config.bin').read_bytes()
 for name,h in identity['inputs'].items():assert sha((P/'bundle'/name).read_bytes())==h
 rel='research/candidates/'+{'anomaly':'anomaly_20261107','learner':'learner_20261107','ensemble':'ensemble_20261107'}[arm]
 assert subprocess.check_output(['git','show',identity['frozen_commit']+':'+rel+'/'+identity['source_file']])==(attempt/'producer.bin').read_bytes()
 assert subprocess.check_output(['git','show',identity['frozen_commit']+':'+rel+'/config.json'])==(attempt/'config.bin').read_bytes()
 frame=pd.read_csv(attempt/'candidate.csv');assert frame.Date.tolist()==date_strings and len(frame)==identity['n']==97
 values=frame[identity['column']].to_numpy();assert np.isfinite(values).all()
 trial=json.loads((attempt/'trial.json').read_bytes());result=trial['result'];frontier=json.loads((attempt/'frontier.json').read_bytes())
 assert trial['candidate_csv_sha256']==identity['candidate_sha256'];assert [v['date'] for v in trial['candidate']['values']]==date_strings
 check(values,[v['value'] for v in trial['candidate']['values']],'weights')
 assert result['candidate_id']==digest(trial['candidate']);assert result['as_of']=='2022-12-31'
 assert outcome['candidate']==trial['candidate'] and outcome['campaign_id']==manifest['campaign_id']
 assert outcome['identity']['producer_sha256']==identity['producer_sha256'] and outcome['identity']['config_sha256']==identity['config_sha256']
 for k,v in atlas['identity'].items():assert result[k]==v
 computed={}
 for record in result['predictions']:
  k=(record['date'],record['horizon'],record['target']);assert k not in computed
  i=bydate[k[0]];h=k[1];t=TARGETS.index(k[2]);train=pool(i,h);assert len(train)==24
  assert record['train_dates']==[date_strings[j] for j in train];assert record['train_last_label_available']==max(outcomes[j,h]['label_available'] for j in train)
  w,base,cuts,nlocal,ncontext=weights(values,i,train)
  check(w,record['candidate_weights'],'weights');check(base,record['reference_weights'],'weights');check(cuts,record['thresholds'],'weights')
  assert record['candidate_cell_n']==nlocal and record['context_cell_n']==ncontext and record['candidate_fallback']==(nlocal==0) and record['context_fallback']==(ncontext==0)
  atoms=np.array([outcomes[j,h]['values'][t] for j in train]);check(atoms,record['atoms'],'atoms')
  target=outcomes[i,h];assert record['role']==target['role'] and all(record[x]==target[x] for x in ('entry','end','label_available'))
  y=target['values'][t] if target['role']=='development' else None;check(y,record['outcome'],'atoms')
  candidate=scores(atoms,w,y,k[2]);baseline=scores(atoms,base,y,k[2]);unconditional=scores(atoms,np.full(24,1/24),y,k[2])
  for prefix,calc in [('candidate',candidate),('reference',baseline),('unconditional',unconditional)]:check(calc['crps'],record[prefix+'_crps'],'loss')
  check(None if y is None else baseline['crps']-candidate['crps'],record['loss_improvement'],'loss')
  computed[k]={**candidate,'role':record['role'],'status':record['status']};counts['candidate_predictions']+=1;counts['scored_candidate_predictions']+=int(y is not None)
 for e in result['eligibility']:
  train=pool(bydate[e['date']],e['horizon']);assert e['forecast_available']==(len(train)==24)
  i=bydate[e['date']];h=e['horizon'];all_mature=[j for j in range(i) if outcomes[j,h]['values'] is not None and outcomes[j,h]['label_available']<date_strings[i]]
  assert e['mature_training_n']==len(all_mature)
 for cell in result['cells']:
  rr=[r for r in result['predictions'] if (r['role'],r['horizon'],r['target'])==(cell['role'],cell['horizon'],cell['target'])];scored=[r for r in rr if r['status']=='scored']
  assert cell['forecast_n']==len(rr) and cell['scored_n']==len(scored)
  assert cell['forecast_origins_id']==digest([r['date'] for r in rr]);assert cell['scored_origins_id']==digest([r['date'] for r in scored])
  for prefix in ('candidate','reference','unconditional'):check(np.mean([r[prefix+'_crps'] for r in scored]) if scored else None,cell[prefix+'_mean_crps'],'summary')
  check(np.mean([r['reference_crps']-r['candidate_crps'] for r in scored]) if scored else None,cell['mean_loss_improvement'],'summary');counts['trial_cells']+=1
 for cell in frontier['cells']:
  reference=atlas_maps[cell['reference'],cell['replica']];keys=[k for k,v in computed.items() if (v['role'],k[1],k[2])==(cell['role'],cell['horizon'],cell['target'])]
  selected=[k for k in keys if computed[k]['status']=='scored' and reference[k]['status']=='scored'];failed=[k for k in keys if reference[k]['status']=='numerical_failure'];expected=[k for k in keys if computed[k]['status']=='scored']
  complete=len(selected)==len(expected) and not failed
  assert cell['requested_n']==len(keys) and cell['scored_n']==len(selected) and cell['failure_n']==len(failed) and cell['unavailable_n']==len(keys)-len(selected)-len(failed)
  assert cell['scored_origins_id']==digest(sorted(k[0] for k in selected))
  for metric in metrics:
   cm=np.mean([computed[k][metric] for k in selected]) if complete and selected else None;rm=np.mean([reference[k][metric] for k in selected]) if complete and selected else None
   delta=np.mean([reference[k][metric]-computed[k][metric] for k in selected]) if complete and selected else None
   check(cm,cell['candidate'][metric],'frontier');check(rm,cell['reference_means'][metric],'frontier');check(delta,cell['reference_minus_candidate'][metric],'frontier')
  counts['frontier_cells']+=1
 for guard in frontier['mc_guards']:
  cells=[next(c for c in frontier['cells'] if c['reference']=='generative' and c['replica']==replica and all(c[k]==guard[k] for k in ('role','horizon','target'))) for replica in (0,1)]
  gains=[c['reference_minus_candidate'][guard['metric']] for c in cells];assert gains==guard['replica_gains']
  stable=all(g is not None and g>0 for g in gains) and abs(gains[0]-gains[1])<.2*min(gains)
  assert bool(stable)==guard['numerically_stable_gain']
 primary=next(c for c in result['cells'] if c['role']=='development' and c['horizon']==24 and c['target']=='terminal_log_return')
 summary[arm]={'primary24_crps':primary['candidate_mean_crps'],'unconditional24_crps':primary['unconditional_mean_crps'],'primary_fails_unconditional':primary['candidate_mean_crps']>=primary['unconditional_mean_crps'],'candidate_csv_sha256':identity['candidate_sha256']}
 if arm=='anomaly':
  subset=[c for c in frontier['cells'] if c['role']=='development' and c['horizon']==12 and c['target']=='peak_drawdown_log_loss']
  summary[arm]['secondary12_peak_dd_crps']=subset[0]['candidate']['crps'];summary[arm]['best_frontier12_peak_dd_crps']=min(c['reference_means']['crps'] for c in subset)
report={'status':'independent_arithmetic_audit_pass','campaign_id':manifest['campaign_id'],'atlas_sha256':manifest['benchmark_atlas_sha256'],'counts':counts,'max_abs_errors':maxerr,'candidates':summary,
 'reproduction_metadata_sha256':sha((P/'generators/reproduction.json').read_bytes()),'captured_controller_sha256':sha((P/'generators/controller.py').read_bytes()),
 'limitations':['No generators/models/scorers rerun. Reproduction hash consistency checked against frozen commits and owned inputs/outputs, not execution attestation.',
 'Generative native fair scores retained from hash-frozen atlas; algebra/corrections and paired aggregates checked, no Monte Carlo samples regenerated.',
 'Anomaly is semantically undirected despite generic higher_risk benchmark metadata; no directional claim. Secondary improvement cannot rescue failed primary.']}
Path('/private/tmp/research-round1-independent-audit-a.json').write_bytes(canon(report));print(json.dumps(report,indent=2))
