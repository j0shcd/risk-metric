# Benchmark frontier comparison

Completed measurement; no automatic promotion. Positive loss delta favors candidate; coverage/width are separate tradeoffs.

| Role | Months | Target | Reference | Replica | Scored / failed / unavailable | CRPS delta | Brier delta | 50% coverage delta / width delta | 80% coverage delta / width delta |
|---|---:|---|---|---:|---|---:|---:|---|---|
| development | 12 | terminal_log_return | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.009377 | 0.006427 | 0.020833 / 0.018920 | 0.062500 / 0.119657 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.005068 | 0.046145 | 0.104167 / 0.040339 | -0.020833 / 0.022821 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.010174 | 0.023848 | -0.020833 / -0.021356 | 0.000000 / 0.010605 |
| development | 24 | terminal_log_return | direct_cdf:dca_risk | None | 24 / 0 / 0 | -0.106284 | 0.000000 | 0.166667 / 0.068502 | 0.000000 / -0.010814 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | 0.019337 | 0.016670 | -0.083333 / 0.072912 | 0.000000 / 0.018903 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | 0.002075 | -0.003142 | 0.125000 / 0.187656 | 0.041667 / 0.057660 |
| development | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.032816 | 0.010582 | 0.000000 / 0.023582 | 0.062500 / 0.142405 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.012576 | 0.045767 | 0.083333 / 0.021751 | -0.020833 / 0.024308 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.010892 | 0.007898 | -0.083333 / -0.033791 | 0.000000 / 0.030898 |
| development | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.103786 | 0.000000 | 0.166667 / 0.012017 | 0.000000 / -0.061440 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | 0.011361 | 0.010665 | -0.041667 / 0.074821 | 0.000000 / 0.000232 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | 0.012734 | -0.007917 | 0.041667 / 0.112745 | 0.041667 / 0.057660 |
| development | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.013906 | 0.043300 | 0.041667 / 0.046202 | 0.062500 / 0.102071 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.019545 | 0.096589 | 0.083333 / 0.029958 | -0.041667 / 0.018381 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.007768 | 0.006161 | -0.041667 / 0.014521 | 0.020833 / 0.041798 |
| development | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | -0.090246 | 0.000000 | 0.166667 / 0.132977 | 0.000000 / 0.096940 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | 0.018361 | 0.012121 | 0.000000 / 0.069738 | 0.000000 / 0.018903 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | -0.004820 | -0.001790 | 0.250000 / 0.245226 | 0.083333 / 0.083404 |
| development | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | -0.008129 | 0.003533 | 0.020833 / -0.034450 | 0.062500 / 0.025650 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | 0.010334 | 0.039761 | 0.062500 / -0.006918 | -0.020833 / 0.023160 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | 0.012947 | 0.033640 | -0.041667 / -0.053788 | -0.041667 / -0.041998 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.058066 | 0.000000 | 0.208333 / 0.121177 | 0.000000 / 0.048650 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | 0.014817 | 0.009006 | 0.000000 / 0.058426 | 0.000000 / 0.018903 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.011160 | 0.009760 | 0.166667 / 0.203733 | 0.083333 / 0.083404 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.051721 | 0.010582 | 0.000000 / 0.025220 | 0.041667 / 0.118801 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.014067 | 0.048190 | 0.062500 / 0.012217 | -0.020833 / 0.021166 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.008230 | 0.004456 | -0.083333 / -0.027846 | 0.020833 / 0.036427 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.110391 | 0.000000 | 0.166667 / -0.067205 | 0.000000 / -0.047483 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | 0.015480 | 0.013021 | -0.041667 / 0.070484 | 0.000000 / 0.015354 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | 0.018059 | -0.016163 | -0.041667 / 0.039124 | 0.000000 / 0.020586 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | -0.016156 | 0.019460 | 0.020833 / 0.176486 | 0.083333 / 0.189748 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | 0.000985 | 0.034330 | 0.125000 / 0.079313 | 0.000000 / 0.033304 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | 0.000867 | 0.003797 | 0.041667 / -0.005348 | 0.020833 / 0.053262 |
| development | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.086232 | 0.000000 | 0.166667 / 0.127868 | 0.000000 / 0.096940 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | 0.016141 | 0.010642 | 0.041667 / 0.080216 | 0.000000 / 0.018903 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.004067 | -0.001790 | 0.250000 / 0.240229 | 0.083333 / 0.078407 |
| development | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | -0.016156 | 0.019460 | 0.020833 / 0.176486 | 0.083333 / 0.189748 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | 0.000985 | 0.034330 | 0.125000 / 0.079313 | 0.000000 / 0.033304 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | 0.000867 | 0.003797 | 0.041667 / -0.005348 | 0.020833 / 0.053262 |
| development | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.086232 | 0.000000 | 0.166667 / 0.127868 | 0.000000 / 0.096940 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | 0.016141 | 0.010642 | 0.041667 / 0.080216 | 0.000000 / 0.018903 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.004067 | -0.001790 | 0.250000 / 0.240229 | 0.083333 / 0.078407 |
| development | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.001148 | 0.000611 | 0.041667 / 0.133338 | 0.062500 / 0.042969 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.014162 | 0.032407 | 0.083333 / 0.044948 | -0.020833 / 0.011081 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.015144 | 0.008458 | -0.062500 / -0.037460 | 0.000000 / 0.008403 |
| development | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | -0.070834 | 0.000000 | 0.041667 / -0.013468 | 0.000000 / -0.028342 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | 0.004850 | 0.000000 | 0.000000 / 0.021606 | 0.000000 / 0.018833 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | 0.009122 | -0.022674 | 0.166667 / 0.088355 | 0.041667 / 0.014159 |
| development | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | -0.021071 | 0.005679 | 0.000000 / -0.135724 | 0.041667 / 0.039041 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | 0.012463 | 0.049845 | 0.062500 / -0.003415 | -0.020833 / 0.023746 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | 0.010368 | 0.009872 | -0.083333 / -0.050072 | -0.020833 / 0.041158 |
| development | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | -0.056739 | 0.000000 | 0.208333 / 0.124988 | 0.000000 / 0.100712 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | 0.018496 | 0.013021 | 0.041667 / 0.077431 | 0.000000 / 0.018903 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | -0.027193 | -0.004936 | 0.166667 / 0.121997 | 0.083333 / 0.083404 |
| development | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.050978 | 0.008498 | 0.020833 / 0.088362 | 0.041667 / 0.024163 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.023066 | 0.063998 | 0.083333 / 0.033273 | -0.041667 / 0.013796 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.030306 | 0.049865 | -0.083333 / -0.042241 | -0.062500 / -0.005199 |
| development | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | -0.035883 | 0.000000 | 0.083333 / 0.097117 | 0.000000 / 0.027298 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | 0.014226 | 0.005642 | 0.000000 / 0.062617 | 0.000000 / 0.018833 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | 0.005647 | 0.029844 | 0.125000 / 0.134131 | 0.041667 / 0.031685 |
| development | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.050446 | 0.025897 | -0.020833 / 0.008778 | 0.000000 / 0.030983 |
| development | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.006314 | 0.071371 | 0.104167 / 0.031953 | -0.041667 / -0.005871 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.006305 | 0.019257 | 0.020833 / 0.025564 | 0.020833 / 0.021151 |
| development | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | -0.128152 | 0.000000 | 0.083333 / -0.218732 | 0.000000 / -0.073859 |
| development | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | 0.056213 | 0.039427 | -0.083333 / 0.027205 | -0.083333 / 0.014196 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | 0.032366 | -0.007378 | 0.208333 / 0.156387 | 0.041667 / 0.056415 |
| development | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | 0.025533 | 0.030047 | 0.041667 / 0.158631 | 0.083333 / 0.105363 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | -0.001079 | 0.035008 | 0.104167 / 0.064145 | 0.000000 / 0.031816 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | -0.002753 | -0.004331 | 0.062500 / -0.016713 | 0.000000 / 0.029150 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | -0.072504 | 0.000000 | 0.125000 / 0.027356 | 0.000000 / 0.039401 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | 0.018170 | 0.010642 | -0.041667 / 0.067979 | 0.000000 / 0.018833 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | -0.003576 | 0.017795 | 0.208333 / 0.192097 | 0.083333 / 0.078407 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | -0.060071 | 0.023582 | 0.062500 / -0.121790 | 0.083333 / 0.103152 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | 0.017773 | 0.050090 | 0.083333 / -0.036632 | -0.020833 / 0.015681 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | 0.028928 | 0.021485 | -0.062500 / -0.000339 | 0.000000 / 0.026769 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | -0.008378 | 0.000000 | 0.041667 / 0.129554 | 0.000000 / 0.141796 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | 0.009698 | 0.000000 | 0.083333 / 0.012572 | 0.000000 / 0.018903 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | -0.012104 | 0.008464 | 0.208333 / 0.178795 | 0.083333 / 0.065993 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | context | None | 48 / 0 / 0 | -0.016156 | 0.019460 | 0.020833 / 0.176486 | 0.083333 / 0.189748 |
| development | 12 | entry_adverse_log_loss | context | None | 48 / 0 / 0 | 0.000985 | 0.034330 | 0.125000 / 0.079313 | 0.000000 / 0.033304 |
| development | 12 | peak_drawdown_log_loss | context | None | 48 / 0 / 0 | 0.000867 | 0.003797 | 0.041667 / -0.005348 | 0.020833 / 0.053262 |
| development | 24 | terminal_log_return | context | None | 24 / 0 / 0 | -0.086232 | 0.000000 | 0.166667 / 0.127868 | 0.000000 / 0.096940 |
| development | 24 | entry_adverse_log_loss | context | None | 24 / 0 / 0 | 0.016141 | 0.010642 | 0.041667 / 0.080216 | 0.000000 / 0.018903 |
| development | 24 | peak_drawdown_log_loss | context | None | 24 / 0 / 0 | -0.004067 | -0.001790 | 0.250000 / 0.240229 | 0.083333 / 0.078407 |
| development | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | unconditional | None | 48 / 0 / 0 | -0.012445 | 0.078423 | 0.041667 / 0.232941 | 0.083333 / 0.278024 |
| development | 12 | entry_adverse_log_loss | unconditional | None | 48 / 0 / 0 | 0.009654 | 0.055991 | 0.125000 / 0.117295 | 0.020833 / 0.067142 |
| development | 12 | peak_drawdown_log_loss | unconditional | None | 48 / 0 / 0 | 0.019368 | 0.026882 | -0.041667 / 0.074815 | 0.020833 / 0.009884 |
| development | 24 | terminal_log_return | unconditional | None | 24 / 0 / 0 | -0.208958 | 0.002658 | 0.416667 / 0.331016 | 0.041667 / 0.200789 |
| development | 24 | entry_adverse_log_loss | unconditional | None | 24 / 0 / 0 | 0.027156 | 0.037489 | -0.083333 / 0.193408 | 0.166667 / 0.160592 |
| development | 24 | peak_drawdown_log_loss | unconditional | None | 24 / 0 / 0 | -0.000629 | -0.065480 | 0.208333 / 0.399759 | 0.083333 / 0.129972 |
| development | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 0 | 48 / 0 / 0 | -0.216010 | 0.019371 | 0.104167 / -0.081592 | 0.166667 / -0.187274 |
| development | 12 | entry_adverse_log_loss | generative | 0 | 48 / 0 / 0 | -0.046052 | -0.013099 | -0.083333 / -0.035185 | -0.020833 / -0.018784 |
| development | 12 | peak_drawdown_log_loss | generative | 0 | 48 / 0 / 0 | 0.065328 | 0.291719 | -0.187500 / 0.054933 | -0.145833 / 0.135771 |
| development | 24 | terminal_log_return | generative | 0 | 24 / 0 / 0 | 0.165158 | 0.094137 | -0.083333 / 0.289592 | -0.375000 / 0.392699 |
| development | 24 | entry_adverse_log_loss | generative | 0 | 24 / 0 / 0 | -0.067675 | -0.014050 | 0.125000 / 0.295922 | 0.250000 / 0.465326 |
| development | 24 | peak_drawdown_log_loss | generative | 0 | 24 / 0 / 0 | -0.026187 | 0.234753 | 0.166667 / 0.154135 | 0.041667 / 0.142211 |
| development | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 1 | 48 / 0 / 0 | -0.217707 | 0.018944 | 0.083333 / -0.086910 | 0.187500 / -0.190578 |
| development | 12 | entry_adverse_log_loss | generative | 1 | 48 / 0 / 0 | -0.046303 | -0.013798 | -0.083333 / -0.035963 | -0.020833 / -0.021856 |
| development | 12 | peak_drawdown_log_loss | generative | 1 | 48 / 0 / 0 | 0.064827 | 0.291459 | -0.187500 / 0.055022 | -0.166667 / 0.134387 |
| development | 24 | terminal_log_return | generative | 1 | 24 / 0 / 0 | 0.166596 | 0.095399 | -0.041667 / 0.291274 | -0.375000 / 0.381152 |
| development | 24 | entry_adverse_log_loss | generative | 1 | 24 / 0 / 0 | -0.067380 | -0.013410 | 0.083333 / 0.296426 | 0.250000 / 0.466750 |
| development | 24 | peak_drawdown_log_loss | generative | 1 | 24 / 0 / 0 | -0.025245 | 0.234351 | 0.125000 / 0.156010 | 0.041667 / 0.141041 |
| development | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |

MC guard (numerical only, not significance):
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [-0.21600957545428398, -0.21770670276135318], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.019370508523206587, 0.01894435531468631], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.04605236955829592, -0.04630310209508121], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.013099228187671112, -0.01379804818855973], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [0.06532823671604687, 0.06482668741918864], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.2917187265912815, 0.2914588335159931], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [0.16515768690117938, 0.16659559632661436], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.09413701770599477, 0.09539876736477615], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.06767548727081872, -0.06737973000549498], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.014049774151845107, -0.013409740820037841], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [-0.026186673448997378, -0.025245427984915258], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.23475252415422077, 0.23435093105740845], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}

Fixed-direction ordering, separate from forecast quality:
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': 0.014559076642705277, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.027931377842113275, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': -0.06196019219245392, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': 0.043121744163611815, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.059071868016668146, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.06416562591699153, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': 0.03234910985670864, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.06679701213074998, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': -0.2875252833408983, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
