"""Summarize fixed recorded scores; no model fitting or additional selection."""
import json
from collections import defaultdict
from pathlib import Path
import numpy as np
from research.market_dataset import canonical_bytes
root=Path('/Users/josh/Documents/03_Projects/risk-metric');job=root/'output/research-programme-round1-2026-11-07'
atlas=json.loads((job/'benchmark_atlas.json').read_bytes());key=lambda r:(r['date'],r['horizon'],r['target'],r['role'])
base={key(r) for r in atlas['models'][0]['records'] if r['status']=='scored' and r['role']=='development'}
references=[]
for model in atlas['models']:
 records=[r for r in model['records'] if key(r) in base and r['status']=='scored'];cells=[]
 for h in (12,24,48):
  for target in ['terminal_log_return','entry_adverse_log_loss','peak_drawdown_log_loss']:
   rs=[r for r in records if r['horizon']==h and r['target']==target]
   cells.append({'horizon':h,'target':target,'n':len(rs),'mean_crps':None if not rs else float(np.mean([r['crps'] for r in rs])),'mean_brier':None if not rs else float(np.mean([r['brier'] for r in rs])),'coverage_80':None if not rs else float(np.mean([r['coverage_80'] for r in rs]))})
 references.append({'name':model['name'],'replica':model['replica'],'cells':cells})
arms=[]
for p in sorted((job/'attempts').iterdir()):
 f=json.loads((p/'frontier.json').read_bytes());t=json.loads((p/'trial.json').read_bytes());groups=defaultdict(list)
 for c in f['cells']:groups[c['horizon'],c['target']].append(c)
 cells=[]
 for (h,target),cs in groups.items():
  good=[c for c in cs if c.get('candidate',{}).get('crps') is not None and c.get('reference_means',{}).get('crps') is not None]
  if not good:continue
  best=min(good,key=lambda c:c['reference_means']['crps']);candidate=best['candidate'];ref=best['reference_means'];cells.append({'horizon':h,'target':target,'candidate':candidate,'best_reference':best['reference'],'best_replica':best['replica'],'reference':ref,'crps_improvement':ref['crps']-candidate['crps'],'crps_improvement_percent':100*(ref['crps']-candidate['crps'])/ref['crps']})
 primary=next(c for c in cells if c['horizon']==24 and c['target']=='terminal_log_return')
 assert primary['crps_improvement']<0
 arms.append({'arm':p.name.split('--')[1],'attempt':p.name,'candidate_id':f['candidate_id'],'primary_pass':False,'status':'failed_declared_primary_no_outer_release','forecast_records_n':len(t['result']['predictions']),'scored_records_n':sum(r['status']=='scored' for r in t['result']['predictions']),'frontier_cells_n':len(f['cells']),'mc_guards_n':len(f['mc_guards']),'cells':cells})
report={'schema':'research-programme-round1-assessment-v1','campaign_id':'9fb56bebaac599590446489b4917ed97f1dd8581f7e206a8820f9e460de1c20c','benchmark_atlas_id':atlas['atlas_id'],'fixed_primary':'24month terminal_log_return CRPS, lower is better; not wealth','references':references,'new_arms':arms,'outcome':'All three primary comparisons fail. No model improvement merged; no later-period release; no retuning. Keep reproducible negative evidence.','ledger_status':'OPEN protocol state with all3global slots consumed; no eligible finalist, no administrative freeze manufactured','limitations':['Retrospective exposed history, not fresh holdout.','24 two-year forecasts are overlapping, not24 independentcycles; onlyone negative return.','Current-vintage macro reconstruction,45daylag cannot establish historical knowledge.','Generic scalar adapter stamps higher_risk; anomaly is undirected so its ordinalalignment is not directionalvalidation.','Small anomaly one-year drawdown gain is secondary; cannot rescue declaredprimary.','No significance, calibration, professionaluse or tradingprofit claim.']}
(job/'assessment-controller.py').write_bytes(Path(__file__).read_bytes());(job/'assessment.json').write_bytes(canonical_bytes(report))
for r in references:
 cs=[c for c in r['cells'] if c['horizon']==24 and c['target']=='terminal_log_return'];print(r['name'],r['replica'],round(cs[0]['mean_crps'],6))
for arm in arms:
 p=next(c for c in arm['cells'] if c['horizon']==24 and c['target']=='terminal_log_return');print(arm['arm'],'primary',p['candidate']['crps'],'gainpct',p['crps_improvement_percent'])
