"""Reproduce three frozen experimental indicators; no scorer or outcome access."""
import hashlib,importlib.util,io,json,shutil
from pathlib import Path
import pandas as pd
from research.market_dataset import canonical_bytes
ROOT=Path('/Users/josh/Documents/03_Projects/risk-metric')
JOB=ROOT/'output/research-programme-round1-2026-11-07'
BUNDLE=JOB/'bundle'
ARMS={
'anomaly':('/Users/josh/.codex/worktrees/prospective-capture/risk-metric/research/candidates/anomaly_20261107','generator.py','cd2402f','4ac8ec016d195585bf036bb671ee15779022b2d0132e754cfcf0198ece0c57ba'),
'learner':('/Users/josh/.codex/worktrees/research-simple-learner/risk-metric/research/candidates/learner_20261107','generator.py','502c2d3','124ba75f036b4eba7e9e90fb78d9fb12392251722b36faddfc7bc54b5ffb9046'),
'ensemble':('/Users/josh/.codex/worktrees/research-simple-ensemble/risk-metric/research/candidates/ensemble_20261107','producer.py','629a061','1aeb4aa0f7809bb18bb3a7206b4ae90958faba9af1c95cfbae50068203b70da0')}
def sha(x):return hashlib.sha256(x).hexdigest()
manifest=json.loads((BUNDLE/'manifest.json').read_bytes())
owned={}
for name in ['btc_daily.csv','fred_real_yield_10y.csv','fred_dxy.csv']:
 raw=(BUNDLE/name).read_bytes();assert sha(raw)==manifest['sources'][name]['development_sha256'];owned[name]=raw
out=JOB/'generators';out.mkdir(exist_ok=False)
(out/'controller.py').write_bytes(Path(__file__).read_bytes())
summary={}
for arm,(folder,producer,commit,expected) in ARMS.items():
 target=out/arm;target.mkdir();folder=Path(folder)
 for filename in [producer,'config.json']:(target/filename).write_bytes((folder/filename).read_bytes())
 spec=importlib.util.spec_from_file_location('frozen_round1_'+arm,target/producer);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 frame=pd.read_csv(io.BytesIO(owned['btc_daily.csv']))
 if arm=='anomaly':
  scores=module.generate(frame);csv=scores.to_csv(index=False).encode();diagnostics=scores.to_dict('records');column=module.COLUMN
 elif arm=='learner':
  scores,diagnostics=module.generate(frame);csv=scores.to_csv().encode();column=module.COLUMN
 else:
  inputs={role:pd.read_csv(io.BytesIO(owned[name]),usecols=['Date',col]) for role,(name,col) in module.SOURCES.items()}
  dates=pd.date_range(module.CONFIG['first_query'],module.CONFIG['development_cutoff'],freq='ME')
  scores,diagnostics=module.generate(inputs,dates);csv=scores.to_csv(index=False,float_format='%.17g').encode();column='ensemble_risk'
 assert len(scores)==97 and sha(csv)==expected,(arm,sha(csv),expected)
 (target/'candidate.csv').write_bytes(csv)
 # Anomaly's CSV itself contains complete diagnostics, including blank neutral fields.
 if arm!='anomaly':(target/'diagnostics.json').write_bytes(canonical_bytes(diagnostics))
 summary[arm]={'frozen_commit':commit,'column':column,'candidate_sha256':sha(csv),'producer_sha256':sha((target/producer).read_bytes()),'config_sha256':sha((target/'config.json').read_bytes()),'source_file':producer,'n':len(scores),'root_reproduction':'byte-identical','inputs':{name:sha(raw) for name,raw in owned.items() if arm=='ensemble' or name=='btc_daily.csv'}}
(out/'reproduction.json').write_bytes(canonical_bytes(summary))
print(json.dumps(summary,sort_keys=True))
