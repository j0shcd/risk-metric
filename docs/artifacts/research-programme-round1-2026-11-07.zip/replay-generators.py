"""Reproduce owned frozen experiment outputs; no data acquisition or benchmark scoring."""
import argparse,hashlib,importlib.util,io,json
from pathlib import Path
import pandas as pd
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True)
args=parser.parse_args();summary=json.loads((args.packet/'generators/reproduction.json').read_bytes())
args.output_dir.mkdir(parents=True,exist_ok=False)
def sha(x):return hashlib.sha256(x).hexdigest()
for arm,r in summary.items():
 folder=args.packet/'generators'/arm;code=folder/r['source_file'];config=folder/'config.json'
 assert sha(code.read_bytes())==r['producer_sha256'] and sha(config.read_bytes())==r['config_sha256']
 inputs={}
 for name,expected in r['inputs'].items():
  raw=(args.packet/'bundle'/name).read_bytes();assert sha(raw)==expected;inputs[name]=pd.read_csv(io.BytesIO(raw))
 spec=importlib.util.spec_from_file_location('owned_'+arm,code);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 if arm=='anomaly':csv=module.generate(inputs['btc_daily.csv']).to_csv(index=False).encode()
 elif arm=='learner':csv=module.generate(inputs['btc_daily.csv'])[0].to_csv().encode()
 else:
  frames={role:inputs[name] for role,(name,_) in module.SOURCES.items()}
  dates=pd.date_range(module.CONFIG['first_query'],module.CONFIG['development_cutoff'],freq='ME')
  csv=module.generate(frames,dates)[0].to_csv(index=False,float_format='%.17g').encode()
 assert sha(csv)==r['candidate_sha256'],arm
 (args.output_dir/(arm+'.csv')).write_bytes(csv)
 print(arm,'97 dates, output byte-identical')
