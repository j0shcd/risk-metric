"""One frozen shrunk regression stump; no benchmark/scoring imports.

Higher score means lower predicted 24-month terminal log return. A supervised
reconstruction selected after historical exposure, never a historical PIT claim.
CLI reads only hash-bound pre2023 prices and writes a new ignored output folder.
"""
import argparse
import hashlib
import io
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd

COLUMN='astra_b_shrunk_stump'
PARAMETERS={'horizon_months':24,'latest_mature_labels':60,'minimum_labels':24,
            'minimum_leaf':12,'leaf_prior_labels':24,'drawdown_closes':365,
            'threshold':'training median only','feature_order':['trend_12_calendar_months','underwater_365_closes'],
            'neutral_risk':.5}
INPUT_SHA256='d6e0e23e4d84e32690cea42cc0bf69f44ddfe9d954939b54ba499635431ed04c'


def canonical(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(raw):return hashlib.sha256(raw).hexdigest()


def features(prices,query):
    """Require full calendar context, no interpolation or post-query closes."""
    start=query-pd.DateOffset(months=12)
    values=prices.reindex(pd.date_range(start,query,freq='D')).to_numpy(dtype=float)
    if not np.isfinite(values).all() or (values<=0).any():return None
    logs=np.log(values)
    return np.array([logs[-1]-logs[0],logs[-1]-np.max(logs[-365:])])


def mature_pool(prices,query):
    """Monthly origins; next-day entry, calendar end, strict end+1day<query."""
    pool=[]
    for origin in pd.date_range(prices.index.min(),query,freq='ME'):
        entry=origin+pd.Timedelta(days=1);end=entry+pd.DateOffset(months=24)
        available=end+pd.Timedelta(days=1)
        if not available<query:continue
        x=features(prices,origin)
        path=prices.reindex(pd.date_range(entry,end,freq='D')).to_numpy(dtype=float)
        if x is None or not np.isfinite(path).all() or (path<=0).any():continue
        target=float(np.log(path[-1])-np.log(path[0]))
        pool.append({'origin':origin.date().isoformat(),'entry':entry.date().isoformat(),
                     'end':end.date().isoformat(),'available':available.date().isoformat(),
                     'x':x.tolist(),'y':target})
    return pool[-PARAMETERS['latest_mature_labels']:]


def fit_predict(x,y,query):
    """Two candidate median splits; shrink leaf means toward the pooled mean.

    Select lowest training squared error of the SHRUNK predictions; exact ties
    select feature0. No depth growth, threshold sweep or outcome-driven controls.
    """
    x=np.asarray(x,float);y=np.asarray(y,float);query=np.asarray(query,float)
    if x.shape!=(len(y),2) or query.shape!=(2,) or not all(np.isfinite(v).all() for v in (x,y,query)):
        raise ValueError('finite two-feature training and query required')
    if len(y)<PARAMETERS['minimum_labels']:return .5,{'status':'neutral_insufficient_mature_labels'}
    pooled=float(np.mean(y));best=None
    for feature in range(2):
        threshold=float(np.median(x[:,feature]));upper=x[:,feature]>threshold
        counts=[int((~upper).sum()),int(upper.sum())]
        if min(counts)<PARAMETERS['minimum_leaf']:continue
        prior=PARAMETERS['leaf_prior_labels']
        means=[float((y[upper==side].sum()+prior*pooled)/(counts[side]+prior)) for side in (0,1)]
        fitted=np.where(upper,means[1],means[0]);loss=float(np.mean((y-fitted)**2))
        if best is None or loss<best[0]:best=(loss,feature,threshold,counts,means)
    if best is None:return .5,{'status':'neutral_no_supported_split'}
    _,feature,threshold,counts,means=best
    prediction=means[int(query[feature]>threshold)]
    # Stable sigmoid(-prediction), no label clipping or full-history scaling.
    if prediction>=0:
        small=math.exp(-prediction);risk=small/(1+small)
    else:risk=1/(1+math.exp(prediction))
    return risk,{'status':'fitted','split_feature':feature,'threshold':threshold,
                 'leaf_counts':counts,'leaf_means':means,'pooled_mean':pooled,'predicted_log_return':prediction}


def generate(frame,dates=None):
    observed=pd.DatetimeIndex(pd.to_datetime(frame['Date'],utc=True)).tz_localize(None)
    if observed.empty or observed.hasnans or observed.has_duplicates or not observed.is_monotonic_increasing or not observed.equals(observed.normalize()):
        raise ValueError('unique ordered daily dates required')
    prices=pd.Series(pd.to_numeric(frame['Price'],errors='raise').to_numpy(dtype=float),index=observed)
    queries=pd.DatetimeIndex(pd.to_datetime(dates if dates is not None else pd.date_range('2014-12-31','2022-12-31',freq='ME'),utc=True)).tz_localize(None)
    if queries.hasnans or queries.has_duplicates or not queries.is_monotonic_increasing or not queries.equals(queries.normalize()):raise ValueError('ordered unique query days required')
    output=[];diagnostics=[]
    for query in queries:
        # Own prefix BEFORE feature and target construction, even if caller supplies future rows.
        past=prices.loc[:query];q=features(past,query);pool=mature_pool(past,query) if len(past) else []
        if q is None:risk=.5;detail={'status':'neutral_missing_query_context'}
        else:risk,detail=fit_predict(np.array([r['x'] for r in pool]).reshape(-1,2),np.array([r['y'] for r in pool]),q)
        day=query.date().isoformat();output.append((day,risk))
        diagnostics.append({'date':day,'training_n':len(pool),'training_origins':[r['origin'] for r in pool],
            'label_available':[r['available'] for r in pool],'training_digest':sha(canonical(pool)),
            'query_features':None if q is None else q.tolist(),**detail})
    return pd.DataFrame(output,columns=['Date',COLUMN]).set_index('Date'),diagnostics


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args();payload=(args.inputs/'btc_daily.csv').read_bytes()
    if sha(payload)!=INPUT_SHA256:raise ValueError('frozen development price identity mismatch')
    config=Path(__file__).with_name('config.json').read_bytes();declared=json.loads(config)
    if declared['parameters']!=PARAMETERS or declared['input']['sha256']!=INPUT_SHA256 or declared['candidate']!=COLUMN:raise ValueError('fixed config/source mismatch')
    frame=pd.read_csv(io.BytesIO(payload))
    if pd.to_datetime(frame['Date']).max()>pd.Timestamp('2022-12-31'):raise ValueError('post-development input')
    result,diagnostics=generate(frame)
    root=Path(__file__).resolve().parents[3];out=args.output_dir.absolute()
    if any(p.is_symlink() for p in (out,*out.parents)) or not out.resolve().is_relative_to(root/'output') or out.resolve()==root/'output':raise ValueError('new ignored output child required')
    out.mkdir(parents=True,exist_ok=False)
    csv=result.to_csv().encode();source=Path(__file__).read_bytes()
    (out/'candidate.csv').write_bytes(csv)
    (out/'diagnostics.json').write_bytes(canonical({'rows':diagnostics,'input_sha256':sha(payload),
        'input_bytes':len(payload),'producer_sha256':sha(source),'producer_bytes':len(source),
        'config_sha256':sha(config),'config_bytes':len(config),'output_sha256':sha(csv),'output_bytes':len(csv)}))

if __name__=='__main__':main()
