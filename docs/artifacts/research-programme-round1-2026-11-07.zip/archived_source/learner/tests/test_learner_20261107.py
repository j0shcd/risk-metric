"""Synthetic causal/learning-law oracles; never run a benchmark fitness scorer."""
import unittest
import numpy as np
import pandas as pd
from research.candidates.learner_20261107 import generator as g


def fixture(end='2022-12-31'):
    dates=pd.date_range('2010-01-01',end,freq='D');t=np.arange(len(dates))
    return pd.DataFrame({'Date':dates,'Price':np.exp(3+.0002*t+.25*np.sin(t/87))})

class LearnerTests(unittest.TestCase):
    def test_independent_shrinkage_law_and_tie(self):
        side=np.r_[np.full(12,-1.),np.ones(12)];x=np.column_stack((side,side));y=2*side
        risk,d=g.fit_predict(x,y,[1,1])
        self.assertAlmostEqual(d['predicted_log_return'],2/3)
        self.assertAlmostEqual(risk,1/(1+np.exp(2/3)))
        self.assertEqual(d['split_feature'],0);self.assertEqual(d['leaf_counts'],[12,12])
        self.assertLess(risk,g.fit_predict(x,y,[-1,-1])[0])
        self.assertEqual(g.fit_predict(x[:-1],y[:-1],[1,1])[0],.5)
        self.assertEqual(g.fit_predict(np.ones((24,2)),y,[1,1])[1]['status'],'neutral_no_supported_split')
        for sign in (-1,1):
            score,_=g.fit_predict(x,y+sign*2000,[1,1]);self.assertTrue(np.isfinite(score));self.assertTrue(0<=score<=1)

    def test_strict_calendar_maturity_and_terminal_label(self):
        f=fixture('2018-02-03');prices=f.set_index('Date')['Price'];origin='2016-01-31'
        before=g.mature_pool(prices,pd.Timestamp('2018-02-02'))
        after=g.mature_pool(prices,pd.Timestamp('2018-02-03'))
        self.assertNotIn(origin,[r['origin'] for r in before]);self.assertIn(origin,[r['origin'] for r in after])
        row=next(r for r in after if r['origin']==origin)
        self.assertEqual((row['entry'],row['end'],row['available']),('2016-02-01','2018-02-01','2018-02-02'))
        self.assertAlmostEqual(row['y'],np.log(prices['2018-02-01'])-np.log(prices['2016-02-01']))
        self.assertLessEqual(len(after),60)

    def test_future_append_and_shock_preserve_scores_and_training(self):
        frame=fixture();queries=pd.to_datetime(['2016-12-31','2018-12-31','2020-12-31'])
        full,diagnostics=g.generate(frame,queries)
        for i,q in enumerate(queries):
            short=frame.loc[frame.Date<=q]
            one,detail=g.generate(short,[q]);self.assertEqual(one.iloc[0,0],full.iloc[i,0]);self.assertEqual(detail[0],diagnostics[i])
            shock=frame.copy();shock.loc[shock.Date>q,'Price']=np.nan
            actual,d=g.generate(shock,[q]);self.assertEqual(actual.iloc[0,0],one.iloc[0,0]);self.assertEqual(d,detail)
            self.assertTrue(all(pd.Timestamp(a)<q for a in detail[0]['label_available']))

    def test_price_scale_invariance_and_feature_law(self):
        dates=pd.date_range('2014-01-01','2016-02-29');t=np.arange(len(dates));prices=pd.Series(np.exp(.001*t),index=dates)
        q=dates[-1];x=g.features(prices,q)
        self.assertAlmostEqual(x[0],.001*(q-(q-pd.DateOffset(months=12))).days);self.assertEqual(x[1],0.)
        np.testing.assert_allclose(g.features(prices*100,q),x,atol=1e-14)
        # Underwater is current distance below365-close peak, not historical max drawdown.
        prices.iloc[-3:]=[100.,10.,50.];self.assertAlmostEqual(g.features(prices,q)[1],np.log(.5))

    def test_fixed_common_support_and_missing_domain(self):
        frame=fixture();result,detail=g.generate(frame)
        self.assertEqual(len(result),97);self.assertEqual(result.index[0],'2014-12-31');self.assertEqual(result.index[-1],'2022-12-31')
        self.assertTrue(np.isfinite(result.to_numpy()).all());self.assertTrue(((result>=0)&(result<=1)).all().all())
        self.assertTrue(all(d['training_n']<=60 for d in detail))
        for value in (0.,-1.,np.nan,np.inf):
            bad=frame.copy();bad.loc[bad.index[-1],'Price']=value
            r,d=g.generate(bad,['2022-12-31']);self.assertEqual(r.iloc[0,0],.5);self.assertEqual(d[0]['status'],'neutral_missing_query_context')
        with self.assertRaises(ValueError):g.generate(pd.concat([frame,frame.iloc[-1:]]))

if __name__=='__main__':unittest.main()
