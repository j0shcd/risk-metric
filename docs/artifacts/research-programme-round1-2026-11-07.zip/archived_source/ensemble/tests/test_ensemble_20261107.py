import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch
import numpy as np
import pandas as pd

PATH=Path(__file__).resolve().parents[1]/'research/candidates/ensemble_20261107/producer.py'
spec=importlib.util.spec_from_file_location('ensemble_candidate',PATH)
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)


def inputs():
    dates=pd.date_range('2011-01-01','2022-12-31')
    t=np.arange(len(dates))
    return {'valuation':pd.DataFrame({'Date':dates,'Price':np.exp(3+.001*t+.4*np.sin(t/91))}),
            'real_yield':pd.DataFrame({'Date':dates,'real_yield_10y':np.cos(t/173)}),
            'dollar':pd.DataFrame({'Date':dates,'dxy':100*np.exp(.0001*t+.1*np.sin(t/127))})}


class EnsembleTests(unittest.TestCase):
    def test_prefix_oracle_and_future_shock(self):
        source=inputs();dates=pd.to_datetime(['2013-09-30','2014-12-31','2016-02-29','2018-06-30','2022-12-31'])
        full,details=p.generate(source,dates)
        for i,day in enumerate(dates):
            short={k:v.loc[v.Date<=day].copy() for k,v in source.items()}
            actual,diag=p.generate(short,dates[:i+1])
            pd.testing.assert_frame_equal(actual,full.iloc[:i+1].reset_index(drop=True))
            self.assertEqual(diag,details[:i+1])
            shocked={k:v.copy() for k,v in source.items()}
            for k,v in shocked.items():v.loc[v.Date>day,p.SOURCES[k][1]]=1.e90
            x,d=p.generate(shocked,dates[:i+1]);pd.testing.assert_frame_equal(x,actual);self.assertEqual(d,diag)

    def test_release_lag_exclusion_and_mutation_witness(self):
        source=inputs();day=pd.Timestamp('2017-08-31');changed={k:v.copy() for k,v in source.items()}
        for k,v in changed.items():
            cutoff=day-pd.Timedelta(days=1 if k=='valuation' else 45)
            v.loc[v.Date>cutoff,p.SOURCES[k][1]]=1.e90
        a,da=p.generate(source,[day]);b,db=p.generate(changed,[day]);pd.testing.assert_frame_equal(a,b);self.assertEqual(da,db)
        # Nonvacuous: an eligible source change must actually change this query.
        changed['real_yield'].loc[changed['real_yield'].Date==day-pd.Timedelta(days=45),'real_yield_10y']=10.
        c,_=p.generate(changed,[day]);self.assertNotEqual(float(a.ensemble_risk.iloc[0]),float(c.ensemble_risk.iloc[0]))

    def test_rank_independent_formula_and_fixed_missing_weight(self):
        day=pd.Timestamp('2020-01-01');dates=pd.date_range(day-pd.Timedelta(days=400),day-pd.Timedelta(days=45))
        values=np.sin(np.arange(len(dates))/11)
        s=pd.Series(values,index=dates);r=p.coordinate(s,day,'real_yield')
        h=values[:-1];expected=100*((h<values[-1]).sum()+.5*(h==values[-1]).sum())/len(h)
        self.assertEqual(r['score'],expected)
        with patch.object(p,'coordinate',side_effect=[{'score':100.,'available':True},{'score':50.,'available':False},{'score':50.,'available':False}]):
            scores,_=p.generate(inputs(),[day]);self.assertAlmostEqual(scores.ensemble_risk.iloc[0],200./3)
        tied=p.coordinate(pd.Series(1.,index=dates),day,'real_yield');self.assertEqual(tied['score'],50.)

    def test_missing_domain_and_no_silent_date_exclusion(self):
        source=inputs();day=pd.Timestamp('2017-08-31')
        for k,v in source.items():v[p.SOURCES[k][1]]=np.nan
        scores,diagnostics=p.generate(source,pd.date_range('2014-12-31','2022-12-31',freq='ME'))
        self.assertEqual(len(scores),97);self.assertTrue((scores.ensemble_risk==50.).all());self.assertTrue(all(d['available_n']==0 for d in diagnostics))
        for value in (0.,-1.,np.inf,np.nan):
            damaged=inputs();damaged['valuation'].loc[damaged['valuation'].Date==day-pd.Timedelta(days=1),'Price']=value
            _,detail=p.generate(damaged,[day]);self.assertFalse(detail[0]['components']['valuation']['available'])
        broken=inputs();broken['valuation']=pd.concat([broken['valuation'],broken['valuation'].iloc[:1]])
        with self.assertRaises(ValueError):p.generate(broken,[day])

    def test_no_label_channel_or_maturity_dependence(self):
        # No supervised updater exists: even immature/future outcome columns must
        # have no effect. Label maturity cannot enter via incidental CSV fields.
        source=inputs();dates=pd.to_datetime(['2015-12-31','2018-12-31'])
        expected,diag=p.generate(source,dates)
        for frame in source.values():
            frame['terminal_return_24m']=np.arange(len(frame))*1.e30
            frame['label_available_at']='2099-12-31'
        actual,d=p.generate(source,dates);pd.testing.assert_frame_equal(actual,expected);self.assertEqual(d,diag)

    def test_empty_stale_and_warmup_neutral(self):
        source=inputs();day=pd.Timestamp('2012-01-01')
        _,diag=p.generate(source,[day]);self.assertFalse(diag[0]['components']['valuation']['available'])
        for k in source:source[k]=source[k].iloc[:0]
        scores,diag=p.generate(source,[day]);self.assertEqual(scores.ensemble_risk.iloc[0],50.)
        s=pd.Series(np.arange(500),index=pd.date_range('2010-01-01',periods=500))
        self.assertEqual(p.coordinate(s,pd.Timestamp('2014-01-01'),'real_yield')['reason'],'stale')

    def test_cli_parses_the_hashed_owned_bytes(self):
        import contextlib
        import io
        import json
        import sys
        import tempfile
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);bundle=root/'bundle';bundle.mkdir();output=root/'result'
            source=inputs();hashes={}
            for name,(filename,column) in p.SOURCES.items():
                raw=source[name].to_csv(index=False).encode();(bundle/filename).write_bytes(raw)
                hashes[filename]=p.sha(raw)
            (bundle/'manifest.json').write_text(json.dumps({'cutoff':'2022-12-31','sources':{name:{'development_sha256':h} for name,h in hashes.items()}}))
            expected,_=p.generate(source,pd.date_range('2014-12-31','2022-12-31',freq='ME'))
            original_read=Path.read_bytes;changed=[]
            def capture_then_replace(path):
                raw=original_read(path)
                if path==bundle/'btc_daily.csv':
                    poisoned=source['valuation'].copy();poisoned['Price']=100.
                    path.write_bytes(poisoned.to_csv(index=False).encode());changed.append(True)
                return raw
            with patch.dict(p.CONFIG,{'input_sha256':hashes}),patch.object(Path,'read_bytes',capture_then_replace),patch.object(sys,'argv',['producer','--bundle',str(bundle),'--output-dir',str(output)]),contextlib.redirect_stdout(io.StringIO()):
                p.main()
            self.assertEqual(changed,[True])
            actual=pd.read_csv(output/'candidate.csv')
            np.testing.assert_allclose(actual.ensemble_risk,expected.ensemble_risk,rtol=0,atol=1e-12)
            receipt=json.loads((output/'receipt.json').read_bytes())
            self.assertEqual(receipt['input_sha256'],hashes)

if __name__=='__main__':unittest.main()
