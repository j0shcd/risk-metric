"""Fixed price/discount-rate/currency ensemble; no label inputs or fitting.

Research reconstruction only: a 45-day macro lag cannot repair revised vintages.
Dollar source is FRED DTWEXBGS (broad trade-weighted dollar), not ICE DXY.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
from pathlib import Path
import platform
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
CONFIG = json.loads((HERE / 'config.json').read_bytes())
SOURCES = {'valuation': ('btc_daily.csv', 'Price'),
           'real_yield': ('fred_real_yield_10y.csv', 'real_yield_10y'),
           'dollar': ('fred_dxy.csv', 'dxy')}


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def observations(frame, column, positive):
    """Invalid values stay missing; never backfill or silently skip a current row."""
    dates = pd.DatetimeIndex(pd.to_datetime(frame['Date'], errors='raise'))
    if dates.tz is not None or dates.hasnans or dates.has_duplicates or not dates.equals(dates.normalize()):
        raise ValueError('unique timezone-naive calendar dates required')
    values = pd.to_numeric(frame[column], errors='coerce').to_numpy(dtype=float)
    valid = np.isfinite(values)
    if positive:
        valid &= values > 0
    values = np.where(valid, values, np.nan)
    return pd.Series(values, index=dates).sort_index()


def timelines(inputs):
    price = observations(inputs['valuation'], 'Price', True)
    yields = observations(inputs['real_yield'], 'real_yield_10y', False)
    dollar = observations(inputs['dollar'], 'dxy', True)
    if not price.empty:
        price = price.reindex(pd.date_range(price.index.min(), price.index.max(), freq='D'))
    log_price = np.log(price)
    valuation = log_price - log_price.rolling(CONFIG['price_anchor_days'], min_periods=CONFIG['price_anchor_days']).mean()
    # Exact calendar displacement; the earlier dollar observation may be at most
    # seven days before its target. This allows weekends, never future filling.
    targets = dollar.index - pd.Timedelta(days=CONFIG['dollar_change_days'])
    earlier = dollar.reindex(targets, method='ffill', tolerance=pd.Timedelta(days=CONFIG['macro_max_age_days'])).to_numpy()
    change = pd.Series(np.log(dollar.to_numpy()) - np.log(earlier), index=dollar.index)
    return {'valuation': valuation, 'real_yield': yields, 'dollar': change}


def coordinate(series, query, name):
    lag = CONFIG['price_lag_days'] if name == 'valuation' else CONFIG['macro_lag_days']
    max_age = CONFIG['price_max_age_days'] if name == 'valuation' else CONFIG['macro_max_age_days']
    cutoff = query - pd.Timedelta(days=lag)
    observed = series.loc[series.index <= cutoff]
    detail = {'cutoff': cutoff.date().isoformat(), 'source_asof': None,
              'rank_history_n': 0, 'value': None, 'score': 50., 'available': False, 'reason': 'no_observation'}
    if observed.empty:
        return detail
    at = observed.index[-1]
    detail['source_asof'] = at.date().isoformat()
    if (cutoff-at).days > max_age:
        detail['reason'] = 'stale'; return detail
    value = float(observed.iloc[-1])
    if not np.isfinite(value):
        detail['reason'] = 'invalid_or_incomplete_transform'; return detail
    history = observed.loc[(observed.index >= at-pd.Timedelta(days=CONFIG['rank_history_days'])) & (observed.index < at)]
    history = history[np.isfinite(history)]
    detail.update(value=value, rank_history_n=len(history))
    if len(history) < CONFIG['rank_min_observations']:
        detail['reason'] = 'insufficient_rank_history'; return detail
    score = 100.*(np.count_nonzero(history.to_numpy() < value)+.5*np.count_nonzero(history.to_numpy() == value))/len(history)
    detail.update(score=float(score), available=True, reason='available')
    return detail


def generate(inputs, dates):
    """No outcomes accepted/used; causal transforms and fixed equal weights."""
    if set(inputs) != set(SOURCES):
        raise ValueError('exactly three registered source roles required')
    dates = pd.DatetimeIndex(pd.to_datetime(dates))
    if dates.tz is not None or dates.hasnans or dates.has_duplicates or not dates.equals(dates.normalize()) or not dates.is_monotonic_increasing:
        raise ValueError('ordered unique calendar queries required')
    series = timelines(inputs)
    rows, diagnostics = [], []
    for day in dates:
        parts = {name: coordinate(series[name], day, name) for name in SOURCES}
        score = 50. + sum(CONFIG['weights'][name]*(parts[name]['score']-50.) for name in SOURCES)
        rows.append({'Date': day.date().isoformat(), 'ensemble_risk': score})
        diagnostics.append({'Date': day.date().isoformat(), 'available_n': sum(p['available'] for p in parts.values()), 'components': parts})
    return pd.DataFrame(rows, columns=['Date', 'ensemble_risk']), diagnostics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    manifest = json.loads((args.bundle/'manifest.json').read_bytes())
    if manifest['cutoff'] != CONFIG['development_cutoff']:
        raise ValueError('only frozen development cutoff supported')
    inputs, hashes = {}, {}
    for name, (filename, column) in SOURCES.items():
        raw = (args.bundle/filename).read_bytes(); hashes[filename] = sha(raw)
        if hashes[filename] != CONFIG['input_sha256'][filename] or hashes[filename] != manifest['sources'][filename]['development_sha256']:
            raise ValueError('registered input identity changed')
        inputs[name] = pd.read_csv(io.BytesIO(raw), usecols=['Date', column])
        if pd.to_datetime(inputs[name]['Date']).max() > pd.Timestamp(CONFIG['development_cutoff']):
            raise ValueError('post-development row forbidden')
    dates = pd.date_range(CONFIG['first_query'], CONFIG['development_cutoff'], freq='ME')
    scores, diagnostics = generate(inputs, dates)
    assert len(scores) == 97 and np.isfinite(scores['ensemble_risk']).all()
    output = scores.to_csv(index=False, float_format='%.17g').encode()
    receipt = {'schema': 'fixed-ensemble-generation-v1', 'config': CONFIG, 'input_sha256': hashes,
               'producer_sha256': sha(Path(__file__).read_bytes()), 'config_sha256': sha((HERE/'config.json').read_bytes()),
               'csv_sha256': sha(output), 'rows': 97, 'fitness_evaluated': False,
               'runtime': {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__}}
    args.output_dir.mkdir(parents=True, exist_ok=False)
    (args.output_dir/'candidate.csv').write_bytes(output)
    (args.output_dir/'diagnostics.json').write_bytes(canonical(diagnostics))
    receipt['diagnostics_sha256'] = sha((args.output_dir/'diagnostics.json').read_bytes())
    (args.output_dir/'receipt.json').write_bytes(canonical(receipt))
    print(json.dumps({k: receipt[k] for k in ('rows', 'csv_sha256', 'producer_sha256', 'config_sha256', 'fitness_evaluated')}, sort_keys=True))


if __name__ == '__main__':
    main()
