"""One frozen undirected PCA state-incoherence indicator, not a buy/sell score.

A two-dimensional linear reconstruction captures usual coupling among 30/90/365
calendar-day log returns and log90-day realized return volatility. Scaling and
PCA use730 prior daily feature states, excluding the queried state. Two latent
coordinates and two-year memory are fixed modelling assumptions, not selections
from outcome performance. Higher error means atypical geometry only: both panic
and speculative excitement can be anomalous. The locked median decoder can miss
information in this representation; failure does not establish zero information.

Calendar gaps/nonpositive prices invalidate affected histories; no forward fill.
Insufficient or ambiguous-subspace histories return neutral with explicit status.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

CONFIG_PATH=Path(__file__).with_name('config.json')
CONFIG=json.loads(CONFIG_PATH.read_text())
COLUMN=CONFIG['name']


def feature_frame(frame):
    dates=pd.DatetimeIndex(pd.to_datetime(frame['Date'],errors='raise'))
    if (dates.empty or dates.hasnans or dates.has_duplicates or not dates.is_monotonic_increasing
            or dates.tz is not None or not dates.equals(dates.normalize())):
        raise ValueError('unique ordered naive calendar dates required')
    prices=pd.Series(pd.to_numeric(frame['Price'],errors='coerce').to_numpy(dtype=float),index=dates)
    prices=prices.where(np.isfinite(prices)&(prices>0)).reindex(pd.date_range(dates[0],dates[-1],freq='D'))
    logs=np.log(prices)
    features={}
    for days in CONFIG['return_days']:
        # A complete price interval is required, not merely valid endpoints.
        valid=logs.rolling(days+1,min_periods=days+1).count()==days+1
        features['return_'+str(days)]=(logs-logs.shift(days)).where(valid)
    returns=logs.diff()
    volatility=returns.rolling(CONFIG['volatility_days'],min_periods=CONFIG['volatility_days']).std(ddof=1)
    features['log_volatility']=np.log(volatility.clip(lower=CONFIG['volatility_floor']))
    return pd.DataFrame(features)


def state_score(training,query):
    training=np.asarray(training,float);query=np.asarray(query,float)
    if training.shape!=(CONFIG['training_days'],4) or query.shape!=(4,) or not np.isfinite(training).all() or not np.isfinite(query).all():
        return CONFIG['neutral'],'insufficient_or_invalid_history',None,None
    center=training.mean(axis=0);scale=np.maximum(training.std(axis=0,ddof=0),CONFIG['scale_floor'])
    z=(training-center)/scale;q=(query-center)/scale
    eigenvalues,vectors=np.linalg.eigh(z.T@z/len(z))
    rank=CONFIG['principal_components']
    gap=float(eigenvalues[-rank]-eigenvalues[-rank-1])
    if gap<=CONFIG['minimum_relative_eigengap']*max(1.,float(eigenvalues[-1])):
        return CONFIG['neutral'],'ambiguous_pca_subspace',None,gap
    projection=vectors[:,-rank:]
    residual=q-projection@(projection.T@q)
    energy=float(residual@residual/len(q))
    score=float(energy/(1+energy))
    if not np.isfinite(score):raise ValueError('nonfinite reconstruction score')
    return score,'available',energy,gap


def generate(frame,dates=None):
    features=feature_frame(frame)
    queries=pd.DatetimeIndex(dates if dates is not None else pd.date_range(CONFIG['first_query'],CONFIG['last_query'],freq='ME'))
    if queries.hasnans or queries.has_duplicates or queries.tz is not None or not queries.equals(queries.normalize()) or not queries.is_monotonic_increasing:
        raise ValueError('unique ordered naive query dates required')
    records=[]
    for query in queries:
        as_of=query-pd.Timedelta(days=CONFIG['observation_lag_days'])
        history=pd.date_range(end=as_of-pd.Timedelta(days=1),periods=CONFIG['training_days'],freq='D')
        training=features.reindex(history).to_numpy()
        current=features.reindex([as_of]).iloc[0].to_numpy()
        score,status,energy,gap=state_score(training,current)
        records.append({'Date':query.date().isoformat(),COLUMN:score,'available':status=='available','status':status,
                        'source_as_of':as_of.date().isoformat(),'training_start':history[0].date().isoformat(),
                        'training_end':history[-1].date().isoformat(),'finite_training_rows':int(np.isfinite(training).all(axis=1).sum()),
                        'reconstruction_energy':energy,'pca_boundary_eigengap':gap})
    return pd.DataFrame(records)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();source=args.bundle/'btc_daily.csv';raw=source.read_bytes()
    manifest=json.loads((args.bundle/'manifest.json').read_bytes())
    if manifest['cutoff']!=CONFIG['last_query'] or hashlib.sha256(raw).hexdigest()!=manifest['sources']['btc_daily.csv']['development_sha256']:
        raise ValueError('frozen development input mismatch')
    import io
    frame=pd.read_csv(io.BytesIO(raw))
    if pd.to_datetime(frame.Date).max()>pd.Timestamp(CONFIG['last_query']):raise ValueError('postdevelopment input forbidden')
    result=generate(frame)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    with args.output.open('x') as stream:result.to_csv(stream,index=False)

if __name__=='__main__':main()
