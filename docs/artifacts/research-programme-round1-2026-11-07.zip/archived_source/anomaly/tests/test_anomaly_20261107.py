import unittest
import numpy as np
import pandas as pd
from research.candidates.anomaly_20261107 import generator as g


class AnomalyTests(unittest.TestCase):
    def setUp(self):
        rng=np.random.default_rng(20261107);n=1900;t=np.arange(n)
        r=.0004+.001*np.sin(t/73)+rng.normal(size=n)*(.01+.005*np.cos(t/117))
        self.frame=pd.DataFrame({'Date':pd.date_range('2012-01-01',periods=n),'Price':np.exp(5+np.cumsum(r))})
        self.queries=pd.DatetimeIndex(self.frame.Date.iloc[[1100,1400,1600]])

    def test_independent_features_svd_and_excluded_query(self):
        query=self.queries[-1];asof=1598;logs=np.log(self.frame.Price.to_numpy())
        def feature(i):return [logs[i]-logs[i-d] for d in (30,90,365)]+[np.log(max(np.diff(logs[i-90:i+1]).std(ddof=1),1e-6))]
        x=np.array([feature(i) for i in range(asof-730,asof)]);q=np.array(feature(asof))
        center=x.mean(axis=0);scale=np.maximum(x.std(axis=0),1e-6);z=(x-center)/scale;q=(q-center)/scale
        _,_,vt=np.linalg.svd(z,full_matrices=False);residual=q-vt[:2].T@(vt[:2]@q);energy=residual@residual/4
        row=g.generate(self.frame,[query]).iloc[0]
        self.assertTrue(row.available)
        self.assertAlmostEqual(row[g.COLUMN],energy/(1+energy),places=12)
        self.assertEqual(row.training_end,(query-pd.Timedelta(days=3)).date().isoformat())

    def test_prefix_future_append_and_poisoned_suffix(self):
        full=g.generate(self.frame,self.queries)
        for n,query in enumerate(self.queries):
            prefix=self.frame[self.frame.Date<=query]
            pd.testing.assert_frame_equal(full.iloc[[n]].reset_index(drop=True),g.generate(prefix,[query]))
        shocked=self.frame.copy();shocked.loc[shocked.Date>self.queries[-1]-pd.Timedelta(days=2),'Price']=1e100
        pd.testing.assert_frame_equal(full,g.generate(shocked,self.queries))
        shocked.Price=shocked.Price.astype(object);shocked.loc[shocked.Date>self.queries[-1],'Price']='invalid future'
        pd.testing.assert_frame_equal(full,g.generate(shocked,self.queries))

    def test_domain_missing_and_neutral(self):
        short=g.generate(self.frame.iloc[:500],[self.frame.Date.iloc[499]]).iloc[0]
        self.assertEqual(short[g.COLUMN],.5);self.assertFalse(short.available)
        flat=self.frame.copy();flat.Price=7.
        row=g.generate(flat,[self.queries[-1]]).iloc[0]
        self.assertEqual(row.status,'ambiguous_pca_subspace');self.assertEqual(row[g.COLUMN],.5)
        for bad in (0,-1,np.nan,np.inf):
            broken=self.frame.copy();broken.loc[1500,'Price']=bad
            row=g.generate(broken,[self.queries[-1]]).iloc[0]
            self.assertFalse(row.available);self.assertTrue(np.isfinite(row[g.COLUMN]))
        broken=self.frame.drop(index=1500)
        self.assertFalse(g.generate(broken,[self.queries[-1]]).iloc[0].available)
        with self.assertRaises(ValueError):g.generate(pd.concat([self.frame,self.frame.iloc[-1:]]),self.queries)

    def test_units_and_historical_state_have_effect(self):
        original=g.generate(self.frame,self.queries)
        scaled=self.frame.copy();scaled.Price*=100
        np.testing.assert_allclose(original[g.COLUMN],g.generate(scaled,self.queries)[g.COLUMN],atol=1e-11,rtol=0)
        shock=self.frame.copy();shock.loc[1598,'Price']*=4
        self.assertNotAlmostEqual(original.iloc[-1][g.COLUMN],g.generate(shock,self.queries).iloc[-1][g.COLUMN],places=5)
