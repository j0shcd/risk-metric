"""Frozen undirected level state. Only levels enter ranks; clocks validate rows.

Printed/indexed dates must agree; observation<=release<=row query minus2 calendar
 days inclusive. Current query is never its own reference. Missing current stays
neutral. Historical window is calendar based, not last36 nonmissing observations.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import numpy as np
import pandas as pd

CONFIG = json.loads(Path(__file__).with_name('config.json').read_bytes())


def generate(prices_frame, macro_frame, queries):
    del prices_frame  # No price feature or metadata feature.
    f = macro_frame.copy()
    dates = pd.DatetimeIndex(pd.to_datetime(f['Date']))
    if dates.tz is not None or dates.has_duplicates or not dates.is_monotonic_increasing:
        raise ValueError('ordered unique naive macro dates required')
    if not ((dates == dates.normalize()) & dates.is_month_end).all():
        raise ValueError('normalized month ends required')
    f.index = dates
    v = pd.to_numeric(f.assets_usd_millions, errors='coerce')
    p, i, o = [pd.to_datetime(f[c], errors='coerce') for c in
               ('printed_release_date', 'indexed_release_date', 'observation_date')]
    if any(x.dt.tz is not None for x in (p, i, o)):
        raise ValueError('source clocks must be naive dates')
    valid = ((pd.to_numeric(f.available, errors='coerce') == 1) & np.isfinite(v) & (v > 0)
             & (p == i) & (o <= p) & (p <= dates - pd.Timedelta(days=2))
             & (p == p.dt.normalize()) & (o == o.dt.normalize()))
    qs = pd.DatetimeIndex(pd.to_datetime(list(queries)))
    if qs.tz is not None or qs.has_duplicates or not qs.is_monotonic_increasing:
        raise ValueError('ordered unique naive queries required')
    if not ((qs == qs.normalize()) & qs.is_month_end).all():
        raise ValueError('normalized query month ends required')
    rows = []
    for q in qs:
        prior = v[(dates >= q - pd.offsets.MonthEnd(CONFIG['window'])) & (dates < q) & valid]
        current_ok = q in dates and bool(valid.loc[q])
        available = current_ok and len(prior) >= CONFIG['minimum']
        score = CONFIG['neutral']
        if available:
            score = float(((prior < v.loc[q]).sum() + .5 * (prior == v.loc[q]).sum()) / len(prior))
        rows.append({'Date': q.strftime('%Y-%m-%d'), 'balance_sheet_state': score,
                     'available': available, 'valid_prior_n': len(prior),
                     'status': 'available' if available else ('invalid_current' if not current_ok else 'insufficient_history')})
    return pd.DataFrame(rows)


def main():
    p = argparse.ArgumentParser()
    for name in ('prices', 'macro', 'output-dir'):
        p.add_argument('--' + name, type=Path, required=True)
    a = p.parse_args()
    raw = {'btc_daily.csv': a.prices.read_bytes(), 'fed_published_monthly.csv': a.macro.read_bytes()}
    hashes = {k: hashlib.sha256(v).hexdigest() for k, v in raw.items()}
    if hashes != CONFIG['inputs']:
        raise ValueError('input identity mismatch')
    result = generate(pd.read_csv(io.BytesIO(raw['btc_daily.csv'])),
                      pd.read_csv(io.BytesIO(raw['fed_published_monthly.csv'])),
                      pd.date_range('2014-12-31', '2022-12-31', freq=pd.offsets.MonthEnd()))
    assert len(result) == 97 and np.isfinite(result.balance_sheet_state).all()
    a.output_dir.mkdir(parents=True, exist_ok=False)
    out = result.to_csv(index=False, float_format='%.17g').encode()
    (a.output_dir / 'candidate.csv').write_bytes(out)
    diag = {'inputs': hashes, 'rows': len(result), 'availability': result.status.value_counts().to_dict(),
            'candidate_sha256': hashlib.sha256(out).hexdigest(),
            'producer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'config_sha256': hashlib.sha256(Path(__file__).with_name('config.json').read_bytes()).hexdigest(),
            'limitations': CONFIG['limitations'], 'direction': 'undirected'}
    (a.output_dir / 'diagnostics.json').write_text(json.dumps(diag, indent=2) + '\n')


if __name__ == '__main__':
    main()
