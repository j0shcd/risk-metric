"""Frozen undirected twelve-month balance-growth acceleration.

Six recent versus six earlier monthly log changes, normalized by total absolute
change. Only Date and asset levels enter arithmetic. Metadata validates release
eligibility; admitted BTC is hash-checked by CLI but unused economically.
Reconstructed Tier B/C releases are not verified original historical vintages.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
from urllib.parse import urlsplit
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
CONFIG=json.loads((HERE/'config.json').read_bytes())
COLUMN='balance_growth_acceleration'

def sha(raw):return hashlib.sha256(raw).hexdigest()

def validate_row(row):
    """Eligibility at the observation's own monthly query, never today's clock."""
    if row['available'] not in (0,1):raise ValueError('available must be0or1')
    if row['available']==0:return False
    q=pd.Timestamp(row['Date'])
    def day(name):
        d=pd.Timestamp(row[name])
        if pd.isna(d) or d.tz is not None or d!=d.normalize():raise ValueError('invalid source date')
        return d
    printed=day('printed_release_date');indexed=day('indexed_release_date');obs=day('observation_date')
    if printed!=indexed or printed>q-pd.Timedelta(days=2):raise ValueError('release unavailable at own query cutoff')
    if obs.weekday()!=2 or not 0<=(printed-obs).days<=7:raise ValueError('invalid observation clock')
    if row['version_tier'] not in ('B','C'):raise ValueError('unexpected admitted provenance tier')
    h=str(row['source_sha256'])
    if len(h)!=64 or any(c not in '0123456789abcdef' for c in h):raise ValueError('invalid source hash')
    url=urlsplit(str(row['source_url']))
    if url.scheme!='https' or url.hostname!='www.federalreserve.gov' or not url.path.startswith('/releases/h41/') or url.username or url.password:raise ValueError('unexpected provenance URL')
    value=float(row['assets_usd_millions'])
    if not np.isfinite(value) or value<=0 or value!=np.floor(value):raise ValueError('invalid asset level')
    return True

def generate(prices_frame,macro_frame,queries):
    """Return all requested monthends; missing windows stay neutral and flagged.

    Invalid eligible source metadata fails closed. No metadata-derived features,
    carry-forward, retrospective normalization or trained parameters.
    """
    dates=pd.to_datetime(macro_frame['Date'],errors='raise')
    if dates.dt.tz is not None or dates.isna().any() or not dates.eq(dates.dt.normalize()).all():raise ValueError('invalid monthly dates')
    qs=pd.DatetimeIndex(pd.to_datetime(queries))
    if qs.hasnans or qs.tz is not None or qs.has_duplicates or not qs.is_monotonic_increasing or not qs.equals(qs.normalize()) or not qs.is_month_end.all():raise ValueError('ordered unique monthend queries required')
    rows=[]
    for q in qs:
        # Exclude future values and metadata before validating or calculating.
        frame=macro_frame.loc[dates<=q].copy();frame['Date']=dates[dates<=q]
        if frame.Date.duplicated().any():raise ValueError('duplicate past source date')
        if not frame.Date.dt.is_month_end.all():raise ValueError('nonmonthend source')
        window=pd.date_range(end=q,periods=13,freq='ME')
        indexed=frame.set_index('Date',drop=False)
        score=50.;status='available';growth=np.zeros(12);missing=[]
        for d in window:
            if d not in indexed.index or not validate_row(indexed.loc[d]):missing.append(d)
        if q in missing:status='current_unavailable'
        elif missing:status='historical_window_unavailable'
        else:
            values=indexed.loc[window,'assets_usd_millions'].to_numpy(float)
            growth=np.diff(np.log(values));denom=float(np.abs(growth).sum())
            if denom==0:status='flat_window'
            else:score=float(np.clip(50+50*(growth[6:].sum()-growth[:6].sum())/denom,0,100))
        rows.append({'Date':q.date().isoformat(),COLUMN:score,'coverage':status,'missing_months':len(missing)})
    return pd.DataFrame(rows)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prices',type=Path,required=True);parser.add_argument('--macro',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args();price_raw=args.prices.read_bytes();macro_raw=args.macro.read_bytes()
    for name,raw in [('btc_daily.csv',price_raw),('fed_published_monthly.csv',macro_raw)]:
        if sha(raw)!=CONFIG['input_sha256'][name]:raise ValueError('unadmitted input bytes')
    prices=pd.read_csv(io.BytesIO(price_raw));macro=pd.read_csv(io.BytesIO(macro_raw))
    result=generate(prices,macro,pd.date_range('2014-12-31','2022-12-31',freq='ME'))
    assert len(result)==97 and np.isfinite(result[COLUMN]).all()
    csv=result.to_csv(index=False,float_format='%.17g').encode()
    diag={'input_sha256':{name:sha(raw) for name,raw in [('btc_daily.csv',price_raw),('fed_published_monthly.csv',macro_raw)]},'producer_sha256':sha(Path(__file__).read_bytes()),'config_sha256':sha((HERE/'config.json').read_bytes()),'csv_sha256':sha(csv),'rows':len(result),'coverage':result.coverage.value_counts().to_dict(),'fitness_executed':False,'prices_used_as_features':False}
    args.output_dir.mkdir(parents=True,exist_ok=False)
    (args.output_dir/'candidate.csv').write_bytes(csv);(args.output_dir/'diagnostics.json').write_text(json.dumps(diag,indent=2,sort_keys=True)+'\n')
    print(json.dumps(diag,sort_keys=True))

if __name__=='__main__':main()
