"""Frozen unsupervised monthly price/monetary co-movement; no outcome labels."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import numpy as np
import pandas as pd

CONFIG_PATH = Path(__file__).with_name('config.json')
CONFIG = json.loads(CONFIG_PATH.read_bytes())
INPUT_HASHES = {'btc_daily.csv': 'd6e0e23e4d84e32690cea42cc0bf69f44ddfe9d954939b54ba499635431ed04c',
                'fed_published_monthly.csv': '0a34cb9981964f78f250bc278e6fba64a677d5828c4816a9cec930ac49aa2119'}


def indexed(frame):
    frame = frame.copy()
    frame['Date'] = pd.to_datetime(frame['Date'], errors='raise')
    if frame['Date'].isna().any() or frame['Date'].duplicated().any() or any(x != x.normalize() or x.tz is not None for x in frame.Date):
        raise ValueError('unique naive calendar dates required')
    return frame.set_index('Date').sort_index()


def asset_at(macro, day):
    if day not in macro.index:
        return None
    row = macro.loc[day]
    if row.available not in (0, 1):
        raise ValueError('binary availability required')
    if row.available == 0:
        return None
    release = pd.Timestamp(row.printed_release_date)
    indexed_release = pd.Timestamp(row.indexed_release_date)
    observation = pd.Timestamp(row.observation_date)
    if any(pd.isna(x) or x.tz is not None or x != x.normalize() for x in (release, indexed_release, observation)):
        raise ValueError('invalid source clock')
    if release != indexed_release or not 2 <= (day-release).days <= 14 or observation.weekday() != 2 or not 0 <= (release-observation).days <= 7:
        raise ValueError('source clock violation')
    value = float(row.assets_usd_millions)
    if not np.isfinite(value) or value <= 0:
        raise ValueError('positive finite assets required')
    return value


def generate(prices_frame, macro_frame, queries):
    prices, macro = indexed(prices_frame), indexed(macro_frame)
    out, diagnostics = [], []
    for query in pd.to_datetime(queries):
        if query.tz is not None or query != query.normalize() or not query.is_month_end:
            raise ValueError('monthend calendar query required')
        days = pd.date_range(end=query, periods=CONFIG['window_months']+1, freq='ME')
        levels = [asset_at(macro, day) for day in days]
        closes = []
        for day in days:
            cutoff = day-pd.Timedelta(days=CONFIG['price_lag_days'])
            v = float(prices.loc[cutoff, 'Price']) if cutoff in prices.index else np.nan
            if np.isfinite(v) and v <= 0:
                raise ValueError('positive price required')
            closes.append(v)
        pairs = []
        for i in range(1, len(days)):
            if levels[i] is not None and levels[i-1] is not None and np.isfinite(closes[i]) and np.isfinite(closes[i-1]):
                pairs.append((np.log(closes[i])-np.log(closes[i-1]), np.log(levels[i])-np.log(levels[i-1])))
        score, reason = CONFIG['neutral'], 'insufficient_pairs'
        if levels[-1] is None:
            reason = 'current_macro_missing'
        elif not np.isfinite(closes[-1]):
            reason = 'current_price_missing'
        elif len(pairs) >= CONFIG['minimum_pairs']:
            a = np.asarray(pairs); a -= a.mean(axis=0)
            variances = np.mean(a*a, axis=0)
            if np.all(variances > CONFIG['variance_floor']):
                correlation = np.mean(a[:,0]*a[:,1])/np.sqrt(variances.prod())
                score = 50+50*float(np.clip(correlation, -1, 1)); reason = 'available'
            else:
                reason = 'undefined_variation'
        out.append({'Date': query.strftime('%Y-%m-%d'), 'coupling_state': score})
        diagnostics.append({'Date': query.strftime('%Y-%m-%d'), 'valid_pairs': len(pairs), 'status': reason})
    return pd.DataFrame(out), diagnostics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    frames, identities = [], {}
    for name, expected in INPUT_HASHES.items():
        raw = (args.bundle/name).read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != expected:
            raise ValueError('input identity mismatch')
        frames.append(pd.read_csv(io.BytesIO(raw)))
        identities[name] = digest
    result, diagnostics = generate(*frames, pd.date_range('2014-12-31', '2022-12-31', freq='ME'))
    args.output.mkdir(parents=True, exist_ok=False)
    raw = result.to_csv(index=False, float_format='%.17g').encode()
    (args.output/'candidate.csv').write_bytes(raw)
    evidence = {'inputs': identities, 'producer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'config_sha256': hashlib.sha256(CONFIG_PATH.read_bytes()).hexdigest(),
                'csv_sha256': hashlib.sha256(raw).hexdigest(), 'diagnostics': diagnostics}
    (args.output/'diagnostics.json').write_text(json.dumps(evidence, indent=2)+'\n')

if __name__ == '__main__':
    main()
