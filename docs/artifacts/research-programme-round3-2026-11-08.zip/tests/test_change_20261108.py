import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from research.candidates.change_20261108 import producer as p


def fixture(exponents):
    dates=pd.date_range('2013-12-31',periods=13,freq='ME');rows=[]
    for d,e in zip(dates,exponents):
        release=d-pd.Timedelta(days=2);obs=release-pd.Timedelta(days=(release.weekday()-2)%7)
        rows.append({'Date':d,'assets_usd_millions':2.**e,'available':1,'indexed_release_date':release.date().isoformat(),'printed_release_date':release.date().isoformat(),'observation_date':obs.date().isoformat(),'version_tier':'C','source_sha256':'a'*64,'source_url':'https://www.federalreserve.gov/releases/h41/synthetic/'})
    return pd.DataFrame(rows)

class ChangeTests(unittest.TestCase):
    def score(self,f):return p.generate(None,f,['2014-12-31']).iloc[0]
    def test_simple_law(self):
        f=fixture(np.r_[10+np.arange(7),16+2*np.arange(1,7)])
        self.assertAlmostEqual(self.score(f)[p.COLUMN],50+50/3)
        self.assertAlmostEqual(self.score(fixture(np.arange(13)+10))[p.COLUMN],50)
        self.assertEqual(self.score(fixture(np.repeat(20,13))).coverage,'flat_window')
        self.assertAlmostEqual(self.score(fixture(np.r_[10+np.arange(7),16-np.arange(1,7)]))[p.COLUMN],0)
    def test_scale_and_order(self):
        f=fixture(np.r_[10+np.arange(7),16+2*np.arange(1,7)]);a=self.score(f)[p.COLUMN]
        f.assets_usd_millions*=1024
        self.assertAlmostEqual(self.score(f)[p.COLUMN],a)
        self.assertAlmostEqual(self.score(f.iloc[::-1])[p.COLUMN],a)
    def test_future_poison_and_prices_unused(self):
        f=fixture(np.arange(13)+10);a=p.generate(None,f,['2014-12-31'])
        future=f.iloc[-1:].copy();future.Date=pd.Timestamp('2015-01-31');future.assets_usd_millions=np.nan;future.printed_release_date='nonsense';future.version_tier='bad'
        pd.testing.assert_frame_equal(a,p.generate(pd.DataFrame({'Price':[-1,np.nan]}),pd.concat([f,future]),['2014-12-31']))
    def test_missing_current_and_history(self):
        f=fixture(np.arange(13)+10);f.loc[12,'available']=0;f.loc[12,'assets_usd_millions']=np.nan
        r=self.score(f);self.assertEqual(r.coverage,'current_unavailable');self.assertEqual(r[p.COLUMN],50)
        f=fixture(np.arange(13)+10);f.loc[3,'available']=0
        self.assertEqual(self.score(f).coverage,'historical_window_unavailable')
        self.assertEqual(self.score(f.drop(index=3)).coverage,'historical_window_unavailable')
    def test_release_clock_at_historical_row(self):
        f=fixture(np.arange(13)+10)
        f.loc[3,'printed_release_date']=f.loc[3,'Date'].date().isoformat();f.loc[3,'indexed_release_date']=f.loc[3,'printed_release_date']
        with self.assertRaises(ValueError):self.score(f)
        for field,value in [('printed_release_date','2020-01-01'),('observation_date','2014-12-30'),('version_tier','A'),('source_url','https://evil.test/releases/h41/a'),('assets_usd_millions',np.inf)]:
            f=fixture(np.arange(13)+10);f.loc[12,field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):self.score(f)
    def test_full_calendar_neutral_retention(self):
        out=p.generate(None,fixture(np.arange(13)+10),pd.date_range('2014-12-31','2022-12-31',freq='ME'))
        self.assertEqual(len(out),97);self.assertTrue(np.isfinite(out[p.COLUMN]).all());self.assertTrue(out[p.COLUMN].between(0,100).all())
    def test_hashed_bytes_are_parsed(self):
        raw=fixture(np.arange(13)+10).to_csv(index=False).encode();price=b'Date,Price\n2014-01-01,1\n'
        with tempfile.TemporaryDirectory() as temp:
            d=Path(temp);m=d/'macro.csv';m.write_bytes(raw);b=d/'price.csv';b.write_bytes(price);original=pd.read_csv
            def changed_path(arg,*a,**kw):
                m.write_text('invalid');b.write_text('invalid');return original(arg,*a,**kw)
            with patch.dict(p.CONFIG,{'input_sha256':{'btc_daily.csv':hashlib.sha256(price).hexdigest(),'fed_published_monthly.csv':hashlib.sha256(raw).hexdigest()}}),patch('sys.argv',['producer','--prices',str(b),'--macro',str(m),'--output-dir',str(d/'out')]),patch.object(p.pd,'read_csv',side_effect=changed_path):p.main()
            diag=json.loads((d/'out/diagnostics.json').read_text());self.assertEqual(diag['input_sha256']['fed_published_monthly.csv'],hashlib.sha256(raw).hexdigest())
            out=original(d/'out/candidate.csv');self.assertEqual(out.coverage.iloc[0],'available')

if __name__=='__main__':unittest.main()
