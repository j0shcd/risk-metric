import unittest
import numpy as np
import pandas as pd
from research.candidates.coupling_20261108.producer import generate


def fixture(sign=1):
    dates = pd.date_range('2018-01-31', periods=26, freq='ME')
    changes = .01*np.sin(np.arange(len(dates)))
    assets = 100*np.exp(np.cumsum(changes))
    prices = 10*np.exp(sign*np.cumsum(changes))
    rows = []
    for d,v in zip(dates,assets):
        release = d-pd.Timedelta(days=2)
        obs = release-pd.Timedelta(days=(release.weekday()-2)%7)
        rows.append(dict(Date=d,assets_usd_millions=v,available=1,indexed_release_date=release,printed_release_date=release,observation_date=obs))
    return pd.DataFrame({'Date':dates-pd.Timedelta(days=1),'Price':prices}),pd.DataFrame(rows),dates


class CouplingTests(unittest.TestCase):
    def test_mechanism(self):
        for sign,expected in [(1,100),(-1,0)]:
            p,m,d=fixture(sign);r,diag=generate(p,m,[d[-1]])
            self.assertAlmostEqual(r.coupling_state.iloc[0],expected,places=9)
            self.assertEqual(diag[0]['valid_pairs'],12)
    def test_prefix_future_poison(self):
        p,m,d=fixture();q=d[15]
        a,_=generate(p,m,[q]);b,_=generate(p[p.Date<=q],m[m.Date<=q],[q])
        pd.testing.assert_frame_equal(a,b)
        p.loc[p.Date>q,'Price']=1e100;m.loc[m.Date>q,'assets_usd_millions']=1e100
        c,_=generate(p,m,[q]);pd.testing.assert_frame_equal(a,c)
    def test_price_cutoff(self):
        p,m,d=fixture();q=d[-1];a,_=generate(p,m,[q])
        p=pd.concat([p,pd.DataFrame({'Date':[q],'Price':[1e100]})])
        b,_=generate(p,m,[q]);pd.testing.assert_frame_equal(a,b)
    def test_source_clock_and_domain(self):
        p,m,d=fixture()
        for field,value in [('printed_release_date',d[-1]),('assets_usd_millions',-1),('available',2),('observation_date',d[-1]+pd.Timedelta(days=7))]:
            n=m.copy();n.loc[n.index[-1],field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):generate(p,n,[d[-1]])
    def test_missing_no_fill(self):
        p,m,d=fixture();m.loc[m.index[-1],'available']=0
        r,diag=generate(p,m,[d[-1]])
        self.assertEqual(r.coupling_state.iloc[0],50)
        self.assertEqual(diag[0]['status'],'current_macro_missing')
        m.loc[m.index[-1],'available']=1;m.loc[m.index[-4],'available']=0
        _,diag=generate(p,m,[d[-1]])
        self.assertEqual(diag[0]['valid_pairs'],10)
    def test_constant_and_short_neutral(self):
        p,m,d=fixture();m.assets_usd_millions=100
        r,diag=generate(p,m,[d[-1],d[3]])
        self.assertEqual(r.coupling_state.tolist(),[50,50])
        self.assertEqual(diag[0]['status'],'undefined_variation')

if __name__=='__main__':unittest.main()
