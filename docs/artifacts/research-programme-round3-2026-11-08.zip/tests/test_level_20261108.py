import hashlib
import io
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
import pandas as pd
from research.candidates.level_20261108 import producer as m


def fixture(n=50):
    d = pd.date_range('2010-01-31', periods=n, freq=pd.offsets.MonthEnd())
    p = d - pd.Timedelta(days=3)
    return pd.DataFrame({'Date': d, 'assets_usd_millions': np.arange(n) + 100.,
                         'available': 1, 'printed_release_date': p,
                         'indexed_release_date': p, 'observation_date': p - pd.Timedelta(days=1)})


class LevelTests(unittest.TestCase):
    def test_mechanism_ties_scale_and_current_exclusion(self):
        f = fixture(); q = f.Date.iloc[-1]
        self.assertEqual(m.generate(None, f, [q]).balance_sheet_state.iloc[0], 1.)
        f.loc[49, 'assets_usd_millions'] = 130
        # Prior months13..48:17 below130,1equal,18above.
        self.assertEqual(m.generate(None, f, [q]).balance_sheet_state.iloc[0], 17.5/36)
        f.assets_usd_millions *= 1e8
        self.assertEqual(m.generate(None, f, [q]).balance_sheet_state.iloc[0], 17.5/36)
        f.assets_usd_millions = 10
        self.assertEqual(m.generate(None, f, [q]).balance_sheet_state.iloc[0], .5)

    def test_future_append_and_poison(self):
        f = fixture(75); qs = f.Date.iloc[35:50]
        expected = m.generate(None, f.iloc[:50], qs)
        f.loc[50:, 'assets_usd_millions'] = np.nan
        f.loc[50:, 'available'] = 0
        pd.testing.assert_frame_equal(expected, m.generate(None, f, qs))
        f.loc[50:, 'assets_usd_millions'] = 1e300
        f.loc[50:, 'available'] = 1
        pd.testing.assert_frame_equal(expected, m.generate(None, f, qs))

    def test_missing_source_clock_and_calendar_window(self):
        for column, value in [('available', 0), ('assets_usd_millions', np.inf),
                              ('printed_release_date', pd.Timestamp('2050-01-01')),
                              ('observation_date', pd.Timestamp('2050-01-01'))]:
            f = fixture(); f.loc[49, column] = value
            r = m.generate(None, f, [f.Date.iloc[-1]]).iloc[0]
            self.assertFalse(r.available); self.assertEqual(r.balance_sheet_state, .5)
        f = fixture(); f.loc[13:19, 'available'] = 0
        r = m.generate(None, f, [f.Date.iloc[-1]]).iloc[0]
        self.assertEqual(r.valid_prior_n, 29); self.assertFalse(r.available)
        # Old valid rows must not extend the declared calendar window.
        f.loc[13, 'available'] = 1
        self.assertTrue(m.generate(None, f, [f.Date.iloc[-1]]).available.iloc[0])
        q = f.Date.iloc[-1]
        self.assertFalse(m.generate(None, f.iloc[:-1], [q]).available.iloc[0])

    def test_cli_owns_both_inputs_before_parsing(self):
        with tempfile.TemporaryDirectory() as td:
            td = Path(td); prices = td/'prices.csv'; macro = td/'macro.csv'
            prices.write_bytes(b'Date,Price\n2012-01-01,1\n')
            macro.write_bytes(fixture(160).to_csv(index=False).encode())
            cfg = dict(m.CONFIG, inputs={'btc_daily.csv': hashlib.sha256(prices.read_bytes()).hexdigest(),
                                       'fed_published_monthly.csv': hashlib.sha256(macro.read_bytes()).hexdigest()})
            original = pd.read_csv; calls = []
            def reader(source, *args, **kwargs):
                self.assertIsInstance(source, io.BytesIO)
                if not calls:
                    prices.write_bytes(b'poison'); macro.write_bytes(b'poison')
                calls.append(source.getvalue())
                return original(source, *args, **kwargs)
            argv = ['producer', '--prices', str(prices), '--macro', str(macro), '--output-dir', str(td/'out')]
            with patch.object(m, 'CONFIG', cfg), patch('sys.argv', argv), patch.object(m.pd, 'read_csv', reader):
                m.main()
            self.assertEqual(len(calls), 2)
            self.assertEqual(len(original(td/'out/candidate.csv')), 97)


if __name__ == '__main__':
    unittest.main()
