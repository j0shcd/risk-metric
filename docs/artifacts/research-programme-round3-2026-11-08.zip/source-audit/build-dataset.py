"""Replay the frozen source audit from owned Board captures; no network/models.

Run with the repository on PYTHONPATH and --raw-root pointing to the private
capture directory. Published source levels are reconstructed editions, not PIT.
"""
import argparse
import csv
import hashlib
import io
import json
from pathlib import Path
from research.h41_release import extract, ExtractionError


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def build(raw_root, contract_path, exceptions_path, output_dir):
    contract_raw = contract_path.read_bytes()
    contract = json.loads(contract_raw)
    plan_raw = (raw_root / 'monthly-acquisition-plan.json').read_bytes()
    if sha(plan_raw) != contract['acquisition_plan_sha256']:
        raise ValueError('unregistered acquisition plan')
    plan = json.loads(plan_raw)
    capture_raw = (raw_root / 'monthly-capture.json').read_bytes()
    capture = json.loads(capture_raw)
    if not capture['complete'] or capture['plan_sha256'] != sha(plan_raw):
        raise ValueError('incomplete or mismatched capture')
    exceptions_raw = exceptions_path.read_bytes()
    exceptions = json.loads(exceptions_raw)
    if exceptions['plan_sha256'] != sha(plan_raw):
        raise ValueError('exception selection mismatch')
    versions = {row['query']: row for row in exceptions['selected_rows']}
    if len(versions) != len(plan['queries']):
        raise ValueError('exception inventory mismatch')
    rows = []
    if len(capture['rows']) != len(plan['queries']):
        raise ValueError('capture inventory mismatch')
    for selected, captured in zip(plan['queries'], capture['rows']):
        for field in ('query', 'selected_release_date', 'url'):
            if selected[field] != captured[field]:
                raise ValueError('selection changed after capture')
        relative = Path(captured['file'])
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('capture path outside owned directory')
        raw = (raw_root / relative).read_bytes()
        if sha(raw) != captured['sha256'] or len(raw) != captured['bytes']:
            raise ValueError('capture identity mismatch')
        version = versions[selected['query']]
        if version['selected_release_date'] != selected['selected_release_date'] or version['tier'] not in ('A', 'B', 'C', 'D'):
            raise ValueError('exception identity or tier mismatch')
        row = {'Date': selected['query'], 'assets_usd_millions': '', 'available': 0,
               'indexed_release_date': selected['selected_release_date'],
               'printed_release_date': '', 'observation_date': '',
               'version_tier': version['tier'],
               'source_sha256': captured['sha256'], 'source_url': captured['final_url'],
               'unavailable_reason': ''}
        if version['tier'] == 'D' or version['target_correction_identified']:
            row['unavailable_reason'] = 'target correction or unresolved version scope'
            rows.append(row)
            continue
        try:
            value = extract(raw, selected['selected_release_date'])
        except ExtractionError as error:
            row['unavailable_reason'] = str(error)
        else:
            row.update(assets_usd_millions=value['total_assets_usd_millions'], available=1,
                       printed_release_date=value['release_date'],
                       observation_date=value['observation_date'])
        rows.append(row)
    all_n = sum(row['available'] for row in rows)
    benchmark = [row for row in rows if row['Date'] >= contract['monthly_queries']['benchmark_first']]
    bench_n = sum(row['available'] for row in benchmark)
    longest = run = 0
    for row in rows:
        run = 0 if row['available'] else run + 1
        longest = max(longest, run)
    gate = contract['admission_gates']
    if all_n < gate['minimum_eligible_all'] or bench_n < gate['minimum_eligible_benchmark'] or longest > gate['maximum_consecutive_missing_months']:
        raise ValueError('source completeness gate failed')
    output_dir.mkdir(parents=True, exist_ok=False)
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
    writer.writeheader(); writer.writerows(rows)
    raw_csv = stream.getvalue().encode()
    (output_dir / 'published-monthly.csv').write_bytes(raw_csv)
    receipt = {'scope': 'Reconstructed Board published monthly assets; root accepts Tier B/C continuity assumptions for exploratory research only. No original/PIT certification or model qualification.',
               'contract_sha256': sha(contract_raw), 'plan_sha256': sha(plan_raw),
               'capture_manifest_sha256': sha(capture_raw), 'exceptions_sha256': sha(exceptions_raw),
               'dataset_sha256': sha(raw_csv), 'rows': len(rows), 'available': all_n,
               'benchmark_rows': len(benchmark), 'benchmark_available': bench_n,
               'maximum_consecutive_missing': longest,
               'unavailable': [row for row in rows if not row['available']]}
    (output_dir / 'dataset-receipt.json').write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-root', type=Path, required=True)
    parser.add_argument('--contract', type=Path, required=True)
    parser.add_argument('--exceptions', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    build(args.raw_root, args.contract, args.exceptions, args.output_dir)
