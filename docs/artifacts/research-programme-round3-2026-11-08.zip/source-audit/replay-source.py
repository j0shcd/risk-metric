"""Verify the external ZIP SHA first. This runs trusted captured Python, not a sandbox.

--packet is its source-audit directory; --raw-root supplies private Board HTML.
Every dependency is captured and authenticated before any captured code executes.
"""
import argparse
import hashlib
import json
import os
import platform
from pathlib import Path
import subprocess
import sys
import tempfile

FILES = ('build-dataset.py', 'h41_release.py', 'contract.json', 'capture-manifest.json',
         'acquisition-plan.json', 'version-exceptions.json', 'published-monthly.csv')
EXPECTED_CSV = '0a34cb9981964f78f250bc278e6fba64a677d5828c4816a9cec930ac49aa2119'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def runtime():
    return {'implementation': sys.implementation.name, 'version': platform.python_version()}


def relative(name):
    p = Path(name)
    if p.is_absolute() or '..' in p.parts or not p.parts or str(p) != name:
        raise ValueError('unsafe relative path')
    return p


def capture(packet, raw_root):
    freeze_raw = (packet/'source-replay-freeze.json').read_bytes()
    freeze = json.loads(freeze_raw)
    if freeze['schema'] != 'h41-source-replay-v1' or freeze['runtime'] != runtime():
        raise ValueError('runtime/schema mismatch')
    if set(freeze['files']) != set(FILES) or freeze['expected_csv_sha256'] != EXPECTED_CSV:
        raise ValueError('dependency inventory mismatch')
    owned = {}
    for name in FILES:
        data = (packet/name).read_bytes()
        if digest(data) != freeze['files'][name]:
            raise ValueError('packet identity mismatch: '+name)
        owned[name] = data
    if digest(owned['published-monthly.csv']) != EXPECTED_CSV:
        raise ValueError('expected CSV mismatch')
    manifest = json.loads(owned['capture-manifest.json'])
    plan = json.loads(owned['acquisition-plan.json'])
    contract = json.loads(owned['contract.json'])
    exceptions = json.loads(owned['version-exceptions.json'])
    ph = digest(owned['acquisition-plan.json'])
    if not manifest['complete'] or manifest['plan_sha256'] != ph or contract['acquisition_plan_sha256'] != ph or exceptions['plan_sha256'] != ph:
        raise ValueError('plan binding mismatch')
    if len(manifest['rows']) != 157 or len(plan['queries']) != 157:
        raise ValueError('row count mismatch')
    bodies = {}
    for row, query in zip(manifest['rows'], plan['queries']):
        if any(row[k] != query[k] for k in ('query', 'selected_release_date', 'url')):
            raise ValueError('row alignment mismatch')
        name = row['file']; p = relative(name)
        if len(p.parts) != 2 or p.parts[0] != 'monthly' or p.suffix != '.html' or name in bodies:
            raise ValueError('raw inventory/path mismatch')
        data = (raw_root/p).read_bytes()
        if len(data) != row['bytes'] or digest(data) != row['sha256'] or freeze['raw_files'].get(name) != row['sha256']:
            raise ValueError('raw identity mismatch: '+name)
        bodies[name] = data
    if set(bodies) != set(freeze['raw_files']):
        raise ValueError('raw inventory mismatch')
    return owned, bodies, digest(freeze_raw)


def replay(packet, raw_root, output_dir):
    if output_dir.exists():
        raise ValueError('output must be new')
    owned, bodies, freeze_sha = capture(packet, raw_root)
    with tempfile.TemporaryDirectory(prefix='h41-owned-') as td:
        private = Path(td).resolve()
        (private/'research').mkdir()
        (private/'research/__init__.py').write_bytes(b'')
        (private/'research/h41_release.py').write_bytes(owned['h41_release.py'])
        for name in ('build-dataset.py', 'contract.json', 'version-exceptions.json'):
            (private/name).write_bytes(owned[name])
        raw = private/'raw'; raw.mkdir(); (raw/'monthly').mkdir()
        (raw/'monthly-capture.json').write_bytes(owned['capture-manifest.json'])
        (raw/'monthly-acquisition-plan.json').write_bytes(owned['acquisition-plan.json'])
        for name, data in bodies.items():
            (raw/name).write_bytes(data)
        env = os.environ.copy()
        env.pop('PYTHONHOME', None)
        env['PYTHONPATH'] = str(private)
        env['PYTHONNOUSERSITE'] = '1'
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        subprocess.run([sys.executable, str(private/'build-dataset.py'), '--raw-root', str(raw),
                        '--contract', str(private/'contract.json'), '--exceptions', str(private/'version-exceptions.json'),
                        '--output-dir', str(private/'result')], cwd=private, env=env,
                       check=True, capture_output=True, timeout=60)
        actual = (private/'result/published-monthly.csv').read_bytes()
        if actual != owned['published-monthly.csv']:
            raise ValueError('reproduced CSV differs')
        receipt = (private/'result/dataset-receipt.json').read_bytes()
        output_dir.mkdir(parents=True, exist_ok=False)
        (output_dir/'published-monthly.csv').write_bytes(actual)
        (output_dir/'dataset-receipt.json').write_bytes(receipt)
        evidence = {'freeze_sha256': freeze_sha, 'dataset_sha256': digest(actual),
                    'raw_files_verified': len(bodies), 'exact_csv_match': True,
                    'scope': 'Trusted captured code, externally authenticated packet; not a Python sandbox or vintage certification.'}
        (output_dir/'verified-replay.json').write_text(json.dumps(evidence, indent=2)+'\n')
    return evidence


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ('packet', 'raw-root', 'output-dir'):
        parser.add_argument('--'+flag, type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(replay(args.packet.resolve(), args.raw_root.resolve(), args.output_dir.resolve()), sort_keys=True))
