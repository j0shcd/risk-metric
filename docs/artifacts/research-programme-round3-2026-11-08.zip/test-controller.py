"""Portable offline controller audit. Invoke with --packet PATH; no scores read."""
import argparse,hashlib,importlib.util,json,shutil,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
parser=argparse.ArgumentParser();parser.add_argument('--packet',type=Path,required=True);parser.add_argument('--report',type=Path,required=True)
ARGS,REST=parser.parse_known_args()
PACKET=ARGS.packet
EXPECTED_FREEZE='01268e59e0c4edd1d2952a39797d6ea5c047170cb1ab98a0afe0f4021eeddb45'
def sha(b):return hashlib.sha256(b).hexdigest()
freeze_raw=(PACKET/'generation-freeze.json').read_bytes();assert sha(freeze_raw)==EXPECTED_FREEZE
freeze=json.loads(freeze_raw);code=PACKET/'replay-generators.py';assert sha(code.read_bytes())==freeze['controller_sha256']
spec=importlib.util.spec_from_file_location('reviewed_replay',code);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
FILES=['replay-generators.py','generation-freeze.json','owned_indicator_input.py',*c.INPUTS]
FILES += ['generators/'+n+'/'+f for n in freeze['candidates'] for f in ['producer.py','config.json','worker.csv']]
REPORT={'freeze_sha256':EXPECTED_FREEZE,'controller_sha256':sha(code.read_bytes()),'tamper_cases':[],'replay':None}
class Tests(unittest.TestCase):
 def copy(self,path):
  for f in FILES:
   target=path/f;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((PACKET/f).read_bytes())
 def test_all_identity_tampering_precedes_captured_load(self):
  for file in [f for f in FILES if f!='generation-freeze.json']+['runtime']:
   with self.subTest(file=file),tempfile.TemporaryDirectory(prefix='round3-tamper-') as tmp:
    packet=Path(tmp)/'packet';self.copy(packet)
    if file=='runtime':
     doc=json.loads((packet/'generation-freeze.json').read_bytes());doc['runtime']['python']='0.0.0';(packet/'generation-freeze.json').write_text(json.dumps(doc))
    else:
     p=packet/file;p.write_bytes(p.read_bytes()+b'\nTAMPER')
    with patch.object(c,'__file__',str(packet/'replay-generators.py')),patch.object(c,'load',side_effect=AssertionError('captured Python loaded before validation')) as loader:
     with self.assertRaises(ValueError):c.own(packet)
     loader.assert_not_called()
    REPORT['tamper_cases'].append(file)
 def test_owned_snapshot_survives_replacement_and_isolates_frames(self):
  # One actual reviewed-source replay; originals are replaced only in this scratch copy.
  tmp=Path(tempfile.mkdtemp(prefix='round3-independent-replay-'));packet=tmp/'packet';self.copy(packet)
  with patch.object(c,'__file__',str(packet/'replay-generators.py')):owned=c.own(packet)
  for f in FILES:(packet/f).write_bytes(b'REPLACED AFTER OWN')
  real_load=c.load;seen=[];frame_refs=[]
  def spy_load(name,path):
   module=real_load(name,path)
   if name!='round3_owned_input':
    original=module.generate
    def wrapped(prices,macro,queries):
     self.assertEqual(len(prices),4018);self.assertEqual(len(macro),157)
     self.assertTrue(all(prices is not p and macro is not m for p,m in frame_refs));frame_refs.append((prices,macro))
     result=original(prices,macro,queries)
     # Destroy one producer's frames after generation: later arms must see fresh parses.
     prices.drop(prices.index,inplace=True);macro.drop(macro.index,inplace=True);seen.append(name)
     return result
    module.generate=wrapped
   return module
  with patch.object(c,'load',side_effect=spy_load):receipt=c.execute(owned,tmp/'replay')
  self.assertEqual(len(seen),3)
  previous=json.loads((PACKET/'reproduced/reproduction.json').read_bytes());self.assertEqual(receipt,previous)
  for name in freeze['candidates']:
   raw=(tmp/'replay'/name/'candidate.csv').read_bytes();self.assertEqual(raw,(PACKET/'generators'/name/'worker.csv').read_bytes());self.assertEqual(raw,(PACKET/'reproduced'/name/'candidate.csv').read_bytes())
  REPORT['replay']={'path':str(tmp/'replay'),'arms':seen,'rows_each':97,'receipt_exact':True,'csvs_exact':True,'fresh_frames_after_prior_arm_mutation':True,'source_paths_replaced_after_capture':True}
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests);result=unittest.TextTestRunner(verbosity=2).run(suite)
 REPORT.update(status='PASS' if result.wasSuccessful() else 'FAIL',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),script_sha256=sha(Path(__file__).read_bytes()),limitations=['Controller and captured Python are trusted reviewed source, not a sandbox. Authenticate external packet against independently trusted hash before importing.','Joint rewrite of packet and internal manifest is outside this tamper test; no claim of signature or adversarial-code containment.','No scorer, fitness paths, outcomes or network touched.'])
 ARGS.report.write_text(json.dumps(REPORT,indent=2)+'\n');raise SystemExit(not result.wasSuccessful())
