"""Read-only primitive arithmetic audit; no research modules or model/scorer calls."""
import hashlib, io, json, math
from pathlib import Path
import numpy as np
import pandas as pd
P=Path('/Users/josh/Documents/03_Projects/risk-metric/output/research-programme-round3-2026-11-08')
def load(p): return json.loads(p.read_bytes())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(x): return hashlib.sha256((json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()
errors={}; counts={}; warnings=[]
def close(kind,a,b):
 if a is None or b is None: assert a is b,(kind,a,b);return
 e=float(np.max(np.abs(np.asarray(a,dtype=float)-np.asarray(b,dtype=float))))
 errors[kind]=max(errors.get(kind,0),e)
 assert e<1e-10,(kind,e,a,b)
def key(r):return (r['date'],r['horizon'],r['target'])
def cellkey(r):return (r['role'],r['horizon'],r['target'])
def receipt(path):
 for f,h in load(path/'receipt.json')['files'].items():assert sha(path/f)==h,(path,f)
receipt(P)
manifest=load(P/'manifest.json');atlas=load(P/'benchmark_atlas.json');reproduction=load(P/'reproduced/reproduction.json')
assert sha(P/'benchmark_atlas.json')==manifest['benchmark_atlas_sha256']
assert sha(P/'references.json')==manifest['references_id']
assert atlas['atlas_id']==manifest['benchmark_atlas_id']
assert len(atlas['models'])==17 and len(set((m['name'],m['replica']) for m in atlas['models']))==17
assert sorted([list((m['name'],m['replica'])) for m in atlas['models']],key=str)==sorted(atlas['reference_inventory'],key=str)
for file,h in manifest['code_hashes'].items():assert sha(P.parents[1]/'research'/file)==h,file
raw=(P/'btc_daily.csv').read_bytes();assert hashlib.sha256(raw).hexdigest()=='d6e0e23e4d84e32690cea42cc0bf69f44ddfe9d954939b54ba499635431ed04c'
prices=pd.read_csv(io.BytesIO(raw),parse_dates=['Date']).set_index('Date').Price
logs=np.log(prices);support=manifest['support'];assert len(support)==97
macro_raw=(P/'fed_published_monthly.csv').read_bytes()
assert hashlib.sha256(macro_raw).hexdigest()=='0a34cb9981964f78f250bc278e6fba64a677d5828c4816a9cec930ac49aa2119'
macro=pd.read_csv(io.BytesIO(macro_raw),parse_dates=['Date']);asset={}
for row in macro.itertuples():
 assert row.Date not in asset
 if row.available==0:asset[row.Date]=None;continue
 assert row.available==1 and math.isfinite(row.assets_usd_millions) and row.assets_usd_millions>0
 printed=pd.Timestamp(row.printed_release_date);indexed=pd.Timestamp(row.indexed_release_date);obs=pd.Timestamp(row.observation_date)
 assert printed==indexed and 2<=(row.Date-printed).days<=14 and obs.weekday()==2 and 0<=(printed-obs).days<=7
 assert row.version_tier in ('B','C')
 asset[row.Date]=float(row.assets_usd_millions)
freeze=load(P/'generation-freeze.json')
assert sha(P/'generation-freeze.json')=='01268e59e0c4edd1d2952a39797d6ea5c047170cb1ab98a0afe0f4021eeddb45'
assert reproduction['generation_freeze_sha256']==sha(P/'generation-freeze.json')
assert freeze['runtime']==reproduction['runtime']==manifest['runtime']
assert sha(P/'replay-generators.py')==freeze['controller_sha256']
assert sha(P/'owned_indicator_input.py')==freeze['helper_sha256']
for file,h in freeze['inputs'].items():assert sha(P/file)==h
for name,item in freeze['candidates'].items():
 for k,v in item.items():assert reproduction['candidates'][name][k]==v
 for kind,field in [('price_evidence','btc_daily.csv'),('macro_evidence','fed_published_monthly.csv')]:
  evidence=reproduction['candidates'][name][kind]
  assert evidence['input_sha256']==freeze['inputs'][field] and evidence['input_bytes']==(P/field).stat().st_size

TARGETS=['terminal_log_return','entry_adverse_log_loss','peak_drawdown_log_loss']
contexts={}
for d in support:
 q=pd.Timestamp(d);ctx=[logs[q]-logs[q-pd.DateOffset(years=1)],np.std(np.diff(logs.loc[q-pd.Timedelta(days=90):q]),ddof=1)]
 contexts[d]=ctx
labels={}
for d in support:
 for h in (12,24,48):
  entry=pd.Timestamp(d)+pd.Timedelta(days=1);end=entry+pd.DateOffset(months=h);avail=end+pd.Timedelta(days=1)
  if end<=logs.index[-1]:
   path=logs.loc[entry:end].to_numpy();v=[path[-1]-path[0],path[0]-min(path),max(np.maximum.accumulate(path)-path)]
   for t,y in zip(TARGETS,v):labels[(d,h,t)]=(float(y),avail.strftime('%Y-%m-%d'))
def loss(x,w,y):return float(sum(w*abs(x-y))-.5*sum(w[i]*w[j]*abs(x[i]-x[j]) for i in range(len(x)) for j in range(len(x))))
def metrics(r):
 x=np.asarray(r['atoms']);w=np.asarray(r['candidate_weights']);y=r['outcome']
 if y is None:return {}
 mask=x<0 if r['target']==TARGETS[0] else x>math.log(2)
 event=y<0 if r['target']==TARGETS[0] else y>math.log(2)
 prob=float(sum(w[mask]));out={'crps':loss(x,w,y),'brier':(prob-event)**2}
 order=np.argsort(x);xx=x[order];ww=w[order];cs=np.cumsum(ww)
 for level,tail in [(50,.25),(80,.1)]:
  lo=xx[min(np.searchsorted(cs,tail),len(x)-1)];hi=xx[min(np.searchsorted(cs,1-tail),len(x)-1)]
  out['coverage_'+str(level)]=float(lo<=y<=hi);out['width_'+str(level)]=float(hi-lo)
 return out
primary={};totalpred=totalscored=totalcells=totalguards=0
for attempt in sorted((P/'attempts').iterdir()):
 if not attempt.is_dir():continue
 receipt(attempt);name=attempt.name.split('--')[1];rep=reproduction['candidates'][name]
 trial=load(attempt/'trial.json');result=trial['result'];front=load(attempt/'frontier.json');req=load(attempt/'request.json')
 assert load(attempt/'outcome.json')['status']=='completed'
 for f,field in [('producer.bin','producer_sha256'),('config.bin','config_sha256'),('candidate.csv','output_sha256')]:assert sha(attempt/f)==rep[field]
 assert (attempt/'producer.bin').read_bytes()==(P/'generators'/name/'producer.py').read_bytes()
 assert (attempt/'config.bin').read_bytes()==(P/'generators'/name/'config.json').read_bytes()
 assert (attempt/'candidate.csv').read_bytes()==(P/'generators'/name/'worker.csv').read_bytes()==(P/'reproduced'/name/'candidate.csv').read_bytes()
 assert trial['candidate_csv_sha256']==rep['output_sha256']
 for k,v in atlas['identity'].items():assert result[k]==v,k
 csv=pd.read_csv(attempt/'candidate.csv');vals=dict(zip(csv.Date,csv[rep['column']]))
 assert list(csv.Date)==support
 for row in trial['candidate']['values']:close('csv_values',vals[row['date']],row['value'])
 # Independently calculate all97 scalars with count/range/raw-moment formulas.
 for d in support:
  q=pd.Timestamp(d)
  if name=='level':
   prior=[v for day,v in asset.items() if q-pd.offsets.MonthEnd(36)<=day<q and v is not None]
   v=asset.get(q);expected=.5
   if v is not None and len(prior)>=30:expected=(sum(x<v for x in prior)+.5*sum(x==v for x in prior))/len(prior)
   assert int(csv.loc[csv.Date==d,'valid_prior_n'].iloc[0])==len(prior)
  else:
   ds=list(pd.date_range(end=q,periods=13,freq='ME'));vs=[asset.get(day) for day in ds];expected=50.
   if name=='change':
    if all(v is not None for v in vs):
     g=[math.log(vs[i])-math.log(vs[i-1]) for i in range(1,13)];den=sum(abs(x) for x in g)
     if den:expected=50+50*(sum(g[6:])-sum(g[:6]))/den
    assert int(csv.loc[csv.Date==d,'missing_months'].iloc[0])==sum(v is None for v in vs)
   else:
    pairs=[]
    for i in range(1,13):
     if vs[i] is not None and vs[i-1] is not None:
      p0=prices[ds[i-1]-pd.Timedelta(days=1)];p1=prices[ds[i]-pd.Timedelta(days=1)]
      pairs.append((math.log(p1)-math.log(p0),math.log(vs[i])-math.log(vs[i-1])))
    diag=next(r for r in rep['diagnostics'] if r['Date']==d);assert diag['valid_pairs']==len(pairs)
    if vs[-1] is not None and len(pairs)>=9:
     n=len(pairs);sx=sum(a for a,b in pairs);sy=sum(b for a,b in pairs)
     vx=sum(a*a for a,b in pairs)-sx*sx/n;vy=sum(b*b for a,b in pairs)-sy*sy/n
     if vx/n>1e-20 and vy/n>1e-20:expected=50+50*(sum(a*b for a,b in pairs)-sx*sy/n)/math.sqrt(vx*vy)
  close('candidate_'+name,expected,vals[d])
 predictions={key(r):r for r in result['predictions']};base={key(r):r for r in atlas['models'][0]['records']}
 assert predictions.keys()==base.keys()
 computed={}
 for k,r in predictions.items():
  totalpred+=1;assert len(r['atoms'])==24
  h=r['horizon'];d=r['date'];target=r['target']
  eligible=[s for s in support if s<d and (s,h,target) in labels and labels[s,h,target][1]<d][-24:]
  assert eligible==r['train_dates']
  close('atoms',[labels[s,h,target][0] for s in eligible],r['atoms'])
  f=np.array([contexts[s]+[vals[s]] for s in eligible]);query=np.array(contexts[d]+[vals[d]]);cuts=np.median(f,axis=0)
  close('thresholds',cuts,r['thresholds']);m=np.all((f[:,:2]>cuts[:2])==(query[:2]>cuts[:2]),axis=1);c=m&((f[:,2]>cuts[2])==(query[2]>cuts[2]));u=np.ones(24)/24
  wr=.5*u+.5*m/sum(m) if m.any() else u;wc=.5*u+.5*c/sum(c) if c.any() else wr
  close('reference_weights',wr,r['reference_weights']);close('candidate_weights',wc,r['candidate_weights'])
  assert r['candidate_cell_n']==sum(c) and r['context_cell_n']==sum(m)
  assert r['candidate_fallback']==(not c.any()) and r['context_fallback']==(not m.any())
  for field in ('role','outcome','entry','end','label_available'):assert r[field]==base[k][field]
  if r['status']=='scored':
   totalscored+=1;close('outcome',r['outcome'],labels[k][0]);x=np.array(r['atoms']);y=r['outcome']
   for field,w in [('candidate_crps',wc),('reference_crps',wr),('unconditional_crps',u)]:close('crps',loss(x,w,y),r[field])
  computed[k]=metrics(r)
 for model in atlas['models']:
  refs={key(r):r for r in model['records']}
  for cell in [c for c in front['cells'] if c['reference']==model['name'] and c['replica']==model['replica']]:
   totalcells+=1;group=[k for k,r in base.items() if cellkey(r)==cellkey(cell)]
   scored=[k for k in group if predictions[k]['status']=='scored' and refs[k]['status']=='scored'];failed=[k for k in group if refs[k]['status']=='numerical_failure']
   assert cell['requested_n']==len(group) and cell['scored_n']==len(scored) and cell['failure_n']==len(failed)
   assert cell['unavailable_n']==len(group)-len(scored)-len(failed)
   assert cell['scored_origins_id']==digest(sorted(k[0] for k in scored))
   assert cell['extra_reference_origins_excluded_n']==sum(cellkey(r)==cellkey(cell) and k not in base for k,r in refs.items())
   complete=len(scored)==sum(predictions[k]['status']=='scored' for k in group) and not failed
   for metric in ('crps','brier','coverage_50','coverage_80','width_50','width_80'):
    cm=float(np.mean([computed[k][metric] for k in scored])) if complete and scored else None
    rm=float(np.mean([refs[k][metric] for k in scored])) if complete and scored else None
    delta=float(np.mean([refs[k][metric]-computed[k][metric] for k in scored])) if complete and scored else None
    close('cell_candidate_'+metric,cm,cell['candidate'][metric]);close('cell_reference_'+metric,rm,cell['reference_means'][metric]);close('cell_delta_'+metric,delta,cell['reference_minus_candidate'][metric])
 for guard in front['mc_guards']:
  totalguards+=1;cs=[next(c for c in front['cells'] if c['reference']=='generative' and c['replica']==i and cellkey(c)==cellkey(guard)) for i in (0,1)]
  gains=[c['reference_minus_candidate'][guard['metric']] for c in cs];assert gains==guard['replica_gains']
  passed=all(g is not None and g>0 for g in gains) and abs(gains[0]-gains[1])<.2*min(gains)
  assert passed==guard['numerically_stable_gain']
 for cell in result['cells']:
  rows=[r for r in predictions.values() if cellkey(r)==cellkey(cell) and r['status']=='scored']
  assert len(rows)==cell['scored_n']
  if rows:close('trial_cell_crps',np.mean([computed[key(r)]['crps'] for r in rows]),cell['candidate_mean_crps'])
 primary[name]=next(c['candidate_mean_crps'] for c in result['cells'] if cellkey(c)==('development',24,TARGETS[0]))
 best=min(c['reference_means']['crps'] for c in front['cells'] if cellkey(c)==('development',24,TARGETS[0]) and c['reference_means']['crps'] is not None)
 close('primary_best_reference',best,0.33107363984732724)
 assert primary[name]>best
 assert not any(r['status']=='scored' and r['horizon']==48 for r in predictions.values())
 if result['direction']=='higher_risk':warnings.append(name+': API higher_risk metadata is arbitrary ordering convention; registered mechanism is undirected. Does not affect distribution losses.')
 assert len(front['cells'])==765 and len(front['mc_guards'])==90
counts={'attempts':3,'predictions':totalpred,'scored_predictions':totalscored,'frontier_cells':totalcells,'mc_guards':totalguards,'candidate_scalar_values':291,'reference_models':17}
report={'status':'PASS_arithmetic_with_direction_metadata_caveat','counts':counts,'max_absolute_errors':errors,'primary24m_crps':primary,'warnings':warnings,'limitations':['No scorer, generator or model modules imported/executed. No new trials, network or FRED payloads. Only admitted Board monthly levels and owned BTC used.','Generative reference fair losses trusted from immutable previously audited atlas; samples not regenerated.','Candidate source/config/worker/root reproduction byte identity verified; scalars independently reconstructed from two admitted owned inputs.','Reconstructed Tier B/C Board levels, zero verified originals; historical timing/revision limitations remain. Exposed development history is not fresh holdout. No secondary rescue or performance qualification.'],'campaign_manifest_sha256':sha(P/'manifest.json'),'atlas_sha256':sha(P/'benchmark_atlas.json'),'script_sha256':sha(Path(__file__))}
Path('/private/tmp/round3-independent-score-audit-b.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2))
