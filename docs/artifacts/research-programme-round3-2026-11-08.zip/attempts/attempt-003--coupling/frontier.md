# Benchmark frontier comparison

Completed measurement; no automatic promotion. Positive loss delta favors candidate; coverage/width are separate tradeoffs.

| Role | Months | Target | Reference | Replica | Scored / failed / unavailable | CRPS delta | Brier delta | 50% coverage delta / width delta | 80% coverage delta / width delta |
|---|---:|---|---|---:|---|---:|---:|---|---|
| development | 12 | terminal_log_return | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.064998 | 0.054387 | 0.020833 / -0.032125 | 0.020833 / 0.040748 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.008205 | 0.046794 | 0.083333 / 0.069199 | -0.020833 / 0.002189 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | -0.008469 | -0.027031 | -0.041667 / 0.040148 | 0.020833 / 0.065267 |
| development | 24 | terminal_log_return | direct_cdf:dca_risk | None | 24 / 0 / 0 | -0.083039 | 0.000000 | 0.416667 / 0.339319 | 0.000000 / 0.098796 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | 0.015266 | 0.016670 | -0.125000 / 0.085564 | 0.000000 / 0.003646 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | -0.087100 | -0.033420 | 0.125000 / 0.182688 | 0.000000 / 0.029413 |
| development | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.088437 | 0.058542 | 0.000000 / -0.027463 | 0.020833 / 0.063495 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.015713 | 0.046417 | 0.062500 / 0.050611 | -0.020833 / 0.003677 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | -0.007750 | -0.042982 | -0.104167 / 0.027713 | 0.020833 / 0.085560 |
| development | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.080542 | 0.000000 | 0.416667 / 0.282835 | 0.000000 / 0.048171 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | 0.007290 | 0.010665 | -0.083333 / 0.087474 | 0.000000 / -0.015025 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.076442 | -0.038194 | 0.041667 / 0.107777 | 0.000000 / 0.029413 |
| development | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.069527 | 0.091260 | 0.041667 / -0.004843 | 0.020833 / 0.023162 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.022682 | 0.097238 | 0.062500 / 0.058817 | -0.041667 / -0.002250 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | -0.010874 | -0.044719 | -0.062500 / 0.076025 | 0.041667 / 0.096461 |
| development | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | -0.067002 | 0.000000 | 0.416667 / 0.403794 | 0.000000 / 0.206550 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | 0.014290 | 0.012121 | -0.041667 / 0.082390 | 0.000000 / 0.003646 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | -0.093995 | -0.032068 | 0.250000 / 0.240257 | 0.041667 / 0.055156 |
| development | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | 0.047492 | 0.051493 | 0.020833 / -0.085495 | 0.020833 / -0.053259 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | 0.013471 | 0.040410 | 0.041667 / 0.021942 | -0.020833 / 0.002528 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | -0.005695 | -0.017239 | -0.062500 / 0.007716 | -0.020833 / 0.012665 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.034821 | 0.000000 | 0.458333 / 0.391994 | 0.000000 / 0.158260 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | 0.010745 | 0.009006 | -0.041667 / 0.071078 | 0.000000 / 0.003646 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.100336 | -0.020517 | 0.166667 / 0.198765 | 0.041667 / 0.055156 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.107342 | 0.058542 | 0.000000 / -0.025825 | 0.000000 / 0.039892 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.017204 | 0.048840 | 0.041667 / 0.041077 | -0.020833 / 0.000535 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | -0.010413 | -0.046424 | -0.104167 / 0.033658 | 0.041667 / 0.091089 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.087147 | 0.000000 | 0.416667 / 0.203612 | 0.000000 / 0.062128 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | 0.011409 | 0.013021 | -0.083333 / 0.083137 | 0.000000 / 0.000097 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.071117 | -0.046441 | -0.041667 / 0.034155 | -0.041667 / -0.007661 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | 0.039465 | 0.067420 | 0.020833 / 0.125441 | 0.041667 / 0.110838 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | 0.004122 | 0.034980 | 0.104167 / 0.108173 | 0.000000 / 0.012672 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | -0.017775 | -0.047082 | 0.020833 / 0.056156 | 0.041667 / 0.107924 |
| development | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.062987 | 0.000000 | 0.416667 / 0.398685 | 0.000000 / 0.206550 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | 0.012069 | 0.010642 | 0.000000 / 0.092868 | 0.000000 / 0.003646 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.093242 | -0.032068 | 0.250000 / 0.235261 | 0.041667 / 0.050159 |
| development | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | 0.039465 | 0.067420 | 0.020833 / 0.125441 | 0.041667 / 0.110838 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | 0.004122 | 0.034980 | 0.104167 / 0.108173 | 0.000000 / 0.012672 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | -0.017775 | -0.047082 | 0.020833 / 0.056156 | 0.041667 / 0.107924 |
| development | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.062987 | 0.000000 | 0.416667 / 0.398685 | 0.000000 / 0.206550 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | 0.012069 | 0.010642 | 0.000000 / 0.092868 | 0.000000 / 0.003646 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.093242 | -0.032068 | 0.250000 / 0.235261 | 0.041667 / 0.050159 |
| development | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.056769 | 0.048571 | 0.041667 / 0.082293 | 0.020833 / -0.035940 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.017299 | 0.033057 | 0.062500 / 0.073808 | -0.020833 / -0.009551 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | -0.003498 | -0.042422 | -0.083333 / 0.024044 | 0.020833 / 0.063065 |
| development | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | -0.047589 | 0.000000 | 0.291667 / 0.257350 | 0.000000 / 0.081269 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | 0.000779 | 0.000000 | -0.041667 / 0.034259 | 0.000000 / 0.003575 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | -0.080053 | -0.052951 | 0.166667 / 0.083387 | 0.000000 / -0.014089 |
| development | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | 0.034550 | 0.053639 | 0.000000 / -0.186769 | 0.000000 / -0.039868 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | 0.015600 | 0.050495 | 0.041667 / 0.025445 | -0.020833 / 0.003114 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | -0.008274 | -0.041008 | -0.104167 / 0.011432 | 0.000000 / 0.095820 |
| development | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | -0.033494 | 0.000000 | 0.458333 / 0.395805 | 0.000000 / 0.210322 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | 0.014424 | 0.013021 | 0.000000 / 0.090083 | 0.000000 / 0.003646 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | -0.116369 | -0.035214 | 0.166667 / 0.117028 | 0.041667 / 0.055156 |
| development | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.106599 | 0.056458 | 0.020833 / 0.037316 | 0.000000 / -0.054747 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.026203 | 0.064647 | 0.062500 / 0.062133 | -0.041667 / -0.006836 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.011664 | -0.001015 | -0.104167 / 0.019263 | -0.041667 / 0.049463 |
| development | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | -0.012639 | 0.000000 | 0.333333 / 0.367934 | 0.000000 / 0.136909 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | 0.010154 | 0.005642 | -0.041667 / 0.075269 | 0.000000 / 0.003575 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | -0.083529 | -0.000434 | 0.125000 / 0.129163 | 0.000000 / 0.003438 |
| development | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.106067 | 0.073857 | -0.020833 / -0.042267 | -0.041667 / -0.047927 |
| development | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.009451 | 0.072021 | 0.083333 / 0.060813 | -0.041667 / -0.026503 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | -0.012337 | -0.031623 | 0.000000 / 0.087068 | 0.041667 / 0.075813 |
| development | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | -0.104908 | 0.000000 | 0.333333 / 0.052085 | 0.000000 / 0.035751 |
| development | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | 0.052142 | 0.039427 | -0.125000 / 0.039858 | -0.083333 / -0.001061 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | -0.056810 | -0.037656 | 0.208333 / 0.151418 | 0.000000 / 0.028168 |
| development | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | 0.081154 | 0.078007 | 0.041667 / 0.107586 | 0.041667 / 0.026454 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | 0.002058 | 0.035657 | 0.083333 / 0.093004 | 0.000000 / 0.011184 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | -0.021395 | -0.055210 | 0.041667 / 0.044791 | 0.020833 / 0.083812 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | -0.049260 | 0.000000 | 0.375000 / 0.298173 | 0.000000 / 0.149012 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | 0.014099 | 0.010642 | -0.083333 / 0.080631 | 0.000000 / 0.003575 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | -0.092751 | -0.012483 | 0.208333 / 0.187129 | 0.041667 / 0.050159 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | -0.004450 | 0.071542 | 0.062500 / -0.172835 | 0.041667 / 0.024243 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | 0.020909 | 0.050739 | 0.062500 / -0.007772 | -0.020833 / -0.004951 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | 0.010286 | -0.029395 | -0.083333 / 0.061165 | 0.020833 / 0.081431 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | 0.014866 | 0.000000 | 0.291667 / 0.400371 | 0.000000 / 0.251407 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | 0.005626 | 0.000000 | 0.041667 / 0.025224 | 0.000000 / 0.003646 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | -0.101280 | -0.021814 | 0.208333 / 0.173826 | 0.041667 / 0.037745 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | context | None | 48 / 0 / 0 | 0.039465 | 0.067420 | 0.020833 / 0.125441 | 0.041667 / 0.110838 |
| development | 12 | entry_adverse_log_loss | context | None | 48 / 0 / 0 | 0.004122 | 0.034980 | 0.104167 / 0.108173 | 0.000000 / 0.012672 |
| development | 12 | peak_drawdown_log_loss | context | None | 48 / 0 / 0 | -0.017775 | -0.047082 | 0.020833 / 0.056156 | 0.041667 / 0.107924 |
| development | 24 | terminal_log_return | context | None | 24 / 0 / 0 | -0.062987 | 0.000000 | 0.416667 / 0.398685 | 0.000000 / 0.206550 |
| development | 24 | entry_adverse_log_loss | context | None | 24 / 0 / 0 | 0.012069 | 0.010642 | 0.000000 / 0.092868 | 0.000000 / 0.003646 |
| development | 24 | peak_drawdown_log_loss | context | None | 24 / 0 / 0 | -0.093242 | -0.032068 | 0.250000 / 0.235261 | 0.041667 / 0.050159 |
| development | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | unconditional | None | 48 / 0 / 0 | 0.043176 | 0.126383 | 0.041667 / 0.181896 | 0.041667 / 0.199114 |
| development | 12 | entry_adverse_log_loss | unconditional | None | 48 / 0 / 0 | 0.012791 | 0.056641 | 0.104167 / 0.146154 | 0.020833 / 0.046510 |
| development | 12 | peak_drawdown_log_loss | unconditional | None | 48 / 0 / 0 | 0.000726 | -0.023998 | -0.062500 / 0.136319 | 0.041667 / 0.064547 |
| development | 24 | terminal_log_return | unconditional | None | 24 / 0 / 0 | -0.185714 | 0.002658 | 0.666667 / 0.601833 | 0.041667 / 0.310400 |
| development | 24 | entry_adverse_log_loss | unconditional | None | 24 / 0 / 0 | 0.023084 | 0.037489 | -0.125000 / 0.206061 | 0.166667 / 0.145334 |
| development | 24 | peak_drawdown_log_loss | unconditional | None | 24 / 0 / 0 | -0.089804 | -0.095757 | 0.208333 / 0.394790 | 0.041667 / 0.101725 |
| development | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 0 | 48 / 0 / 0 | -0.160389 | 0.067331 | 0.104167 / -0.132637 | 0.125000 / -0.266184 |
| development | 12 | entry_adverse_log_loss | generative | 0 | 48 / 0 / 0 | -0.042915 | -0.012450 | -0.104167 / -0.006326 | -0.020833 / -0.039416 |
| development | 12 | peak_drawdown_log_loss | generative | 0 | 48 / 0 / 0 | 0.046686 | 0.240839 | -0.208333 / 0.116437 | -0.125000 / 0.190433 |
| development | 24 | terminal_log_return | generative | 0 | 24 / 0 / 0 | 0.188402 | 0.094137 | 0.166667 / 0.560409 | -0.375000 / 0.502309 |
| development | 24 | entry_adverse_log_loss | generative | 0 | 24 / 0 / 0 | -0.071747 | -0.014050 | 0.083333 / 0.308575 | 0.250000 / 0.450068 |
| development | 24 | peak_drawdown_log_loss | generative | 0 | 24 / 0 / 0 | -0.115362 | 0.204475 | 0.166667 / 0.149167 | 0.000000 / 0.113963 |
| development | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 1 | 48 / 0 / 0 | -0.162086 | 0.066904 | 0.083333 / -0.137955 | 0.145833 / -0.269488 |
| development | 12 | entry_adverse_log_loss | generative | 1 | 48 / 0 / 0 | -0.043166 | -0.013148 | -0.104167 / -0.007104 | -0.020833 / -0.042488 |
| development | 12 | peak_drawdown_log_loss | generative | 1 | 48 / 0 / 0 | 0.046185 | 0.240579 | -0.208333 / 0.116527 | -0.145833 / 0.189049 |
| development | 24 | terminal_log_return | generative | 1 | 24 / 0 / 0 | 0.189840 | 0.095399 | 0.208333 / 0.562091 | -0.375000 / 0.490762 |
| development | 24 | entry_adverse_log_loss | generative | 1 | 24 / 0 / 0 | -0.071451 | -0.013410 | 0.041667 / 0.309078 | 0.250000 / 0.451492 |
| development | 24 | peak_drawdown_log_loss | generative | 1 | 24 / 0 / 0 | -0.114421 | 0.204073 | 0.125000 / 0.151041 | 0.000000 / 0.112793 |
| development | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |

MC guard (numerical only, not significance):
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [-0.1603885690203527, -0.16208569632742187], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.06733057796765102, 0.06690442475913075], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.042915427649519555, -0.04316616018630486], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.012449633280263694, -0.013148453281152307], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [0.046686175783016516, 0.04618462648615828], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.24083909696165193, 0.24057920388636353], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [0.188401964367335, 0.18983987379276998], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.09413701770599477, 0.09539876736477615], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.07174708568238496, -0.0714513284170612], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.014049774151845107, -0.013409740820037841], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [-0.1153624230193528, -0.11442117755527066], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.20447474637644295, 0.20407315327963063], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}

Fixed-direction ordering, separate from forecast quality:
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': 0.3007188417535689, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.2123716437088888, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.09714570824344952, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': -0.048041674705768866, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.11865838339966717, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.052322651088136815, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': 0.5301780286582718, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.2819594203112633, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': -0.6223169529672881, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
