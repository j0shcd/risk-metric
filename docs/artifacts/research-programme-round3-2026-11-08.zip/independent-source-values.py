"""Offline independent text-stream audit; imports no project extractor or model."""
import re,html,json,hashlib,datetime
from pathlib import Path
ROOT=Path('/Users/josh/Documents/03_Projects/risk-metric/data/external_private/fed-h41-audit-2026-11-08')
sha=lambda b:hashlib.sha256(b).hexdigest()
TITLE='Consolidated Statement of Condition of All Federal Reserve Banks'
DATE=r'(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2},\s+\d{4}'
def date(s):
 for fmt in ('%b %d, %Y','%B %d, %Y'):
  try:return datetime.datetime.strptime(s,fmt).date()
  except ValueError:pass
 raise ValueError(s)
def extract(raw):
 # Independent primitive: erase tags, decode entities and normalize to one logical
 # text stream. No fixed-column offsets, DOM ids, project helpers or prior values.
 s=raw.decode('utf-8',errors='replace')
 s=re.sub(r'<(?:script|style)\b[^>]*>.*?</(?:script|style)>',' ',s,flags=re.S|re.I)
 s=re.sub(r'<!--.*?-->',' ',s,flags=re.S)
 t=re.sub(r'\s+',' ',html.unescape(re.sub(r'<[^>]+>',' ',s))).strip()
 rm=re.search(r'Release Date:\s*(?:(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday),\s*)?('+DATE+')',t)
 assert rm,'missing printed release date'
 release=date(rm[1])
 starts=[m.start() for m in re.finditer(re.escape(TITLE)+r'(?: \(continued\))? Millions of dollars',t)]
 assert len(starts)==2,(len(starts),'ambiguous consolidated sections')
 section=t[starts[0]:starts[1]]
 assert 'Millions of dollars' in section[:150]
 header=section[:section.index('Gold certificate account')]
 ds=re.findall(DATE,header);assert len(ds)==3,ds
 obs,week,year=map(date,ds)
 assert obs.weekday()==week.weekday()==year.weekday()==2
 assert obs>week>year and (obs-week).days==7
 assert 'Eliminations' in header and 'Change since' in header and 'Wednesday' in header
 # Parenthesized consolidation eliminations precede the actual current value.
 ms=list(re.finditer(r'Total assets\s+\(([\d,]+)\)\s+([\d,]+)\s+([+-]?\s*[\d,]+)\s+([+-]?\s*[\d,]+)',section))
 assert len(ms)==1,'ambiguous consolidated total'
 m=ms[0];v=int(m[2].replace(',',''));elim=int(m[1].replace(',',''))
 assert v>0 and obs<=release
 district=t[t.index('Statement of Condition of Each Federal Reserve Bank',starts[1]):]
 dm=re.search(r'Total assets\s+([\d,]+)',district);assert dm,'missing district decoy'
 return {'release_date':release.isoformat(),'observation_date':obs.isoformat(),'total_assets_usd_millions':v,'eliminations_usd_millions':elim,'district_total_usd_millions':int(dm[1].replace(',','')),'logical_row':m[0],'header':header}
def run():
 capraw=(ROOT/'monthly-capture.json').read_bytes();cap=json.loads(capraw);assert cap['complete'] and len(cap['rows'])==157
 refraw=(ROOT/'first-extraction.json').read_bytes();ref=json.loads(refraw);assert ref['capture_manifest_sha256']==sha(capraw)
 refs={r['query']:r for r in ref['rows']};records=[];errors=[]
 for c in cap['rows']:
  raw=(ROOT/c['file']).read_bytes();assert sha(raw)==c['sha256'] and len(raw)==c['bytes']
  try:
   r=extract(raw);b=refs[c['query']];r.update(query=c['query'],raw_sha256=sha(raw),selected_release_date=c['selected_release_date'],reference_status=b['status'])
   if b['status']=='extracted':
    for k in ('release_date','observation_date','total_assets_usd_millions'):assert r[k]==b[k],(k,r[k],b[k])
    assert r['raw_sha256']==b['source_sha256']
   r['independent_timing_pass']=r['release_date']<=c['cutoff'] and r['release_date']==c['selected_release_date']
   records.append(r)
  except Exception as e:errors.append({'query':c['query'],'error':str(e)})
 out={'scope':'All owned monthly HTML; no B extractor import/call, model, outcome, network or repository edit. Numeric agreement does not authenticate original vintage.','script_sha256':sha(Path(__file__).read_bytes()),'capture_manifest_sha256':sha(capraw),'reference_extraction_sha256':sha(refraw),'timing_policy':'Query q at00UTC; printed release calendar date <=q minus2calendar days inclusive, plus indexed/printed date agreement. The threshold is a calendar date, not an assertion of availability at threshold00UTC.', 'raw_hashes_verified':157,'benchmark_accepted_exact_comparisons':sum(r['reference_status']=='extracted' and '2014-12-31'<=r['query']<='2022-12-31' for r in records),'independent_extractions':len(records),'accepted_exact_comparisons':sum(r['reference_status']=='extracted' for r in records),'errors':errors,'timing_failures':[r for r in records if not r['independent_timing_pass']],'nonzero_elimination_witnesses':sum(r['eliminations_usd_millions']!=0 for r in records),'district_total_differs_witnesses':sum(r['district_total_usd_millions']!=r['total_assets_usd_millions'] for r in records),'records':records,'version_tiers_accepted':{'B':9,'C':147},'version_tier_source':'Prior independent notice audit; rejected November2019 was C.','limitations':'Stream extraction explicitly requires one current consolidated section, three ordered Wednesday dates, parenthesized eliminations and separate district section. This is independent numerical verification of captured versions, not original publication verification.'}
 Path('/private/tmp/h41-independent-values-a-20261108.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:v for k,v in out.items() if k not in ('records','timing_failures')},indent=2));print('timing',[(r['query'],r['release_date'],r['selected_release_date']) for r in out['timing_failures']])
if __name__=='__main__':run()
