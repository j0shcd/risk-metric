Round three, November 8 2026: three failed macro/price scalar hypotheses.
Authenticate this ZIP against its external SHA in the canonical research record BEFORE executing Python.
Captured code is trusted reviewed Python, not sandboxed. No model is promoted.

Registered research runtime: CPython3.12.16, NumPy2.4.6, pandas2.3.3.
From this directory:
 python replay-generators.py --packet . --output-dir NEW_GENERATOR_DIRECTORY
 python audit-scores.py --packet . --source-root benchmark-code --output NEW_REPORT.json
 python -m unittest discover -s tests
 python test-controller.py --packet . --report NEW_CONTROLLER_REPORT.json

These replay the exact3x97candidateCSVs, independently reconstruct all recorded
comparisons, run focused source/candidate tests, and exercise14controller tampercases.
Both input tables are owned immutable bytes, with fresh frames for every arm.
Numerical identity is enforced exactly for generator CSVs; portability across a
different numeric-library/platform build is not independently demonstrated.
Original generative reference samples are not regenerated; their audited atlas is retained.
The legacy raw macro bundle is omitted; rebuilding that original atlas needs its
separately identified frozen inputs. No new FRED payload or raw site HTML is here.

Board published-monthly levels are reconstructedTierB/C editions, zero authenticated
originals,156/157 source dates and96/97benchmark dates. Nov2019 remains unavailable;
fixed neutral rules are declared per candidate. Source-policy review is not PIT or
professional-use clearance. Capture metadata/hash/URLs are not model features.
All3scalars are undirected; trialAPI higher_risk is an arbitrary ordering convention.
Primary has24overlapping starts andone negative two-year return, not independent experiments.
All19indicator attempts and prior outerhistory remain exposed. No outerrelease orretune.

Optional full source reconstruction requires PRIVATE Board HTML capture directory RAW:
 python source-audit/replay-source.py --packet source-audit --raw-root RAW --output-dir NEW_SOURCE_DIRECTORY
 python test-source-replay.py --packet source-audit --raw-root RAW
The verified wrapper checks all frozen files and157raw bodies before executing
owned source code and requires exact source CSV identity. CPython3.12.16 semantic
runtime is required; host compiler/binary identity is evidence only. It never downloads.
The historical build-dataset.py is a trusted-input builder; use the verified wrapper.
Some original independent source-audit scripts retain historical absolute paths;
those are evidence, not portable entrypoints. The public source CSV is supplied.

The previous398/400known-law panel used a DIFFERENT forecasting/test procedure.
It does not certify sensitivity of this exact97date/latest24mature directCDF readout.
Next proposed bounded task is a preregistered synthetic sensitivity audit of that
unchanged readout, not a decoder change or a rescue of the19failed variants.
