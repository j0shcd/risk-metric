"""Authenticate and replay reviewed round-three transforms; no scoring/network.

Verify the enclosing published packet SHA first: hashes inside a jointly rewritten
packet do not authenticate it. Python is trusted reviewed source, not sandboxed.
Both input tables are parsed from exactly the immutable bytes attested, afresh
for each arm. All identities are checked before any captured Python executes.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import tempfile
import numpy as np
import pandas as pd

INPUTS = {'btc_daily.csv':'d6e0e23e4d84e32690cea42cc0bf69f44ddfe9d954939b54ba499635431ed04c',
          'fed_published_monthly.csv':'0a34cb9981964f78f250bc278e6fba64a677d5828c4816a9cec930ac49aa2119'}
SPECS = {
 'level': {'root':'/Users/josh/.codex/worktrees/research-round2-persistence/risk-metric','commit':'6319778','relative':'research/candidates/level_20261108/producer.py','csv':'output/round3-level-frozen-20261108/candidate.csv','column':'balance_sheet_state','csv_sha256':'3a39d4b482ce43cbbb4a5bf46212bf1ff6bda50de0d23f5d4d9e652f7aff60bc'},
 'change': {'root':'/Users/josh/.codex/worktrees/research-round3-change/risk-metric','commit':'fe2a333','relative':'research/candidates/change_20261108/producer.py','csv':'output/change-20261108-frozen/candidate.csv','column':'balance_growth_acceleration','csv_sha256':'9040f5216f23b08248e6408fa2bfad9554708fbc88c78f5f957f766ff736fefb'},
 'coupling': {'root':'/Users/josh/.codex/worktrees/research-round3-coupling/risk-metric','commit':'38eebdf','relative':'research/candidates/coupling_20261108/producer.py','csv':'/private/tmp/coupling-20261108-frozen-38eebdf/candidate.csv','column':'coupling_state','csv_sha256':'0b865f2e2aa94a77721c1897e341e22bf284206d937b741ddd76517f718a3c80'},
}


def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def runtime():return {'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__}
def checked(path,expected):
    raw=path.read_bytes()
    if sha(raw)!=expected:raise ValueError('identity mismatch: '+str(path))
    return raw


def capture(packet,project):
    folder=packet/'generators';folder.mkdir(exist_ok=False)
    source=Path('/private/tmp/research-round3-admitted-inputs-20261108')
    for name,digest in INPUTS.items():(packet/name).write_bytes(checked(source/name,digest))
    helper=(project/'research/owned_indicator_input.py').read_bytes()
    (packet/'owned_indicator_input.py').write_bytes(helper)
    manifest={'schema':'two-owned-input-transform-freeze-v1','runtime':runtime(),'inputs':INPUTS,
              'controller_sha256':sha(Path(__file__).read_bytes()),'helper_sha256':sha(helper),'candidates':{}}
    for name,item in SPECS.items():
        target=folder/name;target.mkdir()
        original=Path(item['root'])/item['relative']
        code=original.read_bytes();config=original.with_name('config.json').read_bytes()
        for relative,raw in [(item['relative'],code),(str(Path(item['relative']).with_name('config.json')),config)]:
            if raw!=subprocess.check_output(['git','show',item['commit']+':'+relative],cwd=project):
                raise ValueError('worker source differs from frozen commit')
        worker=checked(Path(item['root'])/item['csv'],item['csv_sha256'])
        for file,raw in [('producer.py',code),('config.json',config),('worker.csv',worker)]:(target/file).write_bytes(raw)
        manifest['candidates'][name]={'source_commit':item['commit'],'column':item['column'],
             'producer_sha256':sha(code),'config_sha256':sha(config),'output_sha256':sha(worker)}
    (packet/'generation-freeze.json').write_bytes(canonical(manifest))


def own(packet):
    freeze_raw=(packet/'generation-freeze.json').read_bytes();manifest=json.loads(freeze_raw)
    if manifest['runtime']!=runtime() or manifest['inputs']!=INPUTS or set(manifest['candidates'])!=set(SPECS):
        raise ValueError('unregistered runtime or input/candidate inventory')
    checked(Path(__file__),manifest['controller_sha256'])
    owned={'manifest':manifest,'freeze_sha256':sha(freeze_raw),
           'inputs':{name:checked(packet/name,digest) for name,digest in INPUTS.items()},
           'helper':checked(packet/'owned_indicator_input.py',manifest['helper_sha256']),'candidates':{}}
    for name,item in manifest['candidates'].items():
        root=packet/'generators'/name
        owned['candidates'][name]={file:checked(root/file,item[key]) for file,key in
            [('producer.py','producer_sha256'),('config.json','config_sha256'),('worker.csv','output_sha256')]}
    return owned


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module);return module


def execute(owned,output):
    manifest=owned['manifest'];queries=pd.date_range('2014-12-31','2022-12-31',freq='ME')
    generated={};receipt={'generation_freeze_sha256':owned['freeze_sha256'],'runtime':runtime(),'inputs':INPUTS,'candidates':{}}
    with tempfile.TemporaryDirectory(prefix='round3-owned-') as temp:
        private=Path(temp);helper=private/'owned_indicator_input.py';helper.write_bytes(owned['helper'])
        derive=load('round3_owned_input',helper).derive
        for name,files in owned['candidates'].items():
            root=private/name;root.mkdir()
            for file,raw in files.items():(root/file).write_bytes(raw)
            producer=load('round3_'+name,root/'producer.py')
            # No frames are shared between producers. Each sees owned input bytes.
            (result,macro_evidence),price_evidence=derive(owned['inputs']['btc_daily.csv'],INPUTS['btc_daily.csv'],
                lambda prices:derive(owned['inputs']['fed_published_monthly.csv'],INPUTS['fed_published_monthly.csv'],
                    lambda macro:producer.generate(prices,macro,queries)))
            diagnostics=None
            if isinstance(result,tuple):result,diagnostics=result
            column=manifest['candidates'][name]['column']
            if len(result)!=97 or list(result.Date)!=list(queries.strftime('%Y-%m-%d')) or not np.isfinite(result[column]).all():
                raise ValueError('candidate support/finite mismatch')
            raw=result.to_csv(index=False,float_format='%.17g').encode()
            if raw!=files['worker.csv']:raise ValueError('worker output not reproduced exactly: '+name)
            generated[name]=raw
            receipt['candidates'][name]={**manifest['candidates'][name],'price_evidence':price_evidence,
                'macro_evidence':macro_evidence,'rows':97,'worker_csv_exact':True,'diagnostics':diagnostics}
    output.mkdir(parents=True,exist_ok=False)
    for name,raw in generated.items():
        folder=output/name;folder.mkdir();(folder/'candidate.csv').write_bytes(raw)
    (output/'reproduction.json').write_bytes(canonical(receipt));return receipt


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True)
    parser.add_argument('--capture',action='store_true');parser.add_argument('--project',type=Path)
    args=parser.parse_args()
    if args.capture:
        if args.project is None:parser.error('--capture requires --project')
        capture(args.packet,args.project)
    result=execute(own(args.packet),args.output_dir)
    print(json.dumps({'generation_freeze_sha256':result['generation_freeze_sha256'],'outputs':{n:r['output_sha256'] for n,r in result['candidates'].items()},'rows_each':97},sort_keys=True))
