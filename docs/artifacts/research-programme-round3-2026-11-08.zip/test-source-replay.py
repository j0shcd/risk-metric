import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

import argparse, sys
parser = argparse.ArgumentParser(); parser.add_argument('--packet',type=Path,required=True); parser.add_argument('--raw-root',type=Path,required=True)
args, rest = parser.parse_known_args(); PACKET=args.packet; RAW=args.raw_root
spec = importlib.util.spec_from_file_location('verified', PACKET/'replay-source.py')
m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)


class ReplayTests(unittest.TestCase):
    def test_same_semantic_runtime_different_build_is_portable(self):
        with patch.object(m.sys, 'version', '3.12.16 (main, Nov 8 2026, 00:00:00) [GCC 14.2.0]'), patch.object(m.sys, 'executable', '/nonexistent/different-python-binary'):
            owned, bodies, _ = m.capture(PACKET, RAW)
        self.assertEqual(len(bodies), 157)
        self.assertEqual(m.digest(owned['published-monthly.csv']), m.EXPECTED_CSV)
        with tempfile.TemporaryDirectory() as td, patch.object(m.platform, 'python_version', return_value='3.13.0'), patch.object(m.subprocess, 'run') as child:
            with self.assertRaisesRegex(ValueError, 'runtime/schema'):
                m.replay(PACKET, RAW, Path(td)/'out')
            child.assert_not_called()

    def test_all_packet_and_runtime_tampering_before_child(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/'packet'; shutil.copytree(PACKET,p)
            for name in m.FILES:
                with self.subTest(name=name):
                    original=(p/name).read_bytes();(p/name).write_bytes(original+b' ')
                    with patch.object(m.subprocess,'run',side_effect=AssertionError('child reached')) as child:
                        with self.assertRaisesRegex(ValueError,'identity mismatch'):
                            m.replay(p,RAW,Path(td)/'out')
                        child.assert_not_called()
                    (p/name).write_bytes(original)
            original=(p/'source-replay-freeze.json').read_bytes(); f=json.loads(original)
            f['runtime']['version']='wrong';(p/'source-replay-freeze.json').write_text(json.dumps(f))
            with patch.object(m.subprocess,'run') as child:
                with self.assertRaisesRegex(ValueError,'runtime/schema'):m.replay(p,RAW,Path(td)/'out')
                child.assert_not_called()
            (p/'source-replay-freeze.json').write_bytes(original)
            f=json.loads((p/'version-exceptions.json').read_bytes());f['selected_rows'][0]['tier']='A'
            (p/'version-exceptions.json').write_text(json.dumps(f))
            with patch.object(m.subprocess,'run') as child:
                with self.assertRaisesRegex(ValueError,'identity mismatch'):m.replay(p,RAW,Path(td)/'out')
                child.assert_not_called()

    def test_raw_tamper_and_replacement_after_capture(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td);p=td/'packet';raw=td/'raw'
            shutil.copytree(PACKET,p);shutil.copytree(RAW/'monthly',raw/'monthly')
            first=next((raw/'monthly').glob('*.html'));body=first.read_bytes();first.write_bytes(body+b' ')
            with patch.object(m.subprocess,'run') as child:
                with self.assertRaisesRegex(ValueError,'raw identity'):m.replay(p,raw,td/'out')
                child.assert_not_called()
            first.write_bytes(body)
            capture=m.capture
            def replace_after_owned(*args):
                owned=capture(*args)
                for path in p.rglob('*'):
                    if path.is_file():path.write_bytes(b'replaced')
                for path in (raw/'monthly').iterdir():path.write_bytes(b'replaced')
                return owned
            with patch.object(m,'capture',replace_after_owned):
                result=m.replay(p,raw,td/'out')
            self.assertTrue(result['exact_csv_match'])
            self.assertEqual((td/'out/published-monthly.csv').read_bytes(),(PACKET/'published-monthly.csv').read_bytes())
            with self.assertRaisesRegex(ValueError,'output must be new'):m.replay(p,raw,td/'out')


if __name__=='__main__':unittest.main(argv=[sys.argv[0],*rest])
