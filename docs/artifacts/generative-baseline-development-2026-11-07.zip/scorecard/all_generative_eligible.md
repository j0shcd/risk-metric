# Generative forecast scorecard: all_generative_eligible

Fixed target/horizon/role/replica cells. No combined winner. Incomplete-support means are withheld.
Extra eligible origins are not evidence of superiority. Two replicas are Monte Carlo diagnostics.
Primary generative CRPS/Brier are iid-draw unbiased estimates; reference CDF scores are exact and uncorrected.
Empirical scores and corrections remain in JSON; corrected scores are not clipped.
Generative outside_atom_range describes only the finite Monte Carlo sample range, not the predictive law support.

| Role | Months | Target | Model | Replica | Requested / scored / failed | CRPS | Brier | 50% cover / width | 80% cover / width |
|---|---:|---|---|---:|---:|---:|---:|---|---|
| development | 12 | terminal_log_return | generative | 0 | 96 / 96 / 0 | 0.775976 | 0.294100 | 0.218750 / 0.835741 | 0.416667 / 1.639270 |
| development | 12 | entry_adverse_log_loss | generative | 0 | 96 / 96 / 0 | 0.309370 | 0.256037 | 0.260417 / 0.364325 | 0.552083 / 0.722357 |
| development | 12 | peak_drawdown_log_loss | generative | 0 | 96 / 96 / 0 | 0.361933 | 0.466549 | 0.197917 / 0.361775 | 0.520833 / 0.739418 |
| development | 24 | terminal_log_return | generative | 0 | 84 / 84 / 0 | 1.063711 | 0.200008 | 0.238095 / 1.245447 | 0.416667 / 2.414509 |
| development | 24 | entry_adverse_log_loss | generative | 0 | 84 / 84 / 0 | 0.326031 | 0.271494 | 0.297619 / 0.459918 | 0.547619 / 0.913395 |
| development | 24 | peak_drawdown_log_loss | generative | 0 | 84 / 84 / 0 | 0.529971 | 0.510472 | 0.190476 / 0.463858 | 0.357143 / 0.946079 |
| development | 48 | terminal_log_return | generative | 0 | 60 / 60 / 0 | 1.257597 | 0.061325 | 0.200000 / 2.024135 | 0.450000 / 3.889584 |
| development | 48 | entry_adverse_log_loss | generative | 0 | 60 / 60 / 0 | 0.431117 | 0.357164 | 0.183333 / 0.577471 | 0.450000 / 1.143000 |
| development | 48 | peak_drawdown_log_loss | generative | 0 | 60 / 60 / 0 | 0.689015 | 0.378251 | 0.166667 / 0.594171 | 0.283333 / 1.213048 |
| development | 12 | terminal_log_return | generative | 1 | 96 / 96 / 0 | 0.775717 | 0.294686 | 0.208333 / 0.834416 | 0.427083 / 1.637864 |
| development | 12 | entry_adverse_log_loss | generative | 1 | 96 / 96 / 0 | 0.309961 | 0.255915 | 0.250000 / 0.364054 | 0.552083 / 0.723136 |
| development | 12 | peak_drawdown_log_loss | generative | 1 | 96 / 96 / 0 | 0.362406 | 0.467077 | 0.197917 / 0.361481 | 0.510417 / 0.740357 |
| development | 24 | terminal_log_return | generative | 1 | 84 / 84 / 0 | 1.063954 | 0.200434 | 0.261905 / 1.245346 | 0.416667 / 2.411458 |
| development | 24 | entry_adverse_log_loss | generative | 1 | 84 / 84 / 0 | 0.326979 | 0.272089 | 0.285714 / 0.460298 | 0.547619 / 0.915162 |
| development | 24 | peak_drawdown_log_loss | generative | 1 | 84 / 84 / 0 | 0.530961 | 0.510454 | 0.178571 / 0.463063 | 0.369048 / 0.947659 |
| development | 48 | terminal_log_return | generative | 1 | 60 / 60 / 0 | 1.255308 | 0.060938 | 0.216667 / 2.025256 | 0.466667 / 3.894571 |
| development | 48 | entry_adverse_log_loss | generative | 1 | 60 / 60 / 0 | 0.432191 | 0.357634 | 0.183333 / 0.576416 | 0.433333 / 1.143670 |
| development | 48 | peak_drawdown_log_loss | generative | 1 | 60 / 60 / 0 | 0.691117 | 0.379350 | 0.166667 / 0.594452 | 0.283333 / 1.212976 |
| pending | 48 | terminal_log_return | generative | 0 | 49 / 0 / 0 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 0 | 49 / 0 / 0 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 0 | 49 / 0 / 0 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 1 | 49 / 0 / 0 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 1 | 49 / 0 / 0 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 1 | 49 / 0 / 0 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 0 | 25 / 0 / 0 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 0 | 25 / 0 / 0 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 0 | 25 / 0 / 0 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 1 | 25 / 0 / 0 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 1 | 25 / 0 / 0 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 1 | 25 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 0 | 13 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 0 | 13 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 0 | 13 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 1 | 13 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 1 | 13 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 1 | 13 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
