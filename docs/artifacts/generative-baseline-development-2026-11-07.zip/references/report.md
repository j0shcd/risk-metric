# Frozen indicator replay

Chronological pseudo-out-of-sample reconstruction, not an unseen holdout or prospective forecast.
No selection, combined objective, market significance or production promotion. Lower CRPS is better.
Best reference is a descriptive per-cell comparison, not a selected forecasting model.

## constant_reference_packet_anchor

| Role | Months | Outcome | Forecast / scored n | Candidate | Context | Unconditional | Best fixed reference | Ordering |
|---|---:|---|---:|---:|---:|---:|---|---:|
| development | 12 | terminal_log_return | 48 / 48 | 0.854808 | 0.854808 | 0.858520 | calendar_cycle_cos_4y (0.810894) | — |
| development | 12 | entry_adverse_log_loss | 48 / 48 | 0.353230 | 0.353230 | 0.361899 | calendar_cycle_sin_4y (0.351166) | — |
| development | 12 | peak_drawdown_log_loss | 48 / 48 | 0.263792 | 0.263792 | 0.282293 | calendar_cycle_sin_4y (0.260172) | — |
| development | 24 | terminal_log_return | 24 / 24 | 0.453800 | 0.453800 | 0.331074 | time_years_since_2012 (0.411880) | — |
| development | 24 | entry_adverse_log_loss | 24 / 24 | 0.238338 | 0.238338 | 0.249353 | price_drawdown_12m (0.227048) | — |
| development | 24 | peak_drawdown_log_loss | 24 / 24 | 0.297130 | 0.297130 | 0.300568 | price_ath_drawdown (0.274003) | — |
| development | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| development | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| development | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 12 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outer | 12 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 12 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 24 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outer | 24 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 24 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outer | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 12 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 12 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 24 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 24 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| pending | 12 | terminal_log_return | 13 / 0 | — | — | — | — | — |
| pending | 12 | entry_adverse_log_loss | 13 / 0 | — | — | — | — | — |
| pending | 12 | peak_drawdown_log_loss | 13 / 0 | — | — | — | — | — |
| pending | 24 | terminal_log_return | 25 / 0 | — | — | — | — | — |
| pending | 24 | entry_adverse_log_loss | 25 / 0 | — | — | — | — | — |
| pending | 24 | peak_drawdown_log_loss | 25 / 0 | — | — | — | — | — |
| pending | 48 | terminal_log_return | 25 / 0 | — | — | — | — | — |
| pending | 48 | entry_adverse_log_loss | 25 / 0 | — | — | — | — | — |
| pending | 48 | peak_drawdown_log_loss | 25 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |

- Historical source vintages, UTC close convention and execution availability remain unverified.
- Outer is chronological pseudo-out-of-sample replay of already exposed history, not an unseen historical holdout.
- Pending distributions are reconstructed now, not predictions archived at their origin dates.
- Overlapping monthly outcomes are not independent evidence; no significance, financial utility or automatic promotion is established.
- Forecast skill is specific to the registered finite-bin readout; fixed-direction ordering is a separate diagnostic.

