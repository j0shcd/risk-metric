#!/usr/bin/env python3
"""Portable independent retained-record arithmetic audit. Requires numpy only.

--packet points to the frozen source tree (research/, tests/, docs/).
Path-bank samples are not retained: audit their averaging, not simulation scores.
Strict >0 sign counts are excluded because epsilon-level score differences can flip them.
No original scoring or aggregation module is imported.
"""
import argparse
import gzip
import hashlib
import json
import math
from pathlib import Path
import numpy as np

REG_SHA = '423265ed2494247b1ce5ae8e1f357bc48cf1880c27bf3a9903ecee692372501f'
FREEZE_SHA = '179d25075d96b39043311f4ced88940844329226f696ae1f5476a915e0aa2f04'
SUMMARY_SHA = '955a9db4f6ef7c68098b16783252c8ec21fb8585886f8c3664bb4226e7046d1d'
METRICS = ('crps', 'brier', 'coverage80', 'width80')
ARMS = ('constant', 'nuisance', 'noisy', 'exact')
TERMINAL = 'terminal_log_return'
checks, max_error = 0, 0.0


def digest(b):
    return hashlib.sha256(b).hexdigest()


def compare(actual, expected):
    global checks, max_error
    a, b = np.asarray(actual, dtype=float), np.asarray(expected, dtype=float)
    assert a.shape == b.shape, (a.shape, b.shape)
    assert np.isfinite(a).all() and np.isfinite(b).all()
    error = float(np.max(np.abs(a-b))) if a.size else 0.0
    checks += a.size
    max_error = max(max_error, error)
    assert np.allclose(a, b, atol=1e-12, rtol=0), (a, b, error)


def empirical(x, w, y, terminal):
    x, w = np.asarray(x), np.asarray(w)
    compare(w.sum(), 1)
    assert np.all(w >= 0)
    crps = np.sum(w * np.abs(x-y)) - .5 * np.sum(np.outer(w, w)*np.abs(x[:, None]-x[None, :]))
    order = np.argsort(x)
    cumulative = np.cumsum(w[order])
    lo, hi = [x[order[min(np.searchsorted(cumulative, q), len(x)-1)]] for q in (.1, .9)]
    event = x < 0 if terminal else x > math.log(2)
    observed = y < 0 if terminal else y > math.log(2)
    return dict(zip(METRICS, (crps, (np.sum(w[event])-observed)**2, float(lo <= y <= hi), hi-lo)))


def gaussian(mu, variance, y):
    sigma = math.sqrt(variance)
    z = (y-mu)/sigma
    cdf = .5 * math.erfc(-z/math.sqrt(2))
    crps = sigma*(z*(2*cdf-1)+math.sqrt(2/math.pi)*math.exp(-z*z/2)-1/math.sqrt(math.pi))
    p = .5*math.erfc(mu/(sigma*math.sqrt(2)))
    d = 1.2815515655446004*sigma
    return dict(zip(METRICS, (crps, (p-(y<0))**2, float(mu-d <= y <= mu+d), 2*d)))


def audit_statistics(values, reported, indices):
    values = np.asarray(values)
    compare(values.mean(), reported['mean'])
    compare(np.median(values), reported['world_median'])
    compare(np.quantile(values, [.1, .9]), reported['world_q10_q90'])
    compare(np.quantile(np.mean(values[indices], axis=1), [.025, .975]), reported['pointwise_95_percentile_world_bootstrap'])
    assert len(values) == reported['world_n']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet', type=Path, required=True)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    registration_bytes = (args.packet/'docs/artifacts/direct-cdf-sensitivity-2026-11-09-registration.json').read_bytes()
    assert digest(registration_bytes) == REG_SHA
    spec = json.loads(registration_bytes)
    for name, expected in spec['frozen_code_sha256'].items():
        assert digest((args.packet/'research'/name).read_bytes()) == expected, name
    freeze_bytes = (args.results/'implementation-freeze.json').read_bytes()
    assert digest(freeze_bytes) == FREEZE_SHA
    for name, expected in json.loads(freeze_bytes)['code_sha256'].items():
        assert digest((args.packet/name).read_bytes()) == expected, name
    manifest = json.loads((args.results/'manifest.json').read_bytes())
    summary_bytes = (args.results/'summary.json').read_bytes()
    assert digest(summary_bytes) == SUMMARY_SHA == manifest['summary_sha256']
    assert manifest['status'] == 'complete' and not manifest['failures']
    assert manifest['registration_sha256'] == REG_SHA
    assert manifest['implementation_freeze_sha256'] == FREEZE_SHA
    assert len(manifest['completed']) == 128
    summary = json.loads(summary_bytes)
    worlds, record_count = [], 0
    names = [entry['file'] for entry in manifest['completed']]
    assert len(set(names)) == 128
    assert set(names) == {p.name for p in args.results.glob('world-*.json.gz')}
    for entry in manifest['completed']:
        payload = gzip.decompress((args.results/entry['file']).read_bytes())
        assert digest(payload) == entry['sha256'], entry['file']
        world = json.loads(payload)
        worlds.append(world)
        assert world['root_seed'] == spec['randomness']['root_seed']
        assert world['oracle_paths_per_bank'] == 128 and world['oracle_banks'] == 2
        assert len(world['records']) == 216
        targets = {r['target'] for r in world['records']}
        assert len(targets) == 3 and TERMINAL in targets
        for target in targets:
            for horizon, count in ((12, 48), (24, 24), (48, 0)):
                assert sum(r['target'] == target and r['horizon'] == horizon for r in world['records']) == count
        for row in world['records']:
            record_count += 1
            x, y = row['atoms'], row['outcome']
            assert len(x) == len(row['train_dates']) == 24
            assert max(row['train_dates']) < row['date']
            weights = {'pooled': np.ones(len(x))/len(x), 'reference': row['reference_weights']}
            weights.update({arm: row['arms'][arm]['weights'] for arm in ARMS})
            calculated = {}
            for model, w in weights.items():
                calculated[model] = empirical(x, w, y, row['target'] == TERMINAL)
            assert row['arms']['constant']['weights'] == row['reference_weights']
            for arm in ARMS:
                w = np.array(weights[arm])
                compare(1/np.sum(w*w), row['arms'][arm]['effective_atoms'])
            assert row['outside_atom_range'] == (y < min(x) or y > max(x))
            for info, moments in row['terminal_oracle_moments'].items():
                model = 'oracle_'+info
                if row['target'] == TERMINAL:
                    calculated[model] = gaussian(moments['mean'], moments['variance'], y)
                else:
                    banks = row['oracle_banks'][model]
                    assert len(banks) == 2
                    calculated[model] = {m: (banks[0][m]+banks[1][m])/2 for m in METRICS}
            for model, scores in calculated.items():
                for metric, value in scores.items():
                    compare(value, row['metrics'][model][metric])
            row['recalculated'] = calculated
    assert record_count == 27648
    assert {(w['world_id'], w['beta']) for w in worlds} == {(i,b) for i in spec['budget']['world_ids'] for b in spec['law']['monthly_loadings']}
    assert summary['world_count'] == 128 and len(summary['cells']) == 18
    assert {(c['beta'], c['horizon'], c['target']) for c in summary['cells']} == {(b, h, t) for b in spec['law']['monthly_loadings'] for h in (12,24,48) for t in targets}
    available, unavailable = 0, 0
    for cell in summary['cells']:
        group = sorted((w for w in worlds if w['beta'] == cell['beta']), key=lambda w: w['world_id'])
        records = [[r for r in w['records'] if r['horizon'] == cell['horizon'] and r['target'] == cell['target']] for w in group]
        assert [len(rows) for rows in records] == cell['scored_origins_per_world']
        assert cell['world_n'] == 64
        if cell['horizon'] == 48:
            assert cell['status'] == 'unavailable_by_registered_calendar'
            unavailable += 1
            continue
        available += 1
        indices = np.random.default_rng(np.random.SeedSequence([spec['randomness']['root_seed'],0,6,0,0])).integers(0,64,(4000,64))
        means = {model: {m: np.array([sum(r['recalculated'][model][m] for r in rows)/len(rows) for rows in records]) for m in METRICS} for model in cell['models']}
        for model, metrics in cell['models'].items():
            for m, reported in metrics.items():
                audit_statistics(means[model][m], reported, indices)
        for arm in ARMS:
            oracle = 'oracle_'+(arm if arm in ('noisy','exact') else 'price')
            pairs = {'reference_minus_candidate': ('reference',arm), 'pooled_minus_candidate': ('pooled',arm), 'price_oracle_minus_signal_oracle': ('oracle_price',oracle), 'candidate_minus_signal_oracle': (arm,oracle)}
            for contrast, (a,b) in pairs.items():
                for m in METRICS:
                    audit_statistics(means[a][m]-means[b][m], cell['contrasts'][arm][contrast][m], indices)
            flat = [r['arms'][arm] for rows in records for r in rows]
            diag = cell['diagnostics'][arm]
            compare(np.mean([r['fallback'] for r in flat]), diag['fallback_fraction'])
            compare(np.quantile([r['cell_n'] for r in flat],[0,.5,1]), diag['cell_n_q0_q50_q100'])
            compare(np.quantile([r['effective_atoms'] for r in flat],[.1,.5,.9]), diag['effective_atom_n_q10_q50_q90'])
        compare(np.mean([r['outside_atom_range'] for rows in records for r in rows]), cell['diagnostics']['outside_atom_range_fraction'])
        for model, metrics in cell['oracle_bank_mean_absolute_discrepancy'].items():
            for m, value in metrics.items():
                compare(np.mean([abs(r['oracle_banks'][model][0][m]-r['oracle_banks'][model][1][m]) for rows in records for r in rows]), value)
    assert (available, unavailable) == (12,6)
    report = {'status':'pass', 'registration_sha256':REG_SHA, 'freeze_sha256':FREEZE_SHA, 'summary_sha256':SUMMARY_SHA, 'world_files_verified':len(worlds), 'records_verified':record_count, 'numeric_comparisons':int(checks), 'maximum_absolute_error':max_error, 'absolute_tolerance':1e-12, 'available_cells':available, 'unavailable_cells':unavailable, 'bootstrap_resamples':4000, 'limitations':['Path-bank samples are not retained; only bank metric averaging and discrepancy independently checked.', 'Strict positive sign counts excluded because machine-epsilon score perturbations can flip signs.', 'Retained oracle moments are inputs to this arithmetic audit; law derivation covered separately by engineering tests.']}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
