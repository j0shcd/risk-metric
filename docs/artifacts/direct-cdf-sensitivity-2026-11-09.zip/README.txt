Fixed readout sensitivity audit, November9 2026
Authenticate ZIP against its externally recorded SHA before executing trusted
Python. This is not a sandbox. Only artificial prices are included.
64 independent history IDs, paired across two laws and four features:128 jobs,
512 unchanged decoder calls. Original97dates,48/24/0 scored origins per horizon.
No benchmark change, model promotion, market power or error-control certificate.
Current-scalar oracle excludes historical scalar releases. Terminal oracle is
Gaussian; downside metrics score two finite128-path ensembles. Bank samples
must be regenerated; retained bank metrics alone cannot independently rescore
those paths. Floating-point signs at effectively zero are not stable win counts.

Use CPython3.12.16 with pinned requirements.txt (numpy2.4.6,pandas2.3.3).
From this directory, using new output/report paths:
 python audit-results.py --packet . --results results --report NEW_AUDIT.json
 python -m unittest tests.test_readout_sensitivity tests.test_readout_synthetic_world
 python -m research.readout_sensitivity run --freeze docs/artifacts/direct-cdf-sensitivity-2026-11-09-implementation.json --output NEW_RESULTS_DIR
Compare manifest decompressed-world SHA values and summary SHA. Elapsed seconds
vary. Same-host recovery reproduces the original recorded summary exactly.
Cross-platform bitwise identity remains unverified. No browser or network action
is performed by these commands; installing dependencies is a separate action.
Research code/registration were committed before original run. Temporary output
vanished between turns; unchanged source/seeds restored the recorded summary.
This is deterministic recovery, not another independent replication or tuning.
The10800second cooperative cap is checked between world/law jobs.
