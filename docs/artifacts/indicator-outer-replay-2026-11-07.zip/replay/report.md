# Frozen indicator replay

Chronological pseudo-out-of-sample reconstruction, not an unseen holdout or prospective forecast.
No selection, combined objective, market significance or production promotion. Lower CRPS is better.
Best reference is a descriptive per-cell comparison, not a selected forecasting model.

## swing_a_memory_0

| Role | Months | Outcome | Forecast / scored n | Candidate | Context | Unconditional | Best fixed reference | Ordering |
|---|---:|---|---:|---:|---:|---:|---|---:|
| development | 12 | terminal_log_return | 48 / 48 | 0.855343 | 0.854808 | 0.858520 | calendar_cycle_cos_4y (0.810894) | 0.518903 |
| development | 12 | entry_adverse_log_loss | 48 / 48 | 0.341412 | 0.353230 | 0.361899 | calendar_cycle_sin_4y (0.351166) | 0.538008 |
| development | 12 | peak_drawdown_log_loss | 48 / 48 | 0.255046 | 0.263792 | 0.282293 | calendar_cycle_sin_4y (0.260172) | 0.683683 |
| development | 24 | terminal_log_return | 24 / 24 | 0.456734 | 0.453800 | 0.331074 | time_years_since_2012 (0.411880) | 0.641553 |
| development | 24 | entry_adverse_log_loss | 24 / 24 | 0.236041 | 0.238338 | 0.249353 | price_drawdown_12m (0.227048) | 0.576695 |
| development | 24 | peak_drawdown_log_loss | 24 / 24 | 0.303706 | 0.297130 | 0.300568 | price_ath_drawdown (0.274003) | 0.624442 |
| development | 48 | terminal_log_return | 0 / 0 | — | — | — | — | 0.571971 |
| development | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | 0.630607 |
| development | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | -0.422684 |
| outer | 12 | terminal_log_return | 30 / 30 | 0.582567 | 0.553077 | 0.520563 | calendar_cycle_sin_4y (0.459558) | 0.781535 |
| outer | 12 | entry_adverse_log_loss | 30 / 30 | 0.271883 | 0.249202 | 0.228357 | calendar_cycle_sin_4y (0.179188) | 0.499889 |
| outer | 12 | peak_drawdown_log_loss | 30 / 30 | 0.382699 | 0.359484 | 0.325409 | calendar_cycle_sin_4y (0.313214) | 0.686539 |
| outer | 24 | terminal_log_return | 18 / 18 | 0.286751 | 0.276072 | 0.304205 | calendar_cycle_sin_4y (0.256821) | 0.940144 |
| outer | 24 | entry_adverse_log_loss | 18 / 18 | 0.142749 | 0.146430 | 0.257553 | price_drawdown_12m (0.097276) | 0.164087 |
| outer | 24 | peak_drawdown_log_loss | 18 / 18 | 0.610416 | 0.603242 | 0.587358 | calendar_cycle_cos_4y (0.498272) | 0.895131 |
| outer | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outer | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 12 | terminal_log_return | 13 / 13 | 0.771392 | 0.673945 | 0.664647 | calendar_cycle_cos_4y (0.585301) | 0.923077 |
| retrospective_challenge | 12 | entry_adverse_log_loss | 13 / 13 | 0.294913 | 0.265138 | 0.290599 | price_ath_drawdown (0.263824) | 0.972527 |
| retrospective_challenge | 12 | peak_drawdown_log_loss | 13 / 13 | 0.285849 | 0.278715 | 0.284268 | calendar_cycle_cos_4y (0.267220) | 0.953053 |
| retrospective_challenge | 24 | terminal_log_return | 25 / 25 | 0.697425 | 0.630540 | 0.618476 | price_trend_12m (0.630540) | 0.960769 |
| retrospective_challenge | 24 | entry_adverse_log_loss | 25 / 25 | 0.246293 | 0.225862 | 0.238236 | dca_bottom_reversal_component (0.203835) | 0.790000 |
| retrospective_challenge | 24 | peak_drawdown_log_loss | 25 / 25 | 0.292296 | 0.285742 | 0.264393 | price_trend_12m (0.285742) | 0.927340 |
| retrospective_challenge | 48 | terminal_log_return | 19 / 19 | 2.035742 | 2.034753 | 1.953330 | calendar_cycle_cos_4y (1.974509) | 0.631380 |
| retrospective_challenge | 48 | entry_adverse_log_loss | 19 / 19 | 0.755692 | 0.759408 | 0.737593 | calendar_cycle_sin_4y (0.751521) | 0.743129 |
| retrospective_challenge | 48 | peak_drawdown_log_loss | 19 / 19 | 0.504803 | 0.504803 | 0.486117 | dca_risk (0.504803) | 0.210557 |
| pending | 12 | terminal_log_return | 12 / 0 | — | — | — | — | — |
| pending | 12 | entry_adverse_log_loss | 12 / 0 | — | — | — | — | — |
| pending | 12 | peak_drawdown_log_loss | 12 / 0 | — | — | — | — | — |
| pending | 24 | terminal_log_return | 24 / 0 | — | — | — | — | — |
| pending | 24 | entry_adverse_log_loss | 24 / 0 | — | — | — | — | — |
| pending | 24 | peak_drawdown_log_loss | 24 / 0 | — | — | — | — | — |
| pending | 48 | terminal_log_return | 48 / 0 | — | — | — | — | — |
| pending | 48 | entry_adverse_log_loss | 48 / 0 | — | — | — | — | — |
| pending | 48 | peak_drawdown_log_loss | 48 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |

- Historical source vintages, UTC close convention and execution availability remain unverified.
- Outer is chronological pseudo-out-of-sample replay of already exposed history, not an unseen historical holdout.
- Pending distributions are reconstructed now, not predictions archived at their origin dates.
- Overlapping monthly outcomes are not independent evidence; no significance, financial utility or automatic promotion is established.
- Forecast skill is specific to the registered finite-bin readout; fixed-direction ordering is a separate diagnostic.

## swing_b_adaptive

| Role | Months | Outcome | Forecast / scored n | Candidate | Context | Unconditional | Best fixed reference | Ordering |
|---|---:|---|---:|---:|---:|---:|---|---:|
| development | 12 | terminal_log_return | 48 / 48 | 0.820350 | 0.854808 | 0.858520 | calendar_cycle_cos_4y (0.810894) | 0.511593 |
| development | 12 | entry_adverse_log_loss | 48 / 48 | 0.344483 | 0.353230 | 0.361899 | calendar_cycle_sin_4y (0.351166) | 0.475441 |
| development | 12 | peak_drawdown_log_loss | 48 / 48 | 0.257508 | 0.263792 | 0.282293 | calendar_cycle_sin_4y (0.260172) | 0.625862 |
| development | 24 | terminal_log_return | 24 / 24 | 0.450009 | 0.453800 | 0.331074 | time_years_since_2012 (0.411880) | 0.688437 |
| development | 24 | entry_adverse_log_loss | 24 / 24 | 0.237501 | 0.238338 | 0.249353 | price_drawdown_12m (0.227048) | 0.509501 |
| development | 24 | peak_drawdown_log_loss | 24 / 24 | 0.303077 | 0.297130 | 0.300568 | price_ath_drawdown (0.274003) | 0.579723 |
| development | 48 | terminal_log_return | 0 / 0 | — | — | — | — | 0.498372 |
| development | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | 0.610405 |
| development | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | -0.284812 |
| outer | 12 | terminal_log_return | 30 / 30 | 0.592570 | 0.553077 | 0.520563 | calendar_cycle_sin_4y (0.459558) | 0.772191 |
| outer | 12 | entry_adverse_log_loss | 30 / 30 | 0.273688 | 0.249202 | 0.228357 | calendar_cycle_sin_4y (0.179188) | 0.482536 |
| outer | 12 | peak_drawdown_log_loss | 30 / 30 | 0.379809 | 0.359484 | 0.325409 | calendar_cycle_sin_4y (0.313214) | 0.683161 |
| outer | 24 | terminal_log_return | 18 / 18 | 0.280957 | 0.276072 | 0.304205 | calendar_cycle_sin_4y (0.256821) | 0.917441 |
| outer | 24 | entry_adverse_log_loss | 18 / 18 | 0.123800 | 0.146430 | 0.257553 | price_drawdown_12m (0.097276) | 0.186791 |
| outer | 24 | peak_drawdown_log_loss | 18 / 18 | 0.627540 | 0.603242 | 0.587358 | calendar_cycle_cos_4y (0.498272) | 0.905851 |
| outer | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outer | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 12 | terminal_log_return | 13 / 13 | 0.707703 | 0.673945 | 0.664647 | calendar_cycle_cos_4y (0.585301) | 0.945055 |
| retrospective_challenge | 12 | entry_adverse_log_loss | 13 / 13 | 0.261904 | 0.265138 | 0.290599 | price_ath_drawdown (0.263824) | 0.994505 |
| retrospective_challenge | 12 | peak_drawdown_log_loss | 13 / 13 | 0.273296 | 0.278715 | 0.284268 | calendar_cycle_cos_4y (0.267220) | 0.928191 |
| retrospective_challenge | 24 | terminal_log_return | 25 / 25 | 0.654889 | 0.630540 | 0.618476 | price_trend_12m (0.630540) | 0.950769 |
| retrospective_challenge | 24 | entry_adverse_log_loss | 25 / 25 | 0.224532 | 0.225862 | 0.238236 | dca_bottom_reversal_component (0.203835) | 0.773846 |
| retrospective_challenge | 24 | peak_drawdown_log_loss | 25 / 25 | 0.289801 | 0.285742 | 0.264393 | price_trend_12m (0.285742) | 0.932579 |
| retrospective_challenge | 48 | terminal_log_return | 19 / 19 | 2.029969 | 2.034753 | 1.953330 | calendar_cycle_cos_4y (1.974509) | 0.634854 |
| retrospective_challenge | 48 | entry_adverse_log_loss | 19 / 19 | 0.747057 | 0.759408 | 0.737593 | calendar_cycle_sin_4y (0.751521) | 0.713380 |
| retrospective_challenge | 48 | peak_drawdown_log_loss | 19 / 19 | 0.504803 | 0.504803 | 0.486117 | dca_risk (0.504803) | 0.162728 |
| pending | 12 | terminal_log_return | 12 / 0 | — | — | — | — | — |
| pending | 12 | entry_adverse_log_loss | 12 / 0 | — | — | — | — | — |
| pending | 12 | peak_drawdown_log_loss | 12 / 0 | — | — | — | — | — |
| pending | 24 | terminal_log_return | 24 / 0 | — | — | — | — | — |
| pending | 24 | entry_adverse_log_loss | 24 / 0 | — | — | — | — | — |
| pending | 24 | peak_drawdown_log_loss | 24 / 0 | — | — | — | — | — |
| pending | 48 | terminal_log_return | 48 / 0 | — | — | — | — | — |
| pending | 48 | entry_adverse_log_loss | 48 / 0 | — | — | — | — | — |
| pending | 48 | peak_drawdown_log_loss | 48 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |

- Historical source vintages, UTC close convention and execution availability remain unverified.
- Outer is chronological pseudo-out-of-sample replay of already exposed history, not an unseen historical holdout.
- Pending distributions are reconstructed now, not predictions archived at their origin dates.
- Overlapping monthly outcomes are not independent evidence; no significance, financial utility or automatic promotion is established.
- Forecast skill is specific to the registered finite-bin readout; fixed-direction ordering is a separate diagnostic.

## upside_energy_24m

| Role | Months | Outcome | Forecast / scored n | Candidate | Context | Unconditional | Best fixed reference | Ordering |
|---|---:|---|---:|---:|---:|---:|---|---:|
| development | 12 | terminal_log_return | 48 / 48 | 0.858303 | 0.854808 | 0.858520 | calendar_cycle_cos_4y (0.810894) | 0.476582 |
| development | 12 | entry_adverse_log_loss | 48 / 48 | 0.343475 | 0.353230 | 0.361899 | calendar_cycle_sin_4y (0.351166) | 0.275567 |
| development | 12 | peak_drawdown_log_loss | 48 / 48 | 0.243514 | 0.263792 | 0.282293 | calendar_cycle_sin_4y (0.260172) | 0.420999 |
| development | 24 | terminal_log_return | 24 / 24 | 0.461353 | 0.453800 | 0.331074 | time_years_since_2012 (0.411880) | 0.575728 |
| development | 24 | entry_adverse_log_loss | 24 / 24 | 0.242418 | 0.238338 | 0.249353 | price_drawdown_12m (0.227048) | 0.361170 |
| development | 24 | peak_drawdown_log_loss | 24 / 24 | 0.300288 | 0.297130 | 0.300568 | price_ath_drawdown (0.274003) | 0.262633 |
| development | 48 | terminal_log_return | 0 / 0 | — | — | — | — | 0.232848 |
| development | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | 0.463560 |
| development | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | -0.131089 |
| outer | 12 | terminal_log_return | 30 / 30 | 0.571263 | 0.553077 | 0.520563 | calendar_cycle_sin_4y (0.459558) | 0.763293 |
| outer | 12 | entry_adverse_log_loss | 30 / 30 | 0.267658 | 0.249202 | 0.228357 | calendar_cycle_sin_4y (0.179188) | 0.464294 |
| outer | 12 | peak_drawdown_log_loss | 30 / 30 | 0.381421 | 0.359484 | 0.325409 | calendar_cycle_sin_4y (0.313214) | 0.801413 |
| outer | 24 | terminal_log_return | 18 / 18 | 0.280120 | 0.276072 | 0.304205 | calendar_cycle_sin_4y (0.256821) | 0.564499 |
| outer | 24 | entry_adverse_log_loss | 18 / 18 | 0.141367 | 0.146430 | 0.257553 | price_drawdown_12m (0.097276) | 0.424149 |
| outer | 24 | peak_drawdown_log_loss | 18 / 18 | 0.612675 | 0.603242 | 0.587358 | calendar_cycle_cos_4y (0.498272) | 0.778281 |
| outer | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outer | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outer | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| retrospective_challenge | 12 | terminal_log_return | 13 / 13 | 0.671664 | 0.673945 | 0.664647 | calendar_cycle_cos_4y (0.585301) | 0.901099 |
| retrospective_challenge | 12 | entry_adverse_log_loss | 13 / 13 | 0.268823 | 0.265138 | 0.290599 | price_ath_drawdown (0.263824) | 0.901099 |
| retrospective_challenge | 12 | peak_drawdown_log_loss | 13 / 13 | 0.256260 | 0.278715 | 0.284268 | calendar_cycle_cos_4y (0.267220) | 0.925428 |
| retrospective_challenge | 24 | terminal_log_return | 25 / 25 | 0.648749 | 0.630540 | 0.618476 | price_trend_12m (0.630540) | 0.865385 |
| retrospective_challenge | 24 | entry_adverse_log_loss | 25 / 25 | 0.251113 | 0.225862 | 0.238236 | dca_bottom_reversal_component (0.203835) | 0.795385 |
| retrospective_challenge | 24 | peak_drawdown_log_loss | 25 / 25 | 0.287678 | 0.285742 | 0.264393 | price_trend_12m (0.285742) | 0.758476 |
| retrospective_challenge | 48 | terminal_log_return | 19 / 19 | 2.105631 | 2.034753 | 1.953330 | calendar_cycle_cos_4y (1.974509) | 0.700544 |
| retrospective_challenge | 48 | entry_adverse_log_loss | 19 / 19 | 0.759202 | 0.759408 | 0.737593 | calendar_cycle_sin_4y (0.751521) | 0.631984 |
| retrospective_challenge | 48 | peak_drawdown_log_loss | 19 / 19 | 0.504803 | 0.504803 | 0.486117 | dca_risk (0.504803) | -0.188422 |
| pending | 12 | terminal_log_return | 12 / 0 | — | — | — | — | — |
| pending | 12 | entry_adverse_log_loss | 12 / 0 | — | — | — | — | — |
| pending | 12 | peak_drawdown_log_loss | 12 / 0 | — | — | — | — | — |
| pending | 24 | terminal_log_return | 24 / 0 | — | — | — | — | — |
| pending | 24 | entry_adverse_log_loss | 24 / 0 | — | — | — | — | — |
| pending | 24 | peak_drawdown_log_loss | 24 / 0 | — | — | — | — | — |
| pending | 48 | terminal_log_return | 48 / 0 | — | — | — | — | — |
| pending | 48 | entry_adverse_log_loss | 48 / 0 | — | — | — | — | — |
| pending | 48 | peak_drawdown_log_loss | 48 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | terminal_log_return | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | entry_adverse_log_loss | 0 / 0 | — | — | — | — | — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | 0 / 0 | — | — | — | — | — |

- Historical source vintages, UTC close convention and execution availability remain unverified.
- Outer is chronological pseudo-out-of-sample replay of already exposed history, not an unseen historical holdout.
- Pending distributions are reconstructed now, not predictions archived at their origin dates.
- Overlapping monthly outcomes are not independent evidence; no significance, financial utility or automatic promotion is established.
- Forecast skill is specific to the registered finite-bin readout; fixed-direction ordering is a separate diagnostic.

