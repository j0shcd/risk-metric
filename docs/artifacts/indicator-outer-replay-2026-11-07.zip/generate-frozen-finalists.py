from pathlib import Path
import hashlib,json,tempfile
import pandas as pd,numpy as np
from research.market_dataset import load_snapshot
from research.candidates.swing_a.indicator import generate_indicator
from research.candidates.swing_b.generator import generate
from research.candidates.swing_c.generate import generate as generate_c
root=Path.cwd(); full=Path('output/risk_scores_full.csv');snapshot=load_snapshot(full)
raw_path=Path('data/btc_daily.csv'); raw=pd.read_csv(raw_path,parse_dates=['Date']);raw=raw[raw.Date<=snapshot['daily'][-1]['date']]
expected=pd.DataFrame(snapshot['daily']).set_index('date').price; actual=raw.set_index(raw.Date.dt.strftime('%Y-%m-%d')).Price
np.testing.assert_array_equal(actual.loc[expected.index],expected)
dates=pd.DatetimeIndex([r['date'] for r in snapshot['monthly']]); target=Path(tempfile.mkdtemp(prefix='risk-frozen-finalists-')); print(target,flush=True)
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def candidates(frame,query):
 return {'swing_a_memory_0':generate_indicator(frame,query,memory_weight=0.0),'swing_b_adaptive':generate(frame)['swing_b_adaptive'].reindex(query),'upside_energy_24m':generate_c(frame.set_index('Date').Price).reindex(query)}
scores=candidates(raw,dates); devdates=dates[dates<=pd.Timestamp('2022-12-31')];dev=candidates(raw[raw.Date<=pd.Timestamp('2022-12-31')],devdates)
for k in scores:np.testing.assert_array_equal(scores[k].loc[devdates],dev[k])
# Fixed final selection manifests have already been committed before any outer replay.
entries=[]
for name,manifest,gen in [('swing_a_memory_0','swing_a/finalist.json','swing_a/indicator.py'),('swing_b_adaptive','swing_b/candidate_manifest.json','swing_b/generator.py'),('upside_energy_24m','swing_c/manifest.json','swing_c/generate.py')]:
 csv=target/(name+'.csv');scores[name].rename(name).rename_axis('Date').to_csv(csv,float_format='%.17g')
 m=(root/'research/candidates'/manifest).resolve();g=(root/'research/candidates'/gen).resolve()
 entries.append({'name':name,'column':name,'csv':str(csv),'csv_sha256':h(csv),'manifest':str(m),'manifest_sha256':h(m),'provenance':f'frozen pre-outer candidate; generator={g}; sha256={h(g)}; raw_price_source_sha256={h(raw_path)}; trimmed to snapshot asof; daily prices identical to snapshot; development-prefix parity checked','direction':'higher_risk','frozen':True})
request={'source_sha256':h(full),'candidates':entries}
(target/'registration-draft.json').write_text(json.dumps(request,indent=2)+'\n')
(target/'producer.json').write_text(json.dumps({'source':str(full.resolve()),'source_sha256':h(full),'raw_source':str(raw_path.resolve()),'raw_source_sha256':h(raw_path),'as_of':snapshot['daily'][-1]['date'],'common_months':len(dates),'development_prefix_parity':'exact allthree','candidate_csv_sha256':{k:h(target/(k+'.csv')) for k in scores}},indent=2)+'\n')
