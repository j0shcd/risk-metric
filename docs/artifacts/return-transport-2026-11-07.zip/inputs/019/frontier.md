# Benchmark frontier comparison

Completed measurement; no automatic promotion. Positive loss delta favors candidate; coverage/width are separate tradeoffs.

| Role | Months | Target | Reference | Replica | Scored / failed / unavailable | CRPS delta | Brier delta | 50% coverage delta / width delta | 80% coverage delta / width delta |
|---|---:|---|---|---:|---|---:|---:|---|---|
| development | 12 | terminal_log_return | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.035402 | -0.000732 | 0.020833 / -0.005609 | 0.041667 / 0.020312 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.019307 | 0.023150 | -0.020833 / -0.008303 | -0.062500 / 0.001737 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | -0.023110 | -0.024569 | 0.041667 / 0.023056 | 0.041667 / 0.018201 |
| development | 24 | terminal_log_return | direct_cdf:dca_risk | None | 24 / 0 / 0 | -0.047330 | 0.000000 | 0.041667 / -0.024795 | 0.000000 / -0.063015 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | 0.003176 | 0.008803 | -0.125000 / 0.023169 | 0.000000 / 0.000000 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | 0.011883 | -0.001433 | 0.000000 / 0.013897 | -0.041667 / -0.012643 |
| development | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.058841 | 0.003423 | 0.000000 / -0.000947 | 0.041667 / 0.043059 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.026816 | 0.022772 | -0.041667 / -0.026891 | -0.062500 / 0.003225 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | -0.022392 | -0.040519 | -0.020833 / 0.010621 | 0.041667 / 0.038494 |
| development | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.044833 | 0.000000 | 0.041667 / -0.081279 | 0.000000 / -0.113641 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.004800 | 0.002798 | -0.083333 / 0.025079 | 0.000000 / -0.018671 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | 0.022541 | -0.006207 | -0.083333 / -0.061014 | -0.041667 / -0.012643 |
| development | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.039931 | 0.036141 | 0.041667 / 0.021673 | 0.041667 / 0.002726 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.033785 | 0.073594 | -0.041667 / -0.018685 | -0.083333 / -0.002702 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | -0.025516 | -0.042256 | 0.020833 / 0.058933 | 0.062500 / 0.049394 |
| development | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | -0.031293 | 0.000000 | 0.041667 / 0.039680 | 0.000000 / 0.044739 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | 0.002200 | 0.004254 | -0.041667 / 0.019995 | 0.000000 / 0.000000 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | 0.004988 | -0.000081 | 0.125000 / 0.071466 | 0.000000 / 0.013100 |
| development | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | 0.017896 | -0.003626 | 0.020833 / -0.058979 | 0.041667 / -0.073696 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | 0.024574 | 0.016766 | -0.062500 / -0.055560 | -0.062500 / 0.002076 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | -0.020337 | -0.014777 | 0.020833 / -0.009376 | 0.000000 / -0.034402 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | 0.000888 | 0.000000 | 0.083333 / 0.027881 | 0.000000 / -0.003551 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.001345 | 0.001139 | -0.041667 / 0.008684 | 0.000000 / 0.000000 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.001353 | 0.011470 | 0.041667 / 0.029974 | 0.000000 / 0.013100 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.077746 | 0.003423 | 0.000000 / 0.000691 | 0.020833 / 0.019456 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.028306 | 0.025195 | -0.062500 / -0.036425 | -0.062500 / 0.000083 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | -0.025055 | -0.043961 | -0.020833 / 0.016567 | 0.062500 / 0.044023 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.051438 | 0.000000 | 0.041667 / -0.160502 | 0.000000 / -0.099683 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.000681 | 0.005154 | -0.083333 / 0.020742 | 0.000000 / -0.003549 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | 0.027866 | -0.014454 | -0.166667 / -0.134636 | -0.083333 / -0.049717 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | 0.009869 | 0.012301 | 0.020833 / 0.151957 | 0.062500 / 0.090402 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | 0.015224 | 0.011335 | 0.000000 / 0.030671 | -0.041667 / 0.012221 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | -0.032417 | -0.044620 | 0.104167 / 0.039064 | 0.062500 / 0.060858 |
| development | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.027278 | 0.000000 | 0.041667 / 0.034571 | 0.000000 / 0.044739 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.000021 | 0.002776 | 0.000000 / 0.030473 | 0.000000 / 0.000000 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | 0.005741 | -0.000081 | 0.125000 / 0.066470 | 0.000000 / 0.008103 |
| development | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | 0.009869 | 0.012301 | 0.020833 / 0.151957 | 0.062500 / 0.090402 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | 0.015224 | 0.011335 | 0.000000 / 0.030671 | -0.041667 / 0.012221 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | -0.032417 | -0.044620 | 0.104167 / 0.039064 | 0.062500 / 0.060858 |
| development | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.027278 | 0.000000 | 0.041667 / 0.034571 | 0.000000 / 0.044739 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.000021 | 0.002776 | 0.000000 / 0.030473 | 0.000000 / 0.000000 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | 0.005741 | -0.000081 | 0.125000 / 0.066470 | 0.000000 / 0.008103 |
| development | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.027173 | -0.006548 | 0.041667 / 0.108809 | 0.041667 / -0.056377 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.028402 | 0.009412 | -0.041667 / -0.003694 | -0.062500 / -0.010002 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | -0.018140 | -0.039960 | 0.000000 / 0.006953 | 0.041667 / 0.015998 |
| development | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | -0.011880 | 0.000000 | -0.083333 / -0.106764 | 0.000000 / -0.080543 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | -0.011311 | -0.007867 | -0.041667 / -0.028136 | 0.000000 / -0.000070 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | 0.018930 | -0.020964 | 0.041667 / -0.085404 | -0.041667 / -0.056145 |
| development | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | 0.004954 | -0.001480 | 0.000000 / -0.160253 | 0.020833 / -0.060305 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | 0.026703 | 0.026850 | -0.062500 / -0.052057 | -0.062500 / 0.002662 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | -0.022916 | -0.038546 | -0.020833 / -0.005660 | 0.020833 / 0.048753 |
| development | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | 0.002215 | 0.000000 | 0.083333 / 0.031691 | 0.000000 / 0.048511 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | 0.002334 | 0.005154 | 0.000000 / 0.027688 | 0.000000 / 0.000000 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | -0.017386 | -0.003227 | 0.041667 / -0.051763 | 0.000000 / 0.013100 |
| development | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.077003 | 0.001340 | 0.020833 / 0.063833 | 0.020833 / -0.075183 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.037306 | 0.041003 | -0.041667 / -0.015369 | -0.083333 / -0.007288 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | -0.002978 | 0.001447 | -0.020833 / 0.002171 | -0.020833 / 0.002396 |
| development | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | 0.023070 | 0.000000 | -0.041667 / 0.003820 | 0.000000 / -0.024903 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | -0.001935 | -0.002224 | -0.041667 / 0.012874 | 0.000000 / -0.000070 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | 0.015454 | 0.031553 | 0.000000 / -0.039628 | -0.041667 / -0.038618 |
| development | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.076472 | 0.018738 | -0.020833 / -0.015751 | -0.020833 / -0.068363 |
| development | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.020554 | 0.048376 | -0.020833 / -0.016689 | -0.083333 / -0.026954 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | -0.026979 | -0.029161 | 0.083333 / 0.069976 | 0.062500 / 0.028746 |
| development | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | -0.069199 | 0.000000 | -0.041667 / -0.312029 | 0.000000 / -0.126060 |
| development | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | 0.040052 | 0.031560 | -0.125000 / -0.022537 | -0.083333 / -0.004707 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | 0.042173 | -0.005669 | 0.083333 / -0.017373 | -0.041667 / -0.013888 |
| development | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | 0.051558 | 0.022888 | 0.041667 / 0.134102 | 0.062500 / 0.006017 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | 0.013160 | 0.012013 | -0.020833 / 0.015503 | -0.041667 / 0.010733 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | -0.036037 | -0.052748 | 0.125000 / 0.027699 | 0.041667 / 0.036746 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | -0.013551 | 0.000000 | 0.000000 / -0.065940 | 0.000000 / -0.012800 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | 0.002009 | 0.002776 | -0.083333 / 0.018236 | 0.000000 / -0.000070 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | 0.006232 | 0.019505 | 0.083333 / 0.018338 | 0.000000 / 0.008103 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | -0.034046 | 0.016424 | 0.062500 / -0.146319 | 0.062500 / 0.003806 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | 0.032012 | 0.027095 | -0.041667 / -0.085274 | -0.062500 / -0.005402 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | -0.004356 | -0.026933 | 0.000000 / 0.044073 | 0.041667 / 0.034364 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | 0.050575 | 0.000000 | -0.083333 / 0.036258 | 0.000000 / 0.089595 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | -0.006464 | -0.007867 | 0.041667 / -0.037170 | 0.000000 / 0.000000 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | -0.002297 | 0.010173 | 0.083333 / 0.005035 | 0.000000 / -0.004311 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | context | None | 48 / 0 / 0 | 0.009869 | 0.012301 | 0.020833 / 0.151957 | 0.062500 / 0.090402 |
| development | 12 | entry_adverse_log_loss | context | None | 48 / 0 / 0 | 0.015224 | 0.011335 | 0.000000 / 0.030671 | -0.041667 / 0.012221 |
| development | 12 | peak_drawdown_log_loss | context | None | 48 / 0 / 0 | -0.032417 | -0.044620 | 0.104167 / 0.039064 | 0.062500 / 0.060858 |
| development | 24 | terminal_log_return | context | None | 24 / 0 / 0 | -0.027278 | 0.000000 | 0.041667 / 0.034571 | 0.000000 / 0.044739 |
| development | 24 | entry_adverse_log_loss | context | None | 24 / 0 / 0 | -0.000021 | 0.002776 | 0.000000 / 0.030473 | 0.000000 / 0.000000 |
| development | 24 | peak_drawdown_log_loss | context | None | 24 / 0 / 0 | 0.005741 | -0.000081 | 0.125000 / 0.066470 | 0.000000 / 0.008103 |
| development | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | unconditional | None | 48 / 0 / 0 | 0.013580 | 0.071265 | 0.041667 / 0.208412 | 0.062500 / 0.178678 |
| development | 12 | entry_adverse_log_loss | unconditional | None | 48 / 0 / 0 | 0.023894 | 0.032996 | 0.000000 / 0.068652 | -0.020833 / 0.046059 |
| development | 12 | peak_drawdown_log_loss | unconditional | None | 48 / 0 / 0 | -0.013916 | -0.021536 | 0.020833 / 0.119227 | 0.062500 / 0.017480 |
| development | 24 | terminal_log_return | unconditional | None | 24 / 0 / 0 | -0.150005 | 0.002658 | 0.291667 / 0.237720 | 0.041667 / 0.148588 |
| development | 24 | entry_adverse_log_loss | unconditional | None | 24 / 0 / 0 | 0.010994 | 0.029622 | -0.125000 / 0.143666 | 0.166667 / 0.141689 |
| development | 24 | peak_drawdown_log_loss | unconditional | None | 24 / 0 / 0 | 0.009179 | -0.063770 | 0.083333 / 0.225999 | 0.000000 / 0.059669 |
| development | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 0 | 48 / 0 / 0 | -0.189984 | 0.012212 | 0.104167 / -0.106121 | 0.145833 / -0.286620 |
| development | 12 | entry_adverse_log_loss | generative | 0 | 48 / 0 / 0 | -0.031813 | -0.036094 | -0.208333 / -0.083828 | -0.062500 / -0.039868 |
| development | 12 | peak_drawdown_log_loss | generative | 0 | 48 / 0 / 0 | 0.032044 | 0.243301 | -0.125000 / 0.099345 | -0.104167 / 0.143366 |
| development | 24 | terminal_log_return | generative | 0 | 24 / 0 / 0 | 0.224111 | 0.094137 | -0.208333 / 0.196295 | -0.375000 / 0.340498 |
| development | 24 | entry_adverse_log_loss | generative | 0 | 24 / 0 / 0 | -0.083837 | -0.021917 | 0.083333 / 0.246180 | 0.250000 / 0.446423 |
| development | 24 | peak_drawdown_log_loss | generative | 0 | 24 / 0 / 0 | -0.016379 | 0.236462 | 0.041667 / -0.019624 | -0.041667 / 0.071907 |
| development | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 1 | 48 / 0 / 0 | -0.191682 | 0.011786 | 0.083333 / -0.111439 | 0.166667 / -0.289924 |
| development | 12 | entry_adverse_log_loss | generative | 1 | 48 / 0 / 0 | -0.032063 | -0.036793 | -0.208333 / -0.084605 | -0.062500 / -0.042939 |
| development | 12 | peak_drawdown_log_loss | generative | 1 | 48 / 0 / 0 | 0.031543 | 0.243041 | -0.125000 / 0.099435 | -0.125000 / 0.141982 |
| development | 24 | terminal_log_return | generative | 1 | 24 / 0 / 0 | 0.225549 | 0.095399 | -0.166667 / 0.197978 | -0.375000 / 0.328951 |
| development | 24 | entry_adverse_log_loss | generative | 1 | 24 / 0 / 0 | -0.083541 | -0.021276 | 0.041667 / 0.246683 | 0.250000 / 0.447847 |
| development | 24 | peak_drawdown_log_loss | generative | 1 | 24 / 0 / 0 | -0.015438 | 0.236060 | 0.000000 / -0.017750 | -0.041667 / 0.070737 |
| development | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |

MC guard (numerical only, not significance):
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [-0.18998444994928312, -0.19168157725635235], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.012211943708391763, 0.01178579049987149], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.031812657341470756, -0.03206338987825605], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.0360943815441526, -0.03679320154504121], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [0.03204423252604969, 0.03154268322919145], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.24330119990661073, 0.24304130683132233], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [0.22411098124896744, 0.22554889067440245], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.09413701770599477, 0.09539876736477615], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.08383702306487577, -0.08354126579955201], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.02191652762406733, -0.02127649429226006], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [-0.016379371124049972, -0.01543812565996785], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.23646206213608015, 0.2360604690392679], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}

Fixed-direction ordering, separate from forecast quality:
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': -0.04666066385246975, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': -0.15422147601456762, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.18887096935143166, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': 0.13429971164821045, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': -0.20454169050060705, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.46931955796710334, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': -0.32110016643236444, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': -0.18928848567020723, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.545722667784579, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
