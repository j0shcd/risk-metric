# Benchmark frontier comparison

Completed measurement; no automatic promotion. Positive loss delta favors candidate; coverage/width are separate tradeoffs.

| Role | Months | Target | Reference | Replica | Scored / failed / unavailable | CRPS delta | Brier delta | 50% coverage delta / width delta | 80% coverage delta / width delta |
|---|---:|---|---|---:|---|---:|---:|---|---|
| development | 12 | terminal_log_return | direct_cdf:dca_risk | None | 48 / 0 / 0 | 0.014060 | 0.008166 | 0.020833 / -0.008143 | 0.020833 / 0.013397 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | -0.012689 | 0.007764 | 0.083333 / 0.025194 | -0.062500 / 0.004081 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 48 / 0 / 0 | -0.000410 | 0.025663 | 0.041667 / -0.010831 | 0.000000 / -0.002551 |
| development | 24 | terminal_log_return | direct_cdf:dca_risk | None | 24 / 0 / 0 | -0.020448 | 0.000000 | 0.125000 / 0.109320 | 0.000000 / 0.004214 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | 0.023357 | 0.014789 | -0.125000 / 0.054846 | 0.000000 / 0.018887 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 24 / 0 / 0 | -0.036603 | 0.003802 | 0.083333 / 0.111618 | 0.041667 / 0.059603 |
| development | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_risk | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.037499 | 0.012321 | 0.000000 / -0.003481 | 0.020833 / 0.036144 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | -0.005180 | 0.007386 | 0.062500 / 0.006606 | -0.062500 / 0.005569 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 48 / 0 / 0 | 0.000309 | 0.009713 | -0.020833 / -0.023266 | 0.000000 / 0.017742 |
| development | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.017951 | 0.000000 | 0.125000 / 0.052835 | 0.000000 / -0.046411 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | 0.015381 | 0.008784 | -0.083333 / 0.056756 | 0.000000 / 0.000216 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 24 / 0 / 0 | -0.025944 | -0.000972 | 0.000000 / 0.036707 | 0.041667 / 0.059603 |
| development | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_top_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.018589 | 0.045039 | 0.041667 / 0.019139 | 0.020833 / -0.004189 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | 0.001789 | 0.058208 | 0.062500 / 0.014812 | -0.083333 / -0.000358 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 48 / 0 / 0 | -0.002815 | 0.007976 | 0.020833 / 0.025046 | 0.020833 / 0.028642 |
| development | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | -0.004410 | 0.000000 | 0.125000 / 0.173795 | 0.000000 / 0.111968 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | 0.022381 | 0.010240 | -0.041667 / 0.051672 | 0.000000 / 0.018887 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 24 / 0 / 0 | -0.043498 | 0.005154 | 0.208333 / 0.169188 | 0.083333 / 0.085346 |
| development | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_bottom_reversal_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | -0.003446 | 0.005272 | 0.020833 / -0.061514 | 0.020833 / -0.080611 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | -0.007422 | 0.001380 | 0.041667 / -0.022063 | -0.062500 / 0.004420 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 48 / 0 / 0 | 0.002364 | 0.035455 | 0.020833 / -0.043263 | -0.041667 / -0.055154 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | 0.027770 | 0.000000 | 0.166667 / 0.161995 | 0.000000 / 0.063679 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | 0.018836 | 0.007125 | -0.041667 / 0.040360 | 0.000000 / 0.018887 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 24 / 0 / 0 | -0.049838 | 0.016705 | 0.125000 / 0.127695 | 0.083333 / 0.085346 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_extension_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | 0.056404 | 0.012321 | 0.000000 / -0.001843 | 0.000000 / 0.012541 |
| development | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | -0.003690 | 0.009809 | 0.041667 / -0.002928 | -0.062500 / 0.002426 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 48 / 0 / 0 | -0.002354 | 0.006271 | -0.020833 / -0.017320 | 0.020833 / 0.023271 |
| development | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.024555 | 0.000000 | 0.125000 / -0.026387 | 0.000000 / -0.032454 |
| development | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | 0.019500 | 0.011140 | -0.083333 / 0.052418 | 0.000000 / 0.015338 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 24 / 0 / 0 | -0.020619 | -0.009219 | -0.083333 / -0.036914 | 0.000000 / 0.022529 |
| development | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:dca_cycle_regime_component | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | -0.011473 | 0.021199 | 0.020833 / 0.149423 | 0.041667 / 0.083487 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | -0.016772 | -0.004051 | 0.104167 / 0.064168 | -0.041667 / 0.014564 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 48 / 0 / 0 | -0.009716 | 0.005612 | 0.104167 / 0.005177 | 0.020833 / 0.040105 |
| development | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.000396 | 0.000000 | 0.125000 / 0.168686 | 0.000000 / 0.111968 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | 0.020160 | 0.008762 | 0.000000 / 0.062150 | 0.000000 / 0.018887 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 24 / 0 / 0 | -0.042745 | 0.005154 | 0.208333 / 0.164191 | 0.083333 / 0.080349 |
| development | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_trend_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | -0.011473 | 0.021199 | 0.020833 / 0.149423 | 0.041667 / 0.083487 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | -0.016772 | -0.004051 | 0.104167 / 0.064168 | -0.041667 / 0.014564 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 48 / 0 / 0 | -0.009716 | 0.005612 | 0.104167 / 0.005177 | 0.020833 / 0.040105 |
| development | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.000396 | 0.000000 | 0.125000 / 0.168686 | 0.000000 / 0.111968 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | 0.020160 | 0.008762 | 0.000000 / 0.062150 | 0.000000 / 0.018887 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 24 / 0 / 0 | -0.042745 | 0.005154 | 0.208333 / 0.164191 | 0.083333 / 0.080349 |
| development | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_volatility_90d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.005831 | 0.002350 | 0.041667 / 0.106275 | 0.020833 / -0.063291 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | -0.003594 | -0.005974 | 0.062500 / 0.029803 | -0.062500 / -0.007659 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 48 / 0 / 0 | 0.004561 | 0.010273 | 0.000000 / -0.026935 | 0.000000 / -0.004754 |
| development | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | 0.015002 | 0.000000 | 0.000000 / 0.027350 | 0.000000 / -0.013313 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | 0.008870 | -0.001881 | -0.041667 / 0.003541 | 0.000000 / 0.018816 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 24 / 0 / 0 | -0.029556 | -0.015729 | 0.125000 / 0.012317 | 0.041667 / 0.016101 |
| development | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_drawdown_12m | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | -0.016388 | 0.007418 | 0.000000 / -0.162788 | 0.000000 / -0.067220 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | -0.005293 | 0.011464 | 0.041667 / -0.018560 | -0.062500 / 0.005006 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 48 / 0 / 0 | -0.000215 | 0.011687 | -0.020833 / -0.039547 | -0.020833 / 0.028001 |
| development | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | 0.029097 | 0.000000 | 0.166667 / 0.165806 | 0.000000 / 0.115741 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | 0.022515 | 0.011140 | 0.000000 / 0.059365 | 0.000000 / 0.018887 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 24 / 0 / 0 | -0.065871 | 0.002008 | 0.125000 / 0.045959 | 0.083333 / 0.085346 |
| development | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_ath_drawdown | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.055661 | 0.010237 | 0.020833 / 0.061298 | 0.000000 / -0.082098 |
| development | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.005310 | 0.025617 | 0.062500 / 0.018128 | -0.083333 / -0.004944 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 48 / 0 / 0 | 0.019722 | 0.051680 | -0.020833 / -0.031716 | -0.062500 / -0.018356 |
| development | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | 0.049953 | 0.000000 | 0.041667 / 0.137935 | 0.000000 / 0.042327 |
| development | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | 0.018246 | 0.003762 | -0.041667 / 0.044551 | 0.000000 / 0.018816 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 24 / 0 / 0 | -0.033031 | 0.036788 | 0.083333 / 0.058093 | 0.041667 / 0.033628 |
| development | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:price_log_sma_200d | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | 0.055130 | 0.027636 | -0.020833 / -0.018286 | -0.041667 / -0.075278 |
| development | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | -0.011442 | 0.032990 | 0.083333 / 0.016808 | -0.083333 / -0.024611 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 48 / 0 / 0 | -0.004278 | 0.021072 | 0.083333 / 0.036089 | 0.020833 / 0.007994 |
| development | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | -0.042316 | 0.000000 | 0.041667 / -0.177914 | 0.000000 / -0.058831 |
| development | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | 0.060233 | 0.037546 | -0.125000 / 0.009140 | -0.083333 / 0.014180 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 24 / 0 / 0 | -0.006312 | -0.000434 | 0.166667 / 0.080349 | 0.041667 / 0.058358 |
| development | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:time_years_since_2012 | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | 0.030216 | 0.031786 | 0.041667 / 0.131568 | 0.041667 / -0.000898 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | -0.018836 | -0.003373 | 0.083333 / 0.049000 | -0.041667 / 0.013076 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 48 / 0 / 0 | -0.013337 | -0.002516 | 0.125000 / -0.006188 | 0.000000 / 0.015994 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | 0.013332 | 0.000000 | 0.083333 / 0.068174 | 0.000000 / 0.054430 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | 0.022190 | 0.008762 | -0.083333 / 0.049913 | 0.000000 / 0.018816 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 24 / 0 / 0 | -0.042254 | 0.024740 | 0.166667 / 0.116059 | 0.083333 / 0.080349 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_sin_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | -0.055388 | 0.025321 | 0.062500 / -0.148853 | 0.041667 / -0.003108 |
| development | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | 0.000016 | 0.011709 | 0.062500 / -0.051777 | -0.062500 / -0.003059 |
| development | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 48 / 0 / 0 | 0.018345 | 0.023300 | 0.000000 / 0.010186 | 0.000000 / 0.013612 |
| development | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | 0.077458 | 0.000000 | 0.000000 / 0.170372 | 0.000000 / 0.156825 |
| development | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | 0.013718 | -0.001881 | 0.041667 / -0.005494 | 0.000000 / 0.018887 |
| development | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 24 / 0 / 0 | -0.050782 | 0.015408 | 0.166667 / 0.102757 | 0.083333 / 0.067935 |
| development | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | direct_cdf:calendar_cycle_cos_4y | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | context | None | 48 / 0 / 0 | -0.011473 | 0.021199 | 0.020833 / 0.149423 | 0.041667 / 0.083487 |
| development | 12 | entry_adverse_log_loss | context | None | 48 / 0 / 0 | -0.016772 | -0.004051 | 0.104167 / 0.064168 | -0.041667 / 0.014564 |
| development | 12 | peak_drawdown_log_loss | context | None | 48 / 0 / 0 | -0.009716 | 0.005612 | 0.104167 / 0.005177 | 0.020833 / 0.040105 |
| development | 24 | terminal_log_return | context | None | 24 / 0 / 0 | -0.000396 | 0.000000 | 0.125000 / 0.168686 | 0.000000 / 0.111968 |
| development | 24 | entry_adverse_log_loss | context | None | 24 / 0 / 0 | 0.020160 | 0.008762 | 0.000000 / 0.062150 | 0.000000 / 0.018887 |
| development | 24 | peak_drawdown_log_loss | context | None | 24 / 0 / 0 | -0.042745 | 0.005154 | 0.208333 / 0.164191 | 0.083333 / 0.080349 |
| development | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | context | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | unconditional | None | 48 / 0 / 0 | -0.007762 | 0.080162 | 0.041667 / 0.205878 | 0.041667 / 0.171763 |
| development | 12 | entry_adverse_log_loss | unconditional | None | 48 / 0 / 0 | -0.008102 | 0.017610 | 0.104167 / 0.102149 | -0.020833 / 0.048402 |
| development | 12 | peak_drawdown_log_loss | unconditional | None | 48 / 0 / 0 | 0.008785 | 0.028697 | 0.020833 / 0.085340 | 0.020833 / -0.003272 |
| development | 24 | terminal_log_return | unconditional | None | 24 / 0 / 0 | -0.123122 | 0.002658 | 0.375000 / 0.371834 | 0.041667 / 0.215818 |
| development | 24 | entry_adverse_log_loss | unconditional | None | 24 / 0 / 0 | 0.031175 | 0.035608 | -0.125000 / 0.175343 | 0.166667 / 0.160575 |
| development | 24 | peak_drawdown_log_loss | unconditional | None | 24 / 0 / 0 | -0.039307 | -0.058535 | 0.166667 / 0.323721 | 0.083333 / 0.131915 |
| development | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | unconditional | None | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 0 | 48 / 0 / 0 | -0.211326 | 0.021110 | 0.104167 / -0.108655 | 0.125000 / -0.293535 |
| development | 12 | entry_adverse_log_loss | generative | 0 | 48 / 0 / 0 | -0.063809 | -0.051480 | -0.104167 / -0.050331 | -0.062500 / -0.037524 |
| development | 12 | peak_drawdown_log_loss | generative | 0 | 48 / 0 / 0 | 0.054745 | 0.293534 | -0.125000 / 0.065458 | -0.145833 / 0.122614 |
| development | 24 | terminal_log_return | generative | 0 | 24 / 0 / 0 | 0.250994 | 0.094137 | -0.125000 / 0.330410 | -0.375000 / 0.407727 |
| development | 24 | entry_adverse_log_loss | generative | 0 | 24 / 0 / 0 | -0.063656 | -0.015931 | 0.083333 / 0.277857 | 0.250000 / 0.465309 |
| development | 24 | peak_drawdown_log_loss | generative | 0 | 24 / 0 / 0 | -0.064865 | 0.241697 | 0.125000 / 0.078098 | 0.041667 / 0.144153 |
| development | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 0 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 12 | terminal_log_return | generative | 1 | 48 / 0 / 0 | -0.213024 | 0.020683 | 0.083333 / -0.113974 | 0.145833 / -0.296839 |
| development | 12 | entry_adverse_log_loss | generative | 1 | 48 / 0 / 0 | -0.064059 | -0.052179 | -0.104167 / -0.051108 | -0.062500 / -0.040596 |
| development | 12 | peak_drawdown_log_loss | generative | 1 | 48 / 0 / 0 | 0.054243 | 0.293274 | -0.125000 / 0.065548 | -0.166667 / 0.121230 |
| development | 24 | terminal_log_return | generative | 1 | 24 / 0 / 0 | 0.252431 | 0.095399 | -0.083333 / 0.332092 | -0.375000 / 0.396180 |
| development | 24 | entry_adverse_log_loss | generative | 1 | 24 / 0 / 0 | -0.063360 | -0.015291 | 0.041667 / 0.278360 | 0.250000 / 0.466733 |
| development | 24 | peak_drawdown_log_loss | generative | 1 | 24 / 0 / 0 | -0.063923 | 0.241295 | 0.083333 / 0.079972 | 0.041667 / 0.142983 |
| development | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| development | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outer | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| retrospective_challenge | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| pending | 12 | terminal_log_return | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 13 | — | — | — / — | — / — |
| pending | 24 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | terminal_log_return | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| pending | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 25 | — | — | — / — | — / — |
| outcome_unavailable | 12 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 12 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 24 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | terminal_log_return | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | entry_adverse_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |
| outcome_unavailable | 48 | peak_drawdown_log_loss | generative | 1 | 0 / 0 / 0 | — | — | — / — | — / — |

MC guard (numerical only, not significance):
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [-0.21132640111802922, -0.2130235284250984], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.021109513152836202, 0.02068335994431593], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.06380864495100323, -0.06405937748778852], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.05148030457656002, -0.05217912457744863], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [0.05474479180727047, 0.05424324251041224], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.2935337262697794, 0.293273833194491], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [0.250993533333408, 0.25243144275884305], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [0.09413701770599477, 0.09539876736477615], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [-0.06365579867126585, -0.06336004140594206], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [-0.015930561188882145, -0.015290527857074881], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [-0.06486472639038678, -0.06392348092630466], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [0.24169696859866519, 0.2412953755018529], 'numerically_stable_gain': True}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'crps', 'replica_gains': [None, None], 'numerically_stable_gain': False}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'metric': 'brier', 'replica_gains': [None, None], 'numerically_stable_gain': False}

Fixed-direction ordering, separate from forecast quality:
- {'role': 'development', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': 0.22086765560034022, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.07932545147229478, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.11194900300233111, 'diagnostic_n': 84, 'diagnostic_origins_id': '67a6b3390bf51f95e3407bf9a2ed64770a704baf65063fa750e5fff0fad547b5'}
- {'role': 'outer', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 12, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': -0.06279245565514381, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.1106696814155427, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': 0.04574297619606229, 'diagnostic_n': 72, 'diagnostic_origins_id': '10c1596028fe928cd566c1b426e79be96e2e503907da3c3a5f98df66ea5fc99e'}
- {'role': 'outer', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 24, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': 0.4160265060769986, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'terminal_log_return', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': 0.2731741885676569, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'entry_adverse_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'development', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': -0.3712603413819685, 'diagnostic_n': 48, 'diagnostic_origins_id': '0683b29e5b8f7a83244f234d85ff656c06954601808c92ddc50d80ed5839d059'}
- {'role': 'outer', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'retrospective_challenge', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'pending', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
- {'role': 'outcome_unavailable', 'horizon': 48, 'target': 'peak_drawdown_log_loss', 'ordinal_alignment': None, 'diagnostic_n': 0, 'diagnostic_origins_id': '37517e5f3dc66819f61f5a7bb8ace1921282415f10551d2defa5c3eb0985b570'}
