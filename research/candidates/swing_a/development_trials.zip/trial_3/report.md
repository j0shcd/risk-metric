# Development indicator replay

Candidate: swing_a_memory_100
Labels available by 2022-12-31 only. Reconstructed data; no market significance or outer validation.

| Months | Outcome | Forecast n | Candidate CRPS | Context CRPS | Unconditional CRPS | Best fixed reference | Alignment |
|---:|---|---:|---:|---:|---:|---|---:|
| 12 | terminal_log_return | 48 | 0.908580 | 0.854808 | 0.858520 | calendar_cycle_cos_4y (0.810894) | 0.610023 |
| 12 | entry_adverse_log_loss | 48 | 0.351699 | 0.353230 | 0.361899 | calendar_cycle_sin_4y (0.351166) | 0.600980 |
| 12 | peak_drawdown_log_loss | 48 | 0.244160 | 0.263792 | 0.282293 | calendar_cycle_sin_4y (0.260172) | 0.463286 |
| 24 | terminal_log_return | 24 | 0.496247 | 0.453800 | 0.331074 | time_years_since_2012 (0.411880) | 0.466622 |
| 24 | entry_adverse_log_loss | 24 | 0.224762 | 0.238338 | 0.249353 | price_drawdown_12m (0.227048) | 0.584077 |
| 24 | peak_drawdown_log_loss | 24 | 0.311153 | 0.297130 | 0.300568 | price_ath_drawdown (0.274003) | 0.075183 |
| 48 | terminal_log_return | 0 | — | — | — | — | 0.714069 |
| 48 | entry_adverse_log_loss | 0 | — | — | — | — | 0.757902 |
| 48 | peak_drawdown_log_loss | 0 | — | — | — | — | -0.736556 |
