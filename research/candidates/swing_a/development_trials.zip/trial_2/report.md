# Development indicator replay

Candidate: swing_a_memory_50
Labels available by 2022-12-31 only. Reconstructed data; no market significance or outer validation.

| Months | Outcome | Forecast n | Candidate CRPS | Context CRPS | Unconditional CRPS | Best fixed reference | Alignment |
|---:|---|---:|---:|---:|---:|---|---:|
| 12 | terminal_log_return | 48 | 0.886059 | 0.854808 | 0.858520 | calendar_cycle_cos_4y (0.810894) | 0.602450 |
| 12 | entry_adverse_log_loss | 48 | 0.349213 | 0.353230 | 0.361899 | calendar_cycle_sin_4y (0.351166) | 0.629175 |
| 12 | peak_drawdown_log_loss | 48 | 0.254054 | 0.263792 | 0.282293 | calendar_cycle_sin_4y (0.260172) | 0.647919 |
| 24 | terminal_log_return | 24 | 0.477084 | 0.453800 | 0.331074 | time_years_since_2012 (0.411880) | 0.639173 |
| 24 | entry_adverse_log_loss | 24 | 0.226005 | 0.238338 | 0.249353 | price_drawdown_12m (0.227048) | 0.645963 |
| 24 | peak_drawdown_log_loss | 24 | 0.309671 | 0.297130 | 0.300568 | price_ath_drawdown (0.274003) | 0.461730 |
| 48 | terminal_log_return | 0 | — | — | — | — | 0.718194 |
| 48 | entry_adverse_log_loss | 0 | — | — | — | — | 0.744542 |
| 48 | peak_drawdown_log_loss | 0 | — | — | — | — | -0.592543 |
